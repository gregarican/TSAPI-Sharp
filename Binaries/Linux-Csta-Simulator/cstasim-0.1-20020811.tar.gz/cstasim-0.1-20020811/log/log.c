/*
 * log.c : log primitives
 *
 * Copyright (C) 2000 Alc�ve and Julien Gaulmin <julien.gaulmin@fr.alcove.com>
 *
 * Based on work from :
 * Francisco Espinoza Junior and Philippe de M. Sevestre
 * Dedalus Engenharia S/C Ltda - Convenio GMK/FDTE
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */

#include <stdio.h>
#include <time.h>
#include <stdarg.h>

#include "log.h"


static FILE *logfile;
static loglevel = LOG_NOTICE;


char *timestamp()
{
	static char mtime[50];
	time_t clock;

	clock = time(NULL);
	strftime(mtime, 50, "%e/%m/%y %H:%M:%S", localtime(&clock));

	return (mtime);
}


char *timestampAnsi()
{
	static char mtime[50];
	time_t clock;
	struct tm *now;

	clock = time(NULL);
	now = localtime(&clock);
	sprintf(mtime, "%04d%02d%02d%02d%02d%02d", now->tm_year + 1900, now->tm_mon + 1, now->tm_mday, now->tm_hour, now->tm_min, now->tm_sec);    	

	return (mtime);
}


int loggetfd(void) 
{
	return fileno(logfile);
}


void loginit(FILE *f)
{
	logfile = f;
    
	setvbuf(f, (char *) NULL, _IOLBF, 0);
}


void logsetlevel(int level)
{
	loglevel = level % (LOG_DEBUG + 1);
}


void logmsg(int level, char *s, ...)
{
	va_list args;
    
	if (level > loglevel)
		return;

	fprintf(logfile, timestamp());
	fprintf(logfile, ": %d :", getpid());

	va_start(args, s);
	vfprintf(logfile, s, args);

	if (s[strlen(s)-1] != '\n')
		fprintf (logfile, "\n");

	fflush(logfile);
}


void logdump(int level, char *buf, size_t buflen)
{
	register char *p;
	register int i, j;

	if (level > loglevel)
		return;

	fprintf(logfile, "\n");
	fprintf(logfile, timestamp());
	fprintf(logfile, "\n\n");

	for (i = 0; i < buflen; i+=8) {
		fprintf(logfile, "\t%08x:", i);
		
		p = buf;
		for (j = 0 ;j < 8 && (i+j) < buflen; j++, p++)
			fprintf(logfile, " %02x", (unsigned int) (*p & 0x00ffl));

		while (j < 8) {
			fprintf(logfile, "   ");
			j++;
		}
		
		fprintf(logfile, " ");
		p = buf;

		for (j = 0; j < 8 && (i+j) < buflen; j++, p++)
			fprintf(logfile, " %c", (isprint(*p)?*p:'.'));

		while (j < 8) {
			fprintf(logfile, "  ");
			j++;
		}

		buf += 8;	
		fprintf(logfile, "\n");
	}

	fflush(logfile);
}
