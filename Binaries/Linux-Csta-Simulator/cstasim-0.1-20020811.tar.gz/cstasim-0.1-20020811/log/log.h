/*
 * log.h : log primitives
 */

#ifndef _LOG_H
#define _LOG_H

#ifdef WIN32
#ifdef LOGDLL
#define LOGIMPORTEXPORT __declspec(dllexport)
#else
#define LOGIMPORTEXPORT __declspec(dllimport)
#endif
#else
#define LOGIMPORTEXPORT
#endif


void LOGIMPORTEXPORT loginit(FILE *f);
int LOGIMPORTEXPORT loggetfd(void);
char LOGIMPORTEXPORT *timestamp(void);
char LOGIMPORTEXPORT *timestampAnsi(void);
void LOGIMPORTEXPORT logmsg(int level, char *fmt, ...);
void LOGIMPORTEXPORT logdump(int level, char *buf, size_t buflen);
void LOGIMPORTEXPORT logsetlevel(int level);

#define debugmsg(a)	logmsg(LOG_DEBUG, a);


#ifndef LOG_DEBUG
#define LOG_EMERG	0	/* system is unusable */
#define LOG_ALERT	1	/* action must be taken immediately */
#define LOG_CRIT	2	/* critical conditions */
#define LOG_ERR		3	/* error conditions */
#define LOG_WARNING	4	/* warning conditions */
#define LOG_NOTICE	5	/* normal but signification condition */
#define LOG_INFO	6	/* informational */
#define LOG_DEBUG	7	/* debug-level messages */
#endif


#endif /* _LOG_H */
