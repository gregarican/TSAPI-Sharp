/*
 * cstaclient.c : csta test client application
 *
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 * 
 * Based on work from :
 * Julien Gaulmin <julien.gaulmin@fr.alcove.com>
 * Francisco Espinoza Junior and Philippe de M. Sevestre
 * Dedalus Engenharia S/C Ltda - Convenio GMK/FDTE
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */


#ifdef WIN32
#ifdef CSTADLL
#define CSTADLLIMPORTEXPORT __declspec(dllexport)
#else
#define CSTADLLIMPORTEXPORT __declspec(dllimport)
#endif /* CSTADLL */
#else
#define CSTADLLIMPORTEXPORT
#endif /* WIN32 */

#ifndef WIN32
#include <unistd.h>
#include <poll.h>
#include <signal.h>
#include <time.h>
#include <string.h>
#else
#include <windows.h>
#include <time.h>
#include <winsock2.h>
#endif

extern "C"
{
#include "asn-incl.h"
#include "CSTA-asnany-bridge.h"
#include "csta_defs.h"
}
#include "csta_config.h"
#include "csta_api.h"
#include "csta_request_api.h"
#include "csta_response_api.h"
extern "C"
{
#include "log.h"
#include "tspsock.h"
}
#include "cstaclient.h"


#ifdef WIN32
#define strcasecmp _stricmp
#endif

extern void setoctet(void *, char *);

/* Global variable */
static char enc_buff[8192];
#define ENC_BUFF_LEN sizeof(enc_buff);

static int gRequestID = 0x1000;
static int fdcsta = -1, fdserver = -1;
static time_t tm;
static char logpath[] = "cstaclient.log";
static FILE *logfile;

unsigned long getulong(char *prompt);

/* Constantes and macros */
#define REQUEST_ID	gRequestID
#define NEXT_REQUESTID	++gRequestID
#define INFTIM		-1 
#define MAX_NUM_SIZE	20 
#define DEST_SOCKET ((fdcsta == -1) ? fdserver : fdcsta)

#define DEBUG_CSTATEST
 
handler_entry Event_report_service_handlers[] = 
{
	RECEIVED_CALLCLEAREDEVENT,		received_CALLEVENT_CALLCLEAREDEVENT,
	RECEIVED_CONFERENCEDEVENT,		received_CALLEVENT_CONFERENCEDEVENT,
	RECEIVED_CONNECTIONCLEAREDEVENT,	received_CALLEVENT_CONNECTIONCLEAREDEVENT,
	RECEIVED_DELIVEREDEVENT,		received_CALLEVENT_DELIVEREDEVENT,
	RECEIVED_DIVERTEDEVENT,			received_CALLEVENT_DIVERTEDEVENT,
	RECEIVED_ESTABLISHEDEVENT,		received_CALLEVENT_ESTABLISHEDEVENT,
	RECEIVED_FAILEDEVENT,			received_CALLEVENT_FAILEDEVENT,
	RECEIVED_HELDEVENT,			received_CALLEVENT_HELDEVENT,
	RECEIVED_NETWORKREACHEDEVENT,		received_CALLEVENT_NETWORKREACHEDEVENT,
	RECEIVED_ORIGINATEDEVENT,		received_CALLEVENT_ORIGINATEDEVENT,
	RECEIVED_QUEUEDEVENT,			received_CALLEVENT_QUEUEDEVENT,
	RECEIVED_RETRIEVEDEVENT,		received_CALLEVENT_RETRIEVEDEVENT,
	RECEIVED_SERVICEINITIATEDEVENT,		received_CALLEVENT_SERVICEINITIATEDEVENT,
	RECEIVED_TRANSFEREDEVENT,		received_CALLEVENT_TRANSFEREDEVENT,

	RECEIVED_AUTOANSWEREVENT,		received_FEATUREEVENT_AUTOANSWEREVENT,
	RECEIVED_CALLINFORMATIONEVENT,		received_FEATUREEVENT_CALLINFORMATIONEVENT,
	RECEIVED_DONOTDISTURBEVENT,		received_FEATUREEVENT_DONOTDISTURBEVENT,
	RECEIVED_FORWARDINGEVENT,		received_FEATUREEVENT_FORWARDINGEVENT,
	RECEIVED_MESSAGEWAITINGEVENT,		received_FEATUREEVENT_MESSAGEWAITINGEVENT,
	RECEIVED_MICROPHONEMUTEEVENT,		received_FEATUREEVENT_MICROPHONEMUTEEVENT,
	RECEIVED_SPEAKERMUTEEVENT,		received_FEATUREEVENT_SPEAKERMUTEEVENT,
	RECEIVED_SPEAKERVOLUMEEVENT,		received_FEATUREEVENT_SPEAKERVOLUMEEVENT,

	RECEIVED_AGENTBUSYEVENT,		received_AGENTSTATEEVENT_AGENTBUSYEVENT,
	RECEIVED_LOGGEDONEVENT,			received_AGENTSTATEEVENT_LOGGEDONEVENT,
	RECEIVED_LOGGEDOFFEVENT,		received_AGENTSTATEEVENT_LOGGEDOFFEVENT,
	RECEIVED_NOTREADYEVENT,			received_AGENTSTATEEVENT_NOTREADYEVENT,
	RECEIVED_READYEVENT,			received_AGENTSTATEEVENT_READYEVENT,
	RECEIVED_WORKINGAFTERCALLEVENT,		received_AGENTSTATEEVENT_WORKINGAFTERCALLEVENT,

	RECEIVED_BACKINSERVICEEVENT,		received_MAINTENANCEEVENT_BACKINSERVICEEVENT,
	RECEIVED_OUTOFSERVICEEVENT,		received_MAINTENANCEEVENT_OUTOFSERVICEEVENT,

	RECEIVED_PLAYEVENT,			received_VOICEUNITEVENT_PLAYEVENT,
	RECEIVED_RECORDEVENT,			received_VOICEUNITEVENT_RECORDEVENT,
	RECEIVED_REVIEWEVENT,			received_VOICEUNITEVENT_REVIEWEVENT,
	RECEIVED_STOPEVENT,			received_VOICEUNITEVENT_STOPEVENT,
	RECEIVED_SUSPENDPLAYEVENT,		received_VOICEUNITEVENT_SUSPENDPLAYEVENT,
	RECEIVED_SUSPENDRECORDEVENT,		received_VOICEUNITEVENT_SUSPENDRECORDEVENT,
	RECEIVED_VOICEATTRIBUTESCHANGEEVENT,	received_VOICEUNITEVENT_VOICEATTRIBUTESCHANGEEVENT,
	-1,					NULL
};

handler_entry Bidirectional_services_request_handlers[] =
{
	OV_ESCAPESERVICE,	received_roiv_ESCAPESERVICE,
	OV_SYSTEMSTATUS,	received_roiv_SYSTEMSTATUS,
	-1,			NULL
};

handler_entry Switching_function_service_response_handlers[] =
{
	OV_ALTERNATECALL,	received_rors_ALTERNATECALL,
	OV_ANSWERCALL,		received_rors_ANSWERCALL,
	OV_ASSOCIATEDATA,	received_rors_ASSOCIATEDATA,
	OV_CALLCOMPLETION,	received_rors_CALLCOMPLETION,
	OV_CLEARCALL,		received_rors_CLEARCALL,
	OV_CLEARCONNECTION,	received_rors_CLEARCONNECTION,
	OV_CONFERENCECALL,	received_rors_CONFERENCECALL,
	OV_CONSULTATIONCALL,	received_rors_CONSULTATIONCALL,
	OV_DIVERTCALL,		received_rors_DIVERTCALL,
	OV_HOLDCALL,		received_rors_HOLDCALL,
	OV_MAKECALL,		received_rors_MAKECALL,
	OV_MAKEPREDICTIVECALL,	received_rors_MAKEPREDICTIVECALL,
	OV_PARKCALL,		received_rors_PARKCALL,
	OV_QUERYDEVICE,		received_rors_QUERYDEVICE,
	OV_RECONNECTCALL,	received_rors_RECONNECTCALL,
	OV_RETRIEVECALL,	received_rors_RETRIEVECALL,
	OV_SENDDTMFTONES,	received_rors_SENDDTMFTONES,
	OV_SETFEATURE,		received_rors_SETFEATURE,
	OV_SINGLESTEPCONF,	received_rors_SINGLESTEPCONF,
	OV_SINGLESTEPTRANS,	received_rors_SINGLESTEPTRANS,
	OV_TRANSFERCALL,	received_rors_TRANSFERCALL,
	-1,			NULL
};

handler_entry Computing_function_services_response_handlers[] =
{
	OV_ROUTEREQUEST,	received_rors_ROUTEREQUEST,
	OV_REROUTEREQUEST,	received_rors_REROUTEREQUEST,
	OV_ROUTESELECTREQUEST,	received_rors_ROUTESELECTREQUEST,
	OV_ROUTEUSEDREQUEST,	received_rors_ROUTEUSEDREQUEST,
	OV_ROUTEENDREQUEST,	received_rors_ROUTEENDREQUEST,
	-1,			NULL
};

handler_entry Bidirectional_services_response_handlers[] =
{
	OV_ESCAPESERVICE,	received_rors_ESCAPESERVICE,
	OV_SYSTEMSTATUS,	received_rors_SYSTEMSTATUS,
	-1,			NULL
};

handler_entry Status_reporting_services_response_handlers[] =
{
	OV_MONITORSTART,	received_rors_MONITORSTART,
	OV_CHANGEMONITORFILTER,	received_rors_CHANGEMONITORFILTER,
	OV_MONITORSTOP,		received_rors_MONITORSTOP,
	OV_SNAPSHOTDEVICE,	received_rors_SNAPSHOTDEVICE,
	OV_SNAPSHOTCALL,	received_rors_SNAPSHOTCALL,
	-1,			NULL
};

handler_entry Input_output_services_response_handlers[] =
{
	OV_STARTDATAPATH,	received_rors_STARTDATAPATH,
	OV_STOPDATAPATH,	received_rors_STOPDATAPATH,
	OV_SENDDATA,		received_rors_SENDDATA,
	OV_SENDMULTICASTDATA,	received_rors_SENDMULTICASTDATA,
	OV_SENDBROADCASTDATA,	received_rors_SENDBROADCASTDATA,
	OV_SUSPENDDATAPATH,	received_rors_SUSPENDDATAPATH,
	OV_DATAPATHSUSPENDED,	received_rors_DATAPATHSUSPENDED,
	OV_RESUMEDATAPATH,	received_rors_RESUMEDATAPATH,
	OV_DATAPATHRESUMED,	received_rors_DATAPATHRESUMED,
	OV_FASTDATA,		received_rors_FASTDATA,
	-1,			NULL
};

handler_entry Voice_unit_services_response_handlers[] =
{
	OV_CONCATENATEMESSAGE,	received_rors_CONCATENATEMESSAGE,
	OV_DELETEMESSAGE,	received_rors_DELETEMESSAGE,
	OV_PLAYMESSAGE,		received_rors_PLAYMESSAGE,
	OV_QUERYVOICEATTRIBUTE,	received_rors_QUERYVOICEATTRIBUTE,
	OV_RECORDMESSAGE,	received_rors_RECORDMESSAGE,
	OV_REPOSITION,		received_rors_REPOSITION,
	OV_RESUME,		received_rors_RESUME,
	OV_REVIEW,		received_rors_REVIEW,
	OV_SETVOICEATTRIBUTE,	received_rors_SETVOICEATTRIBUTE,
	OV_STOP,		received_rors_STOP,
	OV_SUSPEND,		received_rors_SUSPEND,
	OV_SYNTHESIZEMESSAGE,	received_rors_SYNTHESIZEMESSAGE,
	-1,			NULL,
};
 
int main(int argc, char **argv)
{
	int test;
	int len;
#ifdef WIN32
	WSADATA wsd;

	WSAStartup(MAKEWORD(1,1), &wsd);


	//__asm int(3);
#endif

	/* Setup exit signals */
#ifndef WIN32
	signal(SIGTERM, end);
	signal(SIGQUIT, end);
	signal(SIGINT, end);
#endif

	/* Set log level and output stream */
	logfile = fopen(logpath, "a");
	logsetlevel(LOG_DEBUG);
	loginit(logfile);
	csta_init();

	/* Check args */
	if (argc == 3) {
		/* Open TCP socket for the CSTA server */
		fdcsta = tsp_open_socket("tcp", argv[1], argv[2], CLIENT);
		if (fdcsta < 0) {
			perror("cstaclient.c: main(): tsp_open_socket(CLIENT)");
			exit(-1);
		}

	} else {
		printf("Usage: cstaclient <host> <port>\n");
		exit(-1);
	}

	/* Setup Log file */
	tm = time(NULL);
	fprintf(logfile, "\n********************************************************************************\n");
	fprintf(logfile, "\n\nRestarted on %s", ctime(&tm));
	fprintf(logfile, "\n--------------------------------------------------------------------------------\n");

	if (fdserver > 0)
	{
		while(1)
		{
			poll_input();
		}
	}

loop:
	printf("Enter the type of primitive :\n");
	printf("\t 1 - MonitorStart\n");
	printf("\t 2 - MonitorStop\n");
	printf("\t 3 - AlternateCall\n");
	printf("\t 4 - AnswerCall\n");
	printf("\t 5 - ClearCall\n");
	printf("\t 6 - ClearConnection\n");
	printf("\t 7 - ConsultationCall\n");
	printf("\t 8 - DivertCall\n");
	printf("\t 9 - HoldCall\n");
	printf("\t10 - MakeCall\n");
	printf("\t11 - MakePredictiveCall\n");
	printf("\t12 - ParkCall\n");
	printf("\t13 - QueryDevice\n");
	printf("\t14 - ReconnectCall\n");
	printf("\t15 - RetrieveCall\n");
	printf("\t16 - SendDTMFTones\n");
	printf("\t17 - SetMessageWaiting\n");
	printf("\t18 - SetDoNotDisturb\n");
	printf("\t19 - SetForwarding\n");
	printf("\t20 - SetAgentState\n");
	printf("\t21 - EnableRouting\n");
	printf("\t22 - AutoAnswer\n");
	printf("\t23 - MicrophoneMute\n");
	printf("\t24 - SpeakerMute\n");
	printf("\t25 - SpeakerVolume\n");
	printf("\t26 - SingleStepConference\n");
	printf("\t27 - SingleStepTransfer\n");
	printf("\t28 - TransferCall\n");
	printf("\t29 - ChangeMonitorFilter\n");

	test = getint("Your choice ->");
	len = 0;

	switch(test)
	{
	case 1: /* MonitorStart */ {
		char device[MAX_NUM_SIZE];

		getstring("Device to monitor : ", device, sizeof(device));

		len = csta_request_MonitorStart(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, device, NULL, NULL);
		if (tsp_write_socket(DEST_SOCKET, (void *) enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;


	case 2: /* MonitorStop */ {
		unsigned long refid;

		refid = getulong("Monitor's crossRefID : ");

		len = csta_request_MonitorStop(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, refid, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 3: /* AlternateCall */ {
		char device[MAX_NUM_SIZE];
		unsigned long active_connid;
		unsigned long held_connid;

		getstring("Device : ", device, sizeof(device));

		active_connid = getulong("Active ConnectionId: ");
		held_connid = getulong("Held ConnectionId: ");

		len = csta_request_AlternateCall(enc_buff, sizeof(enc_buff), NEXT_REQUESTID,
											device, active_connid, held_connid, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 4: /* AnswerCall */ {
		char num[MAX_NUM_SIZE];
		unsigned long connid;

		getstring("Device to lift : ", num, sizeof(num));

		connid = getulong("ConnectionId: ");
		len = csta_request_AnswerCall(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, num, connid, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 5: /* ClearCall */ {
		char num[MAX_NUM_SIZE];
		unsigned long Ref;

		Ref = getulong("ConnectionId: ");
		len = csta_request_ClearCall(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, Ref, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 6: /* ClearConnection */ {
		char num[MAX_NUM_SIZE];
		unsigned long Ref;

		getstring("Device to clear : ", num, sizeof(num));

		Ref = getulong("ConnectionId: ");
		len = csta_request_ClearConnection(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, num, Ref, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 7: /* ConsultationCall */ {
		char caller[MAX_NUM_SIZE];
		char destination[MAX_NUM_SIZE];
		unsigned long connid;

		getstring("Calling device : ", caller, sizeof(caller));

		connid = getulong("Active ConnectionId: ");
		getstring("Called device : ", destination, sizeof(destination));

		len = csta_request_ConsultationCall(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, caller, connid, destination, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 8: /* DivertCall */ {
 		char origin[MAX_NUM_SIZE];
		char destination[MAX_NUM_SIZE];
		unsigned long connid;

		getstring("Device to divert from : ", origin, sizeof(origin));
		connid = getulong("ConnectionId: ");
		getstring("Device to divert to : ", destination, sizeof(destination));

		len = csta_request_DivertCall(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, DivertInfo::DIVERTINFO_DEFLECT,
												origin, connid, destination, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}
		}
		break;

	case 9: /* HoldCall */ {
		char num[MAX_NUM_SIZE];
		unsigned long connid;

		getstring("Device to hold : ", num, sizeof(num));

		connid = getulong("ConnectionId: ");
		len = csta_request_HoldCall(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, num, connid, 0, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 10: /* MakeCall */ {
 		char origin[MAX_NUM_SIZE];
		char destination[MAX_NUM_SIZE];

		getstring("Calling device : ", origin, sizeof(origin));
		getstring("Called device : ", destination, sizeof(destination));

		
		len = csta_request_MakeCall(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, origin, destination, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}
		}
		break;

	case 11: /* MakePredictiveCall */ {
 		char origin[MAX_NUM_SIZE];
		char destination[MAX_NUM_SIZE];

		getstring("Calling device : ", origin, sizeof(origin));
		getstring("Called device : ", destination, sizeof(destination));

		
		len = csta_request_MakePredictiveCall(enc_buff, sizeof(enc_buff), NEXT_REQUESTID,
										origin, destination, ALS_CALLDELIVERED, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}
		}
		break;

	case 12: /* ParkCall */ {
		char current[MAX_NUM_SIZE];
		char destination[MAX_NUM_SIZE];
		unsigned long connid;

		getstring("Current device : ", current, sizeof(current));

		connid = getulong("Active ConnectionId: ");
		getstring("Called device : ", destination, sizeof(destination));

		len = csta_request_ParkCall(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, current, connid, destination, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 13: /* QueryDevice */ {
		char device[MAX_NUM_SIZE];
		
		getstring("Device to query : ", device, sizeof(device));

		len = csta_request_QueryDevice(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, device, QDF_DEVICEINFO, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}
		}
		break;

	case 14: /* ReconnectCall */ {
		char device[MAX_NUM_SIZE];
		unsigned long active_connid;
		unsigned long held_connid;

		getstring("Device : ", device, sizeof(device));

		active_connid = getulong("Active ConnectionId (connection to clear): ");
		held_connid = getulong("Held ConnectionId: ");

		len = csta_request_ReconnectCall(enc_buff, sizeof(enc_buff), NEXT_REQUESTID,
											device, active_connid, held_connid, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 15: /* RetrieveCall */ {
		char device[MAX_NUM_SIZE];
		unsigned long connid;

		getstring("Device on hold : ", device, sizeof(device));

		connid = getulong("ConnectionId: ");
		len = csta_request_RetrieveCall(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, device, connid, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 16: /* SendDTMFTones */ {
		char device[MAX_NUM_SIZE];
		unsigned long connid;
		char tones[MAX_NUM_SIZE];

		getstring("Device : ", device, sizeof(device));
		connid = getulong("ConnectionId: ");
		getstring("Tones to Send : ", tones, sizeof(tones));

		len = csta_request_SendDTMFTones(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, device, connid, tones, 0, 0, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 17: /* SetDoNotDisturb */ {
		char device[MAX_NUM_SIZE];
		char value[MAX_NUM_SIZE];
		int state;

		getstring("Device : ", device, sizeof(device));
		getstring("State (on|off) : ", value, sizeof(value));

		if (strcasecmp(value, "on") == 0)
		{
			state = 1;
		}
		else
		{
			state = 0;
		}

		len = csta_request_SetDoNotDisturb(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, device, state, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 18: /* SetMessageWaiting */ {
		char device[MAX_NUM_SIZE];
		char value[MAX_NUM_SIZE];
		int state;

		getstring("Device : ", device, sizeof(device));
		getstring("State (on|off) : ", value, sizeof(value));

		if (strcasecmp(value, "on") == 0)
		{
			state = 1;
		}
		else
		{
			state = 0;
		}

		len = csta_request_SetMessageWaiting(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, device, state, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 19: /* SetForwarding */ {
		char device[MAX_NUM_SIZE];
		char value[MAX_NUM_SIZE];
		char destination[MAX_NUM_SIZE];
		int state;
		ForwardingType type;

		getstring("Device : ", device, sizeof(device));
		getstring("Type (immediate|busy|no_answer|imm_int|imm_ext|busy_int|busy_ext|noans_int|noans_ext) : ", value, sizeof(value));

		if (strcasecmp(value, "immediate") == 0)
		{
			type = FORWARDIMMEDIATEON;
		}
		else if (strcasecmp(value, "busy") == 0)
		{
			type = FORWARDBUSYON;
		}
		else if (strcasecmp(value, "no_answer") == 0)
		{
			type = FORWARDNOANSON;
		}
		else if (strcasecmp(value, "busy_int") == 0)
		{
			type = FORWARDBUSYINTON;
		}
		else if (strcasecmp(value, "busy_ext") == 0)
		{
			type = FORWARDBUSYEXTON;
		}
		else if (strcasecmp(value, "noans_int") == 0)
		{
			type = FORWARDNOANSINTON;
		}
		else if (strcasecmp(value, "noans_ext") == 0)
		{
			type = FORWARDNOANSEXTON;
		}
		else if (strcasecmp(value, "imm_int") == 0)
		{
			type = FORWARDIMMINTON;
		}
		else if (strcasecmp(value, "imm_ext") == 0)
		{
			type = FORWARDIMMEXTON;
		}

		getstring("State (on|off) : ", value, sizeof(value));
		if (strcasecmp(value, "on") == 0)
		{
			state = 1;
			getstring("Destination : ", destination, sizeof(destination));
		}
		else
		{
			destination[0] = 0;
			type = (ForwardingType ) (type + 1);
			state = 0;
		}
		
		len = csta_request_SetForwarding(enc_buff, sizeof(enc_buff), NEXT_REQUESTID,
											device, type, state, destination, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 20: /* SetAgentState */ {
		char device[MAX_NUM_SIZE];
		char value[MAX_NUM_SIZE];
		char agentid[MAX_NUM_SIZE];
		char password[MAX_NUM_SIZE];
		char acdgroup[MAX_NUM_SIZE];
		AgentParameter::AgentParameterChoiceId state;

		getstring("Device : ", device, sizeof(device));
		getstring("Type (logon|logoff|after_call_work|ready|not_ready|busy) : ", value, sizeof(value));

		if (strcasecmp(value, "logon") == 0)
		{
			state = AgentParameter::AGENTPARAMETER_AGENTLOGGEDIN;
			getstring("AgentId : ", agentid, sizeof(agentid));
			getstring("Password : ", password, sizeof(password));
			getstring("ACD Group : ", acdgroup, sizeof(acdgroup));
		}
		else if (strcasecmp(value, "logoff") == 0)
		{
			state = AgentParameter::AGENTPARAMETER_AGENTLOGGEDOUT;
			getstring("AgentId : ", agentid, sizeof(agentid));
			getstring("Password : ", password, sizeof(password));
			getstring("ACD Group : ", acdgroup, sizeof(acdgroup));
		}
		else if (strcasecmp(value, "after_call_work") == 0)
		{
			state = AgentParameter::AGENTPARAMETER_AGENTWORKINGAFTERCALL;
		}
		else if (strcasecmp(value, "ready") == 0)
		{
			state = AgentParameter::AGENTPARAMETER_AGENTREADY;
		}
		else if (strcasecmp(value, "not_ready") == 0)
		{
			state = AgentParameter::AGENTPARAMETER_AGENTNOTREADY;
		}
		else if (strcasecmp(value, "busy") == 0)
		{
			state = AgentParameter::AGENTPARAMETER_AGENTBUSY;
		}
		
		
		len = csta_request_SetAgentState(enc_buff, sizeof(enc_buff), NEXT_REQUESTID,
										device, state, agentid, acdgroup, password, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 21: /* EnableRouting */ {
		char device[MAX_NUM_SIZE];
		char value[MAX_NUM_SIZE];
		int state;

		getstring("Device : ", device, sizeof(device));
		getstring("State (on|off) : ", value, sizeof(value));

		if (strcasecmp(value, "on") == 0)
		{
			state = 1;
		}
		else
		{
			state = 0;
		}

		len = csta_request_EnableRouting(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, device, state, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 22: /* AutoAnswer */ {
		char device[MAX_NUM_SIZE];
		char value[MAX_NUM_SIZE];
		int state;

		getstring("Device : ", device, sizeof(device));
		getstring("State (on|off) : ", value, sizeof(value));

		if (strcasecmp(value, "on") == 0)
		{
			state = 1;
		}
		else
		{
			state = 0;
		}

		len = csta_request_AutoAnswer(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, device, state, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 23: /* MicrophoneMute */ {
		char device[MAX_NUM_SIZE];
		char value[MAX_NUM_SIZE];
		int state;

		getstring("Device : ", device, sizeof(device));
		getstring("State (on|off) : ", value, sizeof(value));

		if (strcasecmp(value, "on") == 0)
		{
			state = 1;
		}
		else
		{
			state = 0;
		}

		len = csta_request_MicrophoneMute(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, device, state, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 24: /* SpeakerMute */ {
		char device[MAX_NUM_SIZE];
		char value[MAX_NUM_SIZE];
		int state;

		getstring("Device : ", device, sizeof(device));
		getstring("State (on|off) : ", value, sizeof(value));

		if (strcasecmp(value, "on") == 0)
		{
			state = 1;
		}
		else
		{
			state = 0;
		}

		len = csta_request_SpeakerMute(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, device, state, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 25: /* SpeakerVolume */ {
		char device[MAX_NUM_SIZE];
		int level;

		getstring("Device : ", device, sizeof(device));
		level = getint("Level : ");

		len = csta_request_SpeakerVolume(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, device, level, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 26: /* SingleStepConference */ {
		char caller[MAX_NUM_SIZE];
		char destination[MAX_NUM_SIZE];
		unsigned long connid;
		char value[MAX_NUM_SIZE];
		ParticipationType participation;

		getstring("Calling device : ", caller, sizeof(caller));

		connid = getulong("Active ConnectionId: ");
		getstring("Called device : ", destination, sizeof(destination));
		getstring("Participation (silent|active) : ", value, sizeof(value));

		if (strcasecmp(value, "silent") == 0)
		{
			participation = PT_SILENT;
		}
		else
		{
			participation = PT_ACTIVE;
		}


		len = csta_request_SingleStepConference(enc_buff, sizeof(enc_buff), NEXT_REQUESTID,
										caller, connid, destination, participation, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 27: /* SingleStepTransfer */ {
		char caller[MAX_NUM_SIZE];
		char destination[MAX_NUM_SIZE];
		unsigned long connid;

		getstring("Calling device : ", caller, sizeof(caller));

		connid = getulong("Active ConnectionId: ");
		getstring("Called device : ", destination, sizeof(destination));


		len = csta_request_SingleStepTransfer(enc_buff, sizeof(enc_buff), NEXT_REQUESTID,
												caller, connid, destination, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;
		
	case 28: /* TransferCall */ {
		char device[MAX_NUM_SIZE];
		unsigned long active_connid;
		unsigned long held_connid;

		getstring("Device : ", device, sizeof(device));

		active_connid = getulong("Active ConnectionId: ");
		held_connid = getulong("Held ConnectionId: ");

		len = csta_request_TransferCall(enc_buff, sizeof(enc_buff), NEXT_REQUESTID,
											device, active_connid, held_connid, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;

	case 29: /* ChangeMonitorFilter */ {
		unsigned long monitorid;
		MonitorFilter monitorfilter = {0};

		monitorid = getulong("Monitor cross reference id: ");
		len = csta_request_ChangeMonitorFilter(enc_buff, sizeof(enc_buff), NEXT_REQUESTID, monitorid, &monitorfilter, NULL);
		if (tsp_write_socket(DEST_SOCKET, enc_buff, len) < 0)
        	{
                	perror("cstaclient.c: tsp_write_socket()");
		}

		}
		break;

#ifdef NOT_YET
	case 8: /* ACSEassociation */
		ACSEassociation();
		break;
#endif

	default:
		printf("Bad command !\n");
		break;
	}

	goto loop;
}


#ifdef NOT_YET
/* ACSE association management */
void ACSEassociation()
{
}

#endif

/* Poll STDIN, the TCP socket connected with the CSTA server (fdcsta)
 * and the UDP socket for clients (fdserver) */
void poll_input()
{
	fd_set readfds;
	fd_set writefds;
	
	FD_ZERO(&writefds);
	FD_ZERO(&readfds);
	FD_SET(fdcsta, &readfds);
	FD_SET(fdcsta, &writefds);

	if (select(fdcsta + 1, &readfds, &writefds, NULL, NULL) > 0)
	{
		if (FD_ISSET(fdcsta, &readfds))
		{
			dump(fdcsta);
		}
	}

}

/* Get a string from command line */
void getstring(char *prompt, char *buf, int size)
{
	printf("%s", prompt);
	fflush(stdout);

	poll_input();
	fgets(buf, size, stdin);

	if (buf[strlen(buf) - 1] == '\n')
		buf[strlen(buf) - 1] = '\0';
}


/* Get an integer from command line */
int getint(char *prompt)
{
	int val = 0;
	char buf[32];

	printf("%s", prompt);
	fflush(stdout);

	poll_input();
	fgets(buf, sizeof(buf), stdin);
	sscanf(buf, "%d", &val);

	return(val);
}

unsigned long
getulong(char *prompt)
{
	int val = 0;
	char buf[32];

	printf("%s", prompt);
	fflush(stdout);

	poll_input();
	fgets(buf, sizeof(buf), stdin);
	sscanf(buf, "%lu", &val);

	return(val);
}


/* Get an hexa number from command line */
int gethex(char *prompt)
{
	int val = 0;
	char buf[32];

	printf("%s", prompt);
	fflush(stdout);

	poll_input();
	fgets(buf, sizeof(buf), stdin);
	sscanf(buf, "%x", &val);

	return(val);
}


int
received_CALLEVENT_CALLCLEAREDEVENT(void *data)
{
	CallClearedEvent *event = ((CallEvent *) ((CSTAEventReportArgument *) data)->eventSpecificInfo->a.callEvent)->a.callClearedEvent;
	fprintf(logfile, "received_CALLEVENT_CALLCLEAREDEVENT");
	PrintMonitorCrossRefID(logfile, &((CSTAEventReportArgument *) data)->crossRefIdentifier, 0);
	PrintCallClearedEvent(logfile, event, 0);
	return 0;
}

int
received_CALLEVENT_CONFERENCEDEVENT(void *event)
{
	fprintf(logfile, "CONFERENCEDEVENT ");
	PrintMonitorCrossRefID(logfile, &((CSTAEventReportArgument *) event)->crossRefIdentifier, 0);
	return 0;
}

int
received_CALLEVENT_CONNECTIONCLEAREDEVENT(void *event)
{
	CallEvent *callevent  = ((CSTAEventReportArgument *) event)->eventSpecificInfo->a.callEvent;
	ConnectionClearedEvent *connclearedevent = callevent->a.connectionClearedEvent;

	fprintf(logfile, "received_CALLEVENT_CONNECTIONCLEAREDEVENT");
	PrintMonitorCrossRefID(logfile, &((CSTAEventReportArgument *) event)->crossRefIdentifier, 0);
	PrintConnectionClearedEvent(logfile, connclearedevent, 0);

	return 0;
}

int
received_CALLEVENT_DELIVEREDEVENT(void *event)
{
	CallEvent *callevent  = ((CSTAEventReportArgument *) event)->eventSpecificInfo->a.callEvent;
	DeliveredEvent *deliveredevent = callevent->a.deliveredEvent;

	fprintf(logfile, "received_CALLEVENT_DELIVEREDEVENT");
	PrintMonitorCrossRefID(logfile, &((CSTAEventReportArgument *) event)->crossRefIdentifier, 0);
	PrintDeliveredEvent(logfile, deliveredevent, 0);
	return 0;
}

int
received_CALLEVENT_DIVERTEDEVENT(void *event)
{
	CallEvent *callevent  = ((CSTAEventReportArgument *) event)->eventSpecificInfo->a.callEvent;
	DivertedEvent *divertedevent = callevent->a.divertedEvent;

	fprintf(logfile, "received_CALLEVENT_DIVERTEDEVENT");
	PrintMonitorCrossRefID(logfile, &((CSTAEventReportArgument *) event)->crossRefIdentifier, 0);
	PrintDivertedEvent(logfile, divertedevent, 0);
	return 0;
}

int
received_CALLEVENT_ESTABLISHEDEVENT(void *event)
{
	CallEvent *callevent  = ((CSTAEventReportArgument *) event)->eventSpecificInfo->a.callEvent;
	EstablishedEvent *establishedEvent = callevent->a.establishedEvent;

	fprintf(logfile, "received_CALLEVENT_ESTABLISHEDEVENT");
	PrintMonitorCrossRefID(logfile, &((CSTAEventReportArgument *) event)->crossRefIdentifier, 0);
	PrintEstablishedEvent(logfile, establishedEvent, 0);
	return 0;
}

int
received_CALLEVENT_FAILEDEVENT(void *event)
{
	fprintf(logfile, "FAILEDEVENT ");
	PrintMonitorCrossRefID(logfile, &((CSTAEventReportArgument *) event)->crossRefIdentifier, 0);
	return 0;
}

int
received_CALLEVENT_HELDEVENT(void *event)
{
	CallEvent *callevent  = ((CSTAEventReportArgument *) event)->eventSpecificInfo->a.callEvent;
	HeldEvent *heldEvent = callevent->a.heldEvent;

	fprintf(logfile, "received_CALLEVENT_HELDEVENT");
	PrintMonitorCrossRefID(logfile, &((CSTAEventReportArgument *) event)->crossRefIdentifier, 0);
	PrintHeldEvent(logfile, heldEvent, 0);

	return 0;
}

int
received_CALLEVENT_NETWORKREACHEDEVENT(void *event)
{
	fprintf(logfile, "NETWORKREACHEDEVENT ");
	PrintMonitorCrossRefID(logfile, &((CSTAEventReportArgument *) event)->crossRefIdentifier, 0);
	return 0;
}

int
received_CALLEVENT_ORIGINATEDEVENT(void *data)
{
	OriginatedEvent *event = ((CallEvent *) ((CSTAEventReportArgument *) data)->eventSpecificInfo->a.callEvent)->a.originatedEvent;


	fprintf(logfile, "received_CALLEVENT_ORIGINATEDEVENT");
	PrintMonitorCrossRefID(logfile, &((CSTAEventReportArgument *) data)->crossRefIdentifier, 0);
	PrintOriginatedEvent(logfile, event, 0);
	return 0;
}

int
received_CALLEVENT_QUEUEDEVENT(void *event)
{
	fprintf(logfile, "QUEUEDEVENT ");
	PrintMonitorCrossRefID(logfile, &((CSTAEventReportArgument *) event)->crossRefIdentifier, 0);
	return 0;
}

int
received_CALLEVENT_RETRIEVEDEVENT(void *event)
{
	fprintf(logfile, "RETRIEVEDEVENT ");
	PrintMonitorCrossRefID(logfile, &((CSTAEventReportArgument *) event)->crossRefIdentifier, 0);
	return 0;
}

int
received_CALLEVENT_SERVICEINITIATEDEVENT(void *data)
{
	ServiceInitiatedEvent *event = ((CallEvent *) ((CSTAEventReportArgument *) data)->eventSpecificInfo->a.callEvent)->a.serviceInitiatedEvent;


	fprintf(logfile, "received_CALLEVENT_SERVICEINITIATEDEVENT");
	PrintMonitorCrossRefID(logfile, &((CSTAEventReportArgument *) data)->crossRefIdentifier, 0);
	PrintServiceInitiatedEvent(logfile, event, 0);
	return 0;
}

int
received_CALLEVENT_TRANSFEREDEVENT(void *event)
{
	fprintf(logfile, "TRANSFEREDEVENT ");
	PrintMonitorCrossRefID(logfile, &((CSTAEventReportArgument *) event)->crossRefIdentifier, 0);
	return 0;
}


int
received_FEATUREEVENT_AUTOANSWEREVENT(void *event)
{
	return 0;
}

int
received_FEATUREEVENT_CALLINFORMATIONEVENT(void *event)
{
	return 0;
}

int
received_FEATUREEVENT_DONOTDISTURBEVENT(void *event)
{
	return 0;
}

int
received_FEATUREEVENT_FORWARDINGEVENT(void *event)
{
	FeatureEvent  *featureevent = ((CSTAEventReportArgument *) event)->eventSpecificInfo->a.featureEvent;
	ForwardingEvent *forwardingevent = featureevent->a.forwardingEvent;

	tm = time(NULL);
	if (forwardingevent->forwardingInformation->forwardingType == 0) {
		fprintf(logfile, "\n\nNew forward on %s", ctime(&tm));
	} else if (forwardingevent->forwardingInformation->forwardingType == 1) {
		fprintf(logfile, "\n\nEnd of forward on %s", ctime(&tm));
	}

	fprintf(logfile, "\nFORWARDINGEVENT");

	fprintf(logfile, "\n-- forwardingType -- ");
	PrintForwardingType(logfile, (AsnInt *) &forwardingevent->forwardingInformation->forwardingType, 0);

	fprintf(logfile, "\n-- forwardedDeviceNumber -- ");
	PrintNumberDigits(logfile, &forwardingevent->forwardingInformation->forwardDN, 0);

	fprintf(logfile, "\n-- forwardedDevice -- ");
	if (forwardingevent->device->choiceId == SubjectDeviceID::SUBJECTDEVICEID_DEVICEIDENTIFIER &&
    	forwardingevent->device->a.deviceIdentifier->choiceId == ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER &&
	forwardingevent->device->a.deviceIdentifier->a.deviceIdentifier->choiceId == DeviceID::DEVICEID_DIALINGNUMBER)
		PrintNumberDigits(logfile, forwardingevent->device->a.deviceIdentifier->a.deviceIdentifier->a.dialingNumber, 0);
	else
		fprintf(logfile, "''H -- \"\" --");

	if (forwardingevent->forwardedTo != NULL) {
		fprintf(logfile, "\n-- forwardedToDevice -- ");

		if (forwardingevent->forwardedTo->choiceId == SubjectDeviceID::SUBJECTDEVICEID_DEVICEIDENTIFIER &&
    		forwardingevent->forwardedTo->a.deviceIdentifier->choiceId == ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER &&
		forwardingevent->forwardedTo->a.deviceIdentifier->a.deviceIdentifier->choiceId == DeviceID::DEVICEID_DIALINGNUMBER)
			PrintNumberDigits(logfile, forwardingevent->forwardedTo->a.deviceIdentifier->a.deviceIdentifier->a.dialingNumber, 0);
		else
			fprintf(logfile, "''H -- \"\" --");
	}

	fprintf(logfile, "\n\n--------------------------------------------------------------------------------\n");
	return 0;
}

int
received_FEATUREEVENT_MESSAGEWAITINGEVENT(void *event)
{
	return 0;
}

int
received_FEATUREEVENT_MICROPHONEMUTEEVENT(void *event)
{
	return 0;
}

int
received_FEATUREEVENT_SPEAKERMUTEEVENT(void *event)
{
	return 0;
}

int
received_FEATUREEVENT_SPEAKERVOLUMEEVENT(void *event)
{
	return 0;
}

int
received_AGENTSTATEEVENT_AGENTBUSYEVENT(void *event)
{
	AgentBusyEvent *abe;

	fprintf(logfile, "received_AGENTSTATEEVENT_AGENTBUSYEVENT");
	abe = (AgentBusyEvent *) ((CSTAEventReportArgument *) event)->eventSpecificInfo->a.agentStateEvent->a.agentBusyEvent;
	PrintAgentBusyEvent(logfile, abe, 0);
	return 0;
}

int
received_AGENTSTATEEVENT_LOGGEDONEVENT(void *event)
{
	LoggedOnEvent *loe;

	fprintf(logfile, "received_AGENTSTATEEVENT_LOGGEDONEVENT");
	loe = (LoggedOnEvent *) ((CSTAEventReportArgument *) event)->eventSpecificInfo->a.agentStateEvent->a.loggedOnEvent;
	PrintLoggedOnEvent(logfile, loe, 0);
	return 0;
}

int
received_AGENTSTATEEVENT_LOGGEDOFFEVENT(void *event)
{
	LoggedOffEvent *loe;

	fprintf(logfile, "received_AGENTSTATEEVENT_LOGGEDOFFEVENT");
	loe = (LoggedOffEvent *) ((CSTAEventReportArgument *) event)->eventSpecificInfo->a.agentStateEvent->a.loggedOffEvent;
	PrintLoggedOffEvent(logfile, loe, 0);
	return 0;
}

int
received_AGENTSTATEEVENT_NOTREADYEVENT(void *event)
{
	NotReadyEvent *nre;

	fprintf(logfile, "received_AGENTSTATEEVENT_AGENTBUSYEVENT");
	nre = (NotReadyEvent *) ((CSTAEventReportArgument *) event)->eventSpecificInfo->a.agentStateEvent->a.notReadyEvent;
	PrintNotReadyEvent(logfile, nre, 0);
	return 0;
}

int
received_AGENTSTATEEVENT_READYEVENT(void *event)
{
	ReadyEvent *re;

	fprintf(logfile, "received_AGENTSTATEEVENT_AGENTBUSYEVENT");
	re = (ReadyEvent *) ((CSTAEventReportArgument *) event)->eventSpecificInfo->a.agentStateEvent->a.readyEvent;
	PrintReadyEvent(logfile, re, 0);
	return 0;
}

int
received_AGENTSTATEEVENT_WORKINGAFTERCALLEVENT(void *event)
{
	WorkingAfterCallEvent *wace;

	fprintf(logfile, "received_AGENTSTATEEVENT_AGENTBUSYEVENT");
	wace = (WorkingAfterCallEvent *)
				((CSTAEventReportArgument *) event)->eventSpecificInfo->a.agentStateEvent->a.workingAfterCallEvent;
	PrintWorkingAfterCallEvent(logfile, wace, 0);
	return 0;
}


int
received_MAINTENANCEEVENT_BACKINSERVICEEVENT(void *event)
{
	return 0;
}

int
received_MAINTENANCEEVENT_OUTOFSERVICEEVENT(void *event)
{
	return 0;
}


int
received_VOICEUNITEVENT_PLAYEVENT(void *event)
{
	return 0;
}

int
received_VOICEUNITEVENT_RECORDEVENT(void *event)
{
	return 0;
}

int
received_VOICEUNITEVENT_REVIEWEVENT(void *event)
{
	return 0;
}

int
received_VOICEUNITEVENT_STOPEVENT(void *event)
{
	return 0;
}

int
received_VOICEUNITEVENT_SUSPENDPLAYEVENT(void *event)
{
	return 0;
}

int
received_VOICEUNITEVENT_SUSPENDRECORDEVENT(void *event)
{
	return 0;
}

int
received_VOICEUNITEVENT_VOICEATTRIBUTESCHANGEEVENT(void *event)
{
	return 0;
}

int
received_roiv_ASSOCIATEDATA(void *data)
{
	fprintf(logfile, "received_roiv_ASSOCIATEDATA\n");
	return 0;
}

int
received_roiv_ROUTEREQUEST(void *data)
{
	fprintf(logfile, "received_roiv_ROUTEREQUEST\n");
	return 0;
}

int
received_roiv_REROUTEREQUEST(void *data)
{
	fprintf(logfile, "received_roiv_REROUTEREQUEST\n");
	return 0;
}

int
received_roiv_ROUTESELECTREQUEST(void *data)
{
	fprintf(logfile, "received_roiv_ROUTESELECTREQUEST\n");
	return 0;
}

int
received_roiv_ROUTEUSEDREQUEST(void *data)
{
	fprintf(logfile, "received_roiv_ROUTEUSEDREQUEST\n");
	return 0;
}

int
received_roiv_ROUTEENDREQUEST(void *data)
{
	fprintf(logfile, "received_roiv_ROUTEENDREQUEST\n");
	return 0;
}


int
received_roiv_ESCAPESERVICE(void *data)
{
	fprintf(logfile, "received_roiv_ESCAPESERVICE\n");
	return 0;
}

int
received_roiv_SYSTEMSTATUS(void *data)
{
	SystemStatusArgument *event = (SystemStatusArgument *) data;

	fprintf(logfile, "received_roiv_SYSTEMSTATUS\n");

	switch  (event->choiceId)
	{
	case SystemStatusArgument::SYSTEMSTATUSARGUMENT_SYSTEMSTATUS:
		fprintf(logfile, "\n\nSystem status = %d", event->a.systemStatus);
		fprintf(logfile, "\n\n--------------------------------------------------------------------------------\n");
		break;
	case SystemStatusArgument::SYSTEMSTATUSARGUMENT_SYSTEMSTATUSARGUMENTSEQ:
		break;
	}

	return 0;
}

int
received_roiv_SNAPSHOTDEVICE(void *data)
{
	fprintf(logfile, "received_roiv_SNAPSHOTDEVICE\n");
	return 0;
}

int
received_roiv_STARTDATAPATH(void *data)
{
	fprintf(logfile, "received_roiv_STARTDATAPATH\n");
	return 0;
}

int
received_roiv_STOPDATAPATH(void *data)
{
	fprintf(logfile, "received_roiv_STOPDATAPATH\n");
	return 0;
}

int
received_roiv_SENDDATA(void *data)
{
	fprintf(logfile, "received_roiv_SENDDATA\n");
	return 0;
}

int
received_roiv_SENDMULTICASTDATA(void *data)
{
	fprintf(logfile, "received_roiv_SENDMULTICASTDATA\n");
	return 0;
}

int
received_roiv_SENDBROADCASTDATA(void *data)
{
	fprintf(logfile, "received_roiv_SENDBROADCASTDATA\n");
	return 0;
}

int
received_roiv_SUSPENDDATAPATH(void *data)
{
	fprintf(logfile, "received_roiv_SUSPENDDATAPATH\n");
	return 0;
}

int
received_roiv_DATAPATHSUSPENDED(void *data)
{
	fprintf(logfile, "received_roiv_DATAPATHSUSPENDED\n");
	return 0;
}

int
received_roiv_RESUMEDATAPATH(void *data)
{
	fprintf(logfile, "received_roiv_RESUMEDATAPATH\n");
	return 0;
}

int
received_roiv_DATAPATHRESUMED(void *data)
{
	fprintf(logfile, "received_roiv_DATAPATHRESUMED\n");
	return 0;
}

int
received_roiv_FASTDATA(void *data)
{
	fprintf(logfile, "received_roiv_FASTDATA\n");
	return 0;
}


int
received_roiv_CONCATENATEMESSAGE(void *data)
{
	fprintf(logfile, "received_roiv_CONCATENATEMESSAGE\n");
	return 0;
}

int
received_roiv_DELETEMESSAGE(void *data)
{
	fprintf(logfile, "received_roiv_DELETEMESSAGE\n");
	return 0;
}

int
received_roiv_PLAYMESSAGE(void *data)
{
	fprintf(logfile, "received_roiv_PLAYMESSAGE\n");
	return 0;
}

int
received_roiv_QUERYVOICEATTRIBUTE(void *data)
{
	fprintf(logfile, "received_roiv_QUERYVOICEATTRIBUTE\n");
	return 0;
}

int
received_roiv_RECORDMESSAGE(void *data)
{
	fprintf(logfile, "received_roiv_RECORDMESSAGE\n");
	return 0;
}

int
received_roiv_REPOSITION(void *data)
{
	fprintf(logfile, "received_roiv_REPOSITION\n");
	return 0;
}

int
received_roiv_RESUME(void *data)
{
	fprintf(logfile, "received_roiv_RESUME\n");
	return 0;
}

int
received_roiv_REVIEW(void *data)
{
	fprintf(logfile, "received_roiv_REVIEW\n");
	return 0;
}

int
received_roiv_SETVOICEATTRIBUTE(void *data)
{
	fprintf(logfile, "received_roiv_SETVOICEATTRIBUTE\n");
	return 0;
}

int
received_roiv_STOP(void *data)
{
	fprintf(logfile, "received_roiv_STOP\n");
	return 0;
}

int
received_roiv_SUSPEND(void *data)
{
	fprintf(logfile, "received_roiv_SUSPEND\n");
	return 0;
}

int
received_roiv_SYNTHESIZEMESSAGE(void *data)
{
	fprintf(logfile, "received_roiv_SYNTHESIZEMESSAGE\n");
	return 0;
}

/*
 *  Reponse handlers
 */

int
received_rors_ALTERNATECALL(void *data)
{
	fprintf(logfile, "received_rors_ALTERNATECALL\n");
	PrintAlternateCallResult(logfile, (AlternateCallResult *) data, 0);
	return 0;
}

int
received_rors_ANSWERCALL(void *data)
{
	fprintf(logfile, "received_rors_ANSWERCALL\n");
	PrintAnswerCallResult(logfile, (AnswerCallResult *) data, 0);
	return 0;
}

int
received_rors_ASSOCIATEDATA(void *data)
{
	fprintf(logfile, "received_rors_ASSOCIATEDATA\n");
	PrintAssociateDataResult(logfile, (AssociateDataResult *) data, 0);
	return 0;
}

int
received_rors_CALLCOMPLETION(void *data)
{
	fprintf(logfile, "received_rors_CALLCOMPLETION\n");
	PrintCallCompletionResult(logfile, (CallCompletionResult *) data, 0);
	return 0;
}

int
received_rors_CLEARCALL(void *data)
{
	fprintf(logfile, "received_rors_CLEARCALL\n");
	PrintClearCallResult(logfile, (ClearCallResult *) data, 0);
	return 0;
}

int
received_rors_CLEARCONNECTION(void *data)
{
	fprintf(logfile, "received_rors_CLEARCONNECTION\n");
	PrintClearConnectionResult(logfile, (ClearConnectionResult *) data, 0);
	return 0;
}

int
received_rors_CONFERENCECALL(void *data)
{
	fprintf(logfile, "received_rors_CONFERENCECALL\n");
	PrintConferenceCallResult(logfile, (ConferenceCallResult *) data, 0);
	return 0;
}

int
received_rors_CONSULTATIONCALL(void *data)
{
	fprintf(logfile, "received_rors_CONSULTATIONCALL\n");
	PrintConsultationCallResult(logfile, (ConsultationCallResult *) data, 0);
	return 0;
}

int
received_rors_DIVERTCALL(void *data)
{
	fprintf(logfile, "received_rors_DIVERTCALL\n");
	PrintDivertCallResult(logfile, (DivertCallResult *) data, 0);
	return 0;
}

int
received_rors_HOLDCALL(void *data)
{
	fprintf(logfile, "received_rors_HOLDCALL\n");
	PrintHoldCallResult(logfile, (HoldCallResult *) data, 0);
	return 0;
}

int
received_rors_MAKECALL(void *data)
{
	fprintf(logfile, "received_rors_MAKECALL\n");
	PrintMakeCallResult(logfile, (MakeCallResult *) data, 0);
	return 0;
}

int
received_rors_MAKEPREDICTIVECALL(void *data)
{
	fprintf(logfile, "received_rors_MAKEPREDICTIVECALL\n");
	PrintMakePredictiveCallResult(logfile, (MakePredictiveCallResult *) data, 0);
	return 0;
}

int
received_rors_PARKCALL(void *data)
{
	fprintf(logfile, "received_rors_PARKCALL\n");
	PrintParkCallResult(logfile, (ParkCallResult *) data, 0);
	return 0;
}

int
received_rors_QUERYDEVICE(void *data)
{
	fprintf(logfile, "received_rors_QUERYDEVICE\n");
	PrintQueryDeviceResult(logfile, (QueryDeviceResult *) data, 0);
	return 0;
}

int
received_rors_RECONNECTCALL(void *data)
{
	fprintf(logfile, "received_rors_RECONNECTCALL\n");
	PrintReconnectCallResult(logfile, (ReconnectCallResult *) data, 0);
	return 0;
}

int
received_rors_RETRIEVECALL(void *data)
{
	fprintf(logfile, "received_rors_RETRIEVECALL\n");
	PrintRetrieveCallResult(logfile, (RetrieveCallResult *) data, 0);
	return 0;
}

int
received_rors_SENDDTMFTONES(void *data)
{
	fprintf(logfile, "received_rors_SENDDTMFTONES\n");
	PrintSendDTMFTonesResult(logfile, (SendDTMFTonesResult *) data, 0);
	return 0;
}

int
received_rors_SETFEATURE(void *data)
{
	fprintf(logfile, "received_rors_SETFEATURE\n");
	PrintSetFeatureResult(logfile, (SetFeatureResult *) data, 0);
	return 0;
}

int
received_rors_SINGLESTEPCONF(void *data)
{
	fprintf(logfile, "received_rors_SINGLESTEPCONF\n");
	PrintSingleStepConfResult(logfile, (SingleStepConfResult *) data, 0);
	return 0;
}

int
received_rors_SINGLESTEPTRANS(void *data)
{
	fprintf(logfile, "received_rors_SINGLESTEPTRANS\n");
	PrintSingleStepTransResult(logfile, (SingleStepTransResult *) data, 0);
	return 0;
}

int
received_rors_TRANSFERCALL(void *data)
{
	fprintf(logfile, "received_rors_TRANSFERCALL\n");
	PrintTransferCallResult(logfile, (TransferCallResult *) data, 0);
	return 0;
}


int
received_rors_ROUTEREQUEST(void *data)
{
	return 0;
}

int
received_rors_REROUTEREQUEST(void *data)
{
	return 0;
}

int
received_rors_ROUTESELECTREQUEST(void *data)
{
	return 0;
}

int
received_rors_ROUTEUSEDREQUEST(void *data)
{
	return 0;
}

int
received_rors_ROUTEENDREQUEST(void *data)
{
	return 0;
}


int
received_rors_ESCAPESERVICE(void *data)
{
	return 0;
}

int
received_rors_SYSTEMSTATUS(void *data)
{
	return 0;
}


int
received_rors_MONITORSTART(void *data)
{
	fprintf(logfile, "received_rors_MONITORSTART\n");
	PrintMonitorStartResult(logfile, (MonitorStartResult *) data, 0);
	return 0;
}

int
received_rors_CHANGEMONITORFILTER(void *data)
{
	fprintf(logfile, "received_rors_CHANGEMONITORFILTER\n");
	PrintChangeMonitorFilterResult(logfile, (ChangeMonitorFilterResult *) data, 0);
	return 0;
}

int
received_rors_MONITORSTOP(void *data)
{
	fprintf(logfile, "received_rors_MONITORSTOP\n");
	PrintMonitorStopResult(logfile, (MonitorStopResult *) data, 0);
	return 0;
}

int
received_rors_SNAPSHOTDEVICE(void *data)
{
	return 0;
}

int
received_rors_SNAPSHOTCALL(void *data)
{
	return 0;
}


int
received_rors_STARTDATAPATH(void *data)
{
	return 0;
}

int
received_rors_STOPDATAPATH(void *data)
{
	return 0;
}

int
received_rors_SENDDATA(void *data)
{
	return 0;
}

int
received_rors_SENDMULTICASTDATA(void *data)
{
	return 0;
}

int
received_rors_SENDBROADCASTDATA(void *data)
{
	return 0;
}

int
received_rors_SUSPENDDATAPATH(void *data)
{
	return 0;
}

int
received_rors_DATAPATHSUSPENDED(void *data)
{
	return 0;
}

int
received_rors_RESUMEDATAPATH(void *data)
{
	return 0;
}

int
received_rors_DATAPATHRESUMED(void *data)
{
	return 0;
}

int
received_rors_FASTDATA(void *data)
{
	return 0;
}


int
received_rors_CONCATENATEMESSAGE(void *data)
{
	return 0;
}

int
received_rors_DELETEMESSAGE(void *data)
{
	return 0;
}

int
received_rors_PLAYMESSAGE(void *data)
{
	return 0;
}

int
received_rors_QUERYVOICEATTRIBUTE(void *data)
{
	return 0;
}

int
received_rors_RECORDMESSAGE(void *data)
{
	return 0;
}

int
received_rors_REPOSITION(void *data)
{
	return 0;
}

int
received_rors_RESUME(void *data)
{
	return 0;
}

int
received_rors_REVIEW(void *data)
{
	return 0;
}

int
received_rors_SETVOICEATTRIBUTE(void *data)
{
	return 0;
}

int
received_rors_STOP(void *data)
{
	return 0;
}

int
received_rors_SUSPEND(void *data)
{
	return 0;
}

int
received_rors_SYNTHESIZEMESSAGE(void *data)
{
	return 0;
}


message_handler
find_handler(long mt, handler_entry *table)
{
	handler_entry *entry;

	if (table)
	{
		for (entry = table ; entry->message_type != -1 ; entry++)
		{
			if (entry->message_type == mt)
			{
				return entry->handler;
			}
		}
	}

	return NULL;
}

static inline int
received_ROSEAPDUS_ROIV_APDU(ROSEapdus *pdu)
{
	int status = -1;
	ROIVapdu *roivapdu = pdu->a.roiv_apdu;
	void *data;
	handler_entry *table = 0;
	message_handler handler;
	long subtype = -1;


	switch (roivapdu->operation_value)
	{

	/*
	 *  Event report service
	 */

	case OV_CSTAEVENTREPORT:

		data =  (roivapdu->argument.value);
		table = Event_report_service_handlers;
		subtype = (((CSTAEventReportArgument *) data)->eventSpecificInfo->choiceId << 16) + 
				 ((CallEvent *) ((CSTAEventReportArgument *) data)->eventSpecificInfo->a.callEvent)->choiceId;
		break;


	/*
	 *  Bidirectional services
	 */

	case OV_ESCAPESERVICE:
	case OV_SYSTEMSTATUS:

		data =  (roivapdu->argument.value);
		table = Bidirectional_services_request_handlers;
		subtype = roivapdu->operation_value;
		break;

	}


	if (table)
	{
		handler = find_handler(subtype, table);
		if (handler)
		{
			status = handler((void *) data);
		}
	}

	return status;
}

static inline int
received_ROSEAPDUS_RORS_APDU(ROSEapdus *pdu)
{
	int status = -1;
	RORSapdu *rorsapdu = pdu->a.rors_apdu;
	void *data;
	handler_entry *table = 0;
	message_handler handler;
	long subtype = -1;


	if (rorsapdu->rORSapduSeq)
	{
		switch (rorsapdu->rORSapduSeq->operation_value)
		{

		/*
		 *  Switching function services
		 */

		case OV_ALTERNATECALL:
		case OV_ANSWERCALL:
		case OV_ASSOCIATEDATA:
		case OV_CALLCOMPLETION:
		case OV_CLEARCALL:
		case OV_CLEARCONNECTION:
		case OV_CONFERENCECALL:
		case OV_CONSULTATIONCALL:
		case OV_DIVERTCALL:
		case OV_HOLDCALL:
		case OV_MAKECALL:
		case OV_MAKEPREDICTIVECALL:
		case OV_PARKCALL:
		case OV_QUERYDEVICE:
		case OV_RECONNECTCALL:
		case OV_RETRIEVECALL:
		case OV_SENDDTMFTONES:
		case OV_SETFEATURE:
		case OV_SINGLESTEPCONF:
		case OV_SINGLESTEPTRANS:
		case OV_TRANSFERCALL:

			data =  (rorsapdu->rORSapduSeq->result.value);
			table = Switching_function_service_response_handlers;
			subtype = rorsapdu->rORSapduSeq->operation_value;
			break;

		/*
		 *  Computing function services
		 */

		case OV_ROUTEREQUEST:
		case OV_REROUTEREQUEST:
		case OV_ROUTESELECTREQUEST:
		case OV_ROUTEUSEDREQUEST:
		case OV_ROUTEENDREQUEST:

			data =  (rorsapdu->rORSapduSeq->result.value);
			table = Computing_function_services_response_handlers;
			subtype = rorsapdu->rORSapduSeq->operation_value;
			break;


		/*
		 *  Bidirectional services
		 */

		case OV_ESCAPESERVICE:
		case OV_SYSTEMSTATUS:

			data =  (rorsapdu->rORSapduSeq->result.value);
			table = Bidirectional_services_response_handlers;
			subtype = rorsapdu->rORSapduSeq->operation_value;
			break;

		/*
		 *  Status reporting services
		 */

		case OV_MONITORSTART:
		case OV_CHANGEMONITORFILTER:
		case OV_MONITORSTOP:
		case OV_SNAPSHOTDEVICE:
		case OV_SNAPSHOTCALL:

			data =  (rorsapdu->rORSapduSeq->result.value);
			table = Status_reporting_services_response_handlers;
			subtype = rorsapdu->rORSapduSeq->operation_value;
			break;


		/*
		 *  Input/output services
		 */

		case OV_STARTDATAPATH:
		case OV_STOPDATAPATH:
		case OV_SENDDATA:
		case OV_SENDMULTICASTDATA:
		case OV_SENDBROADCASTDATA:
		case OV_SUSPENDDATAPATH:
		case OV_DATAPATHSUSPENDED:
		case OV_RESUMEDATAPATH:
		case OV_DATAPATHRESUMED:
		case OV_FASTDATA:

			data =  (rorsapdu->rORSapduSeq->result.value);
			table = Input_output_services_response_handlers;
			subtype = rorsapdu->rORSapduSeq->operation_value;
			break;

		/*
		 *  Voice unit services
		 */

		case OV_CONCATENATEMESSAGE:
		case OV_DELETEMESSAGE:
		case OV_PLAYMESSAGE:
		case OV_QUERYVOICEATTRIBUTE:
		case OV_RECORDMESSAGE:
		case OV_REPOSITION:
		case OV_RESUME:
		case OV_REVIEW:
		case OV_SETVOICEATTRIBUTE:
		case OV_STOP:
		case OV_SUSPEND:
		case OV_SYNTHESIZEMESSAGE:

			data =  (rorsapdu->rORSapduSeq->result.value);
			table = Voice_unit_services_response_handlers;
			subtype = rorsapdu->rORSapduSeq->operation_value;
			break;

		}

		if (table)
		{
			handler = find_handler(subtype, table);
			if (handler)
			{
				status = handler((void *) data);
			}
		}
	}

	return status;
}

static inline int
received_ROSEAPDUS_ROER_APDU(ROSEapdus *pdu)
{
	ROERapdu *roerapdu = pdu->a.roer_apdu;

	fprintf(logfile, "\nreceived_ROSEAPDUS_ROER_APDU");
	PrintROERapdu(logfile, roerapdu, 0);

	return 0;
}

static inline int
received_ROSEAPDUS_RORJ_APDU(ROSEapdus *pdu)
{
	RORJapdu *rorjapdu = pdu->a.rorj_apdu;

	fprintf(logfile, "\nreceived_ROSEAPDUS_RORJ_APDU");
	PrintRORJapdu(logfile, rorjapdu, 0);

	return 0;
}

int
dump(int fd) 
{
	static char buf[8192];
	int error, size;
	ROSEapdus *pdu;

	tm = time(NULL);

	size = tsp_read_socket(fd, buf, sizeof(buf));
	if (size < 0)
	{
		perror("cstaclient.c: dump(): tsp_read_socket()");
		return(-1);
	}

#ifdef DEBUG_CSTATEST
	logdump(LOG_DEBUG, buf, size);
	fprintf(logfile, "\n");
#endif

	pdu = csta_decode_message(buf, size);

	if (pdu)
	{
		switch (pdu->choiceId)
		{
		case ROSEapdus::ROSEAPDUS_ROIV_APDU:
			received_ROSEAPDUS_ROIV_APDU(pdu);
			break;

		case ROSEapdus::ROSEAPDUS_RORS_APDU:
			received_ROSEAPDUS_RORS_APDU(pdu);
			break;

		case ROSEapdus::ROSEAPDUS_ROER_APDU:
			received_ROSEAPDUS_ROER_APDU(pdu);
			break;

		case ROSEapdus::ROSEAPDUS_RORJ_APDU:
			received_ROSEAPDUS_RORJ_APDU(pdu);
			break;
		}

		csta_release_memory();
	}

#ifdef DEBUG_CSTATEST
	fprintf(logfile, "\n\n--------------------------------------------------------------------------------\n\n");
#endif

	return(0);
}

/* Handler for exit signals */
#ifndef WIN32
void
end(int signo)
{
	printf("\n\nEnd of cstaclient\n");

	/* Close Log file */
	tm = time(NULL);
	fprintf(logfile, "\n\nStopped on %s\n", ctime(&tm));
	fclose(logfile);

	/* Close socket descriptors */
	tsp_close_socket(fdcsta);

	/* Free the NibbleMemory slice */
	ShutdownNibbleMem();

	exit(0);
}
#endif
