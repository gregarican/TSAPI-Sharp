/*
 * cstaclient.h : csta test client application
 *
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 * 
 * Based on work from :
 * Julien Gaulmin <julien.gaulmin@fr.alcove.com>
 * Francisco Espinoza Junior and Philippe de M. Sevestre
 * Dedalus Engenharia S/C Ltda - Convenio GMK/FDTE
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */

#ifdef NOT_YET
void ACSEassociation();
#endif


void poll_input();
void getstring(char *prompt, char *buf, int size);
int getint(char *prompt);
int gethex(char *prompt);
int dump(int);
void end(int);


typedef int (*message_handler)(void *);
typedef struct
{
	long message_type;
	message_handler handler;
} handler_entry;

int received_CALLEVENT_CALLCLEAREDEVENT(void *);
int received_CALLEVENT_CONFERENCEDEVENT(void *);
int received_CALLEVENT_CONNECTIONCLEAREDEVENT(void *);
int received_CALLEVENT_DELIVEREDEVENT(void *);
int received_CALLEVENT_DIVERTEDEVENT(void *);
int received_CALLEVENT_ESTABLISHEDEVENT(void *);
int received_CALLEVENT_FAILEDEVENT(void *);
int received_CALLEVENT_HELDEVENT(void *);
int received_CALLEVENT_NETWORKREACHEDEVENT(void *);
int received_CALLEVENT_ORIGINATEDEVENT(void *);
int received_CALLEVENT_QUEUEDEVENT(void *);
int received_CALLEVENT_RETRIEVEDEVENT(void *);
int received_CALLEVENT_SERVICEINITIATEDEVENT(void *);
int received_CALLEVENT_TRANSFEREDEVENT(void *);

int received_FEATUREEVENT_AUTOANSWEREVENT(void *);
int received_FEATUREEVENT_CALLINFORMATIONEVENT(void *);
int received_FEATUREEVENT_DONOTDISTURBEVENT(void *);
int received_FEATUREEVENT_FORWARDINGEVENT(void *);
int received_FEATUREEVENT_MESSAGEWAITINGEVENT(void *);
int received_FEATUREEVENT_MICROPHONEMUTEEVENT(void *);
int received_FEATUREEVENT_SPEAKERMUTEEVENT(void *);
int received_FEATUREEVENT_SPEAKERVOLUMEEVENT(void *);

int received_AGENTSTATEEVENT_AGENTBUSYEVENT(void *);
int received_AGENTSTATEEVENT_LOGGEDONEVENT(void *);
int received_AGENTSTATEEVENT_LOGGEDOFFEVENT(void *);
int received_AGENTSTATEEVENT_NOTREADYEVENT(void *);
int received_AGENTSTATEEVENT_READYEVENT(void *);
int received_AGENTSTATEEVENT_WORKINGAFTERCALLEVENT(void *);

int received_MAINTENANCEEVENT_BACKINSERVICEEVENT(void *);
int received_MAINTENANCEEVENT_OUTOFSERVICEEVENT(void *);

int received_VOICEUNITEVENT_PLAYEVENT(void *);
int received_VOICEUNITEVENT_RECORDEVENT(void *);
int received_VOICEUNITEVENT_REVIEWEVENT(void *);
int received_VOICEUNITEVENT_STOPEVENT(void *);
int received_VOICEUNITEVENT_SUSPENDPLAYEVENT(void *);
int received_VOICEUNITEVENT_SUSPENDRECORDEVENT(void *);
int received_VOICEUNITEVENT_VOICEATTRIBUTESCHANGEEVENT(void *);

int received_roiv_ESCAPESERVICE(void *);
int received_roiv_SYSTEMSTATUS(void *);

int received_rors_ALTERNATECALL(void *);
int received_rors_ANSWERCALL(void *);
int received_rors_ASSOCIATEDATA(void *);
int received_rors_CALLCOMPLETION(void *);
int received_rors_CLEARCALL(void *);
int received_rors_CLEARCONNECTION(void *);
int received_rors_CONFERENCECALL(void *);
int received_rors_CONSULTATIONCALL(void *);
int received_rors_DIVERTCALL(void *);
int received_rors_HOLDCALL(void *);
int received_rors_MAKECALL(void *);
int received_rors_MAKEPREDICTIVECALL(void *);
int received_rors_PARKCALL(void *);
int received_rors_QUERYDEVICE(void *);
int received_rors_RECONNECTCALL(void *);
int received_rors_RETRIEVECALL(void *);
int received_rors_SENDDTMFTONES(void *);
int received_rors_SETFEATURE(void *);
int received_rors_SINGLESTEPCONF(void *);
int received_rors_SINGLESTEPTRANS(void *);
int received_rors_TRANSFERCALL(void *);

int received_rors_ROUTEREQUEST(void *);
int received_rors_REROUTEREQUEST(void *);
int received_rors_ROUTESELECTREQUEST(void *);
int received_rors_ROUTEUSEDREQUEST(void *);
int received_rors_ROUTEENDREQUEST(void *);

int received_rors_ESCAPESERVICE(void *);
int received_rors_SYSTEMSTATUS(void *);

int received_rors_MONITORSTART(void *);
int received_rors_CHANGEMONITORFILTER(void *);
int received_rors_MONITORSTOP(void *);
int received_rors_SNAPSHOTDEVICE(void *);
int received_rors_SNAPSHOTCALL(void *);

int received_rors_STARTDATAPATH(void *);
int received_rors_STOPDATAPATH(void *);
int received_rors_SENDDATA(void *);
int received_rors_SENDMULTICASTDATA(void *);
int received_rors_SENDBROADCASTDATA(void *);
int received_rors_SUSPENDDATAPATH(void *);
int received_rors_DATAPATHSUSPENDED(void *);
int received_rors_RESUMEDATAPATH(void *);
int received_rors_DATAPATHRESUMED(void *);
int received_rors_FASTDATA(void *);

int received_rors_CONCATENATEMESSAGE(void *);
int received_rors_DELETEMESSAGE(void *);
int received_rors_PLAYMESSAGE(void *);
int received_rors_QUERYVOICEATTRIBUTE(void *);
int received_rors_RECORDMESSAGE(void *);
int received_rors_REPOSITION(void *);
int received_rors_RESUME(void *);
int received_rors_REVIEW(void *);
int received_rors_SETVOICEATTRIBUTE(void *);
int received_rors_STOP(void *);
int received_rors_SUSPEND(void *);
int received_rors_SYNTHESIZEMESSAGE(void *);

#define FIELD_OFFSET(s, f) (((s *)(NULL))->f)
