/*
 * tspsock.c : TCP and UDP transport layers abstraction
 *
 * Copyright (C) 2000 Alc�ve and Julien Gaulmin <julien.gaulmin@fr.alcove.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */


#ifdef WIN32
#include <winsock2.h>
#else
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>	/* Internet Protocol */
#endif

#include "csock.h"
#include "tspsock.h"


int tsp_open_socket(char *transport, char *host, char *service, int type)
{
	int socket_ds;

	switch (type) {
	case CLIENT:
		if ((socket_ds = client_socket(host, service, transport)) < 0) {
			perror("tspsock.c: tsp_open_socket(): create client_socket");
			return(-1);
		}
	
		return(socket_ds);

	case SERVER:
	{
		struct sockaddr_in sin;
		int msock, lsin = sizeof(sin);

		/* Creation socket server */
		msock = server_socket(service, transport, 1);
		if (msock < 0) {
			perror("tspsock.c: tsp_open_socket(): unable to create server_socket");
			return(-1);
		}

		/* Renvoie le descripteur tel quel si non TCP */
		if (strcasecmp(transport, "TCP"))
		   return(msock);
		
		/* Accepte connection sinon (TCP) */
		socket_ds = accept(msock, (struct sockaddr *) &sin, &lsin);
		if (socket_ds < 0) {
			perror("tspsock.c: tsp_open_socket(): unable to accept connection");
			return(-1);
		}

		close(msock);

		return(socket_ds);
	}

	default:
		perror("tspsock.c: tsp_open_socket(): wrong type");
		return(-1);
	}
}


int __tsp_send_socket(int socket_ds, void *buffer, int length)
{
	int sent = 0;
	int count;

	while (sent != length) {
		count = send(socket_ds, buffer, length - sent, 0);
		if (count < 0) {
			perror("tspsock.c: __tsp_send_socket(): unable to send data");
			return(-1);
		}

		sent += count;
		(char *) buffer += count;
	}

	return(sent);
}


int tsp_write_socket(int socket_ds, void *buffer, int length)
{
	unsigned short header = htons(length);
	int realsize = sizeof(header) + length;
	char *realdata;
	int ret;

	realdata = (char *) malloc(realsize);

	/* length (2 bytes) then buffer */
	memcpy(realdata, &header, sizeof(header));
	memcpy(realdata + sizeof(header), buffer, length);

	ret = __tsp_send_socket(socket_ds, realdata, realsize);
	if (ret != realsize) {
		perror("tspsock.c: tsp_write_socket(): unable to send header+data");
		return(-1);
	}

	return(ret);
}


int __tsp_recv_socket(int socket_ds, void *buffer, int length)
{
	int recvd = 0;
	int count;
	
	while (recvd != length) {
		count = recv(socket_ds, buffer, length - recvd, 0);
		if (count < 0) {
			perror("tspsock.c: __tsp_recv_socket(): unable to receive data");
			return(-1);
		}
		
		recvd += count;
		(char *) buffer  += count;
	}

	return(recvd);
}


int tsp_read_socket(int socket_ds, void *buffer, int length)
{
	unsigned short header;
	int ret;
	
	/* Size of the message */
	ret = __tsp_recv_socket(socket_ds, (char *) &header, sizeof(header));
	if (ret != sizeof(header)) {
		perror("tspsock.c: tsp_read_socket(): unable to receive header");
		return(-1);
	}

	header = ntohs(header);
	if (header == 0)
		return(0);

	/* Remaining portion (the message) */
	if (header > length) {
		perror("tspsock.c: tsp_read_socket(): buffer is to small");
		return(-1);
	}

	ret = __tsp_recv_socket(socket_ds, buffer, header);
	if (ret != header) {
		perror("tspsock.c: tsp_read_socket(): unable to receive message");
		return(-1);
	}

	return(ret);
}
