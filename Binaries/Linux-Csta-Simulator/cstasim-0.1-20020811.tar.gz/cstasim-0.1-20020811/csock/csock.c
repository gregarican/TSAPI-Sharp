/*
 * csock.h : socket abstraction
 *
 * Copyright (C) 2000 Alc�ve and Julien Gaulmin <julien.gaulmin@fr.alcove.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */

#include <errno.h>	
#include <sys/types.h>
#ifdef WIN32
#include <winsock2.h>
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>	/* Internet Protocol */
#include <netdb.h>	/* getservbyname() and co */
#endif


#include "csock.h"


int create_socket(char *service, char *transport, struct sockaddr_in *sin)
{
	/* Structures permettant de recuperer... */
	struct servent	*iservice;
	struct protoent	*itransport;
	int s, type, proto;
	
	memset(sin, 0, sizeof(*sin));
	sin->sin_family = AF_INET;

	/* Recherche du numero de port */
	sin->sin_port = htons(atoi(service));

	if (!sin->sin_port) {
		/* Recherche dans host si pas numero */
		iservice = getservbyname(service, transport);
		sin->sin_port = iservice->s_port;
	}

	/* Recherche du numero de protocole */
#ifndef WIN32
	itransport = getprotobyname(transport);
	if (!itransport)
		perror("csock.c: create_socket(): unknown service");

	proto = itransport->p_proto;

	if (!strcasecmp(transport, "UDP"))
		type = SOCK_DGRAM; /* protocole UDP */
	else
#endif
		type = SOCK_STREAM; /* protocole TCP */

	/* Creation de la socket */
	s = socket(AF_INET, SOCK_STREAM, 0);
	if (s < 0)
		perror("csock.c: create_socket(): unable to socket");

	return(s);
}


int client_socket(char *host, char *service, char *transport)
{
	struct sockaddr_in sin;
	struct hostent *ihost;
	int s;

	if ((s = create_socket(service, transport, &sin)) < 0) {
		perror("csock.c: client_socket(): unable to create_socket");
		return(-1);
	}

	sin.sin_addr.s_addr = inet_addr(host);
	if (sin.sin_addr.s_addr == INADDR_NONE) {
		/* Si host nom -> on le cherche */
		ihost = gethostbyname(host);
		if (!ihost) {
			close(s);
			perror("csock.c: client_socket(): unknown host");
			return (-1);
		}

		memcpy(&sin.sin_addr, ihost->h_addr, ihost->h_length);
	}

	if (connect(s, (struct sockaddr *) &sin, sizeof(sin)) < 0) {
#ifndef WIN32
		close(s);
		perror("csock.c: client_socket(): unable to connect");
		return (-1);
#endif
	}
		
	return(s);
}


int server_socket(char *service, char *transport, int lqueue)
{
	int	s, opt;
	struct sockaddr_in	sin;

	if ((s = create_socket(service, transport, &sin)) < 0) {
		perror("csock.c: server_socket(): unable to create_socket");
		return(-1);
	}

	/* Autorise l'utilisation de la socket immediatement apres deconnexion */
	if (setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (char *) &opt, sizeof(opt)) < 0) {
		perror("csock.c: server_socket(): unable to setsockopt");
		return (-1);
	}

	sin.sin_addr.s_addr = INADDR_ANY;

	/* Assigne un nom � la socket */
	if (bind(s, (struct sockaddr *) &sin, sizeof(sin)) < 0) {
		perror("csock.c: server_socket(): unable to bind the socket");
		return (-1);
	}

	/* Place la socket en mode �coute (passif) si pas UDP */
	if (strcasecmp(transport, "UDP") && listen(s, lqueue) < 0) {
		perror("csock.c: server_socket(): unable to listen");
		return (-1);
	}

	return(s);
}
