/*
 * csock.h : socket abstraction
 */

#ifndef _C_SOCK_H
#define _C_SOCK_H

#ifdef WIN32
#define strncasecmp	_strnicmp
#define strcasecmp	_stricmp
#endif



#ifndef	INADDR_NONE
#define	INADDR_NONE	0xFFFFFFFF
#endif


/* Connection types */
#define MAX_CONNECT_TRIES	10
#define ONES	1


/* Prototypes */
int create_socket(char *service, char *transport, struct sockaddr_in *sin);
int client_socket(char *host, char *service, char *transport);
int server_socket(char *service, char *transport, int lqueue);


#endif /* _C_SOCK_H */

