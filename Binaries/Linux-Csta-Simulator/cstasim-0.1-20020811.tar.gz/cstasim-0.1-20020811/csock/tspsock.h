/*
 * tspsock.h : TCP and UDP transport layers abstraction
 */

#ifndef _TSP_SOCK_H
#define _TSP_SOCK_H


#define	SERVER	1
#define	CLIENT	0

#ifdef WIN32
#ifdef CSOCKDLL
#define CSOCKIMPORTEXPORT __declspec(dllexport)
#else
#define CSOCKIMPORTEXPORT __declspec(dllimport)
#endif
#else
#define CSOCKIMPORTEXPORT
#endif


/*
TSP_OPEN_SOCKET: -'type'=SERVER -> permet d'ouvrir une socket serveur sur le
				service 'service' (numero de service ou nom
				correspondant dans le fichier /etc/services).
				'host' doit etre NULL dans ce cas.
		 -'type'=CLIENT -> permet de se connecter sur le service
				'service' d'une machine 'host'.

Retourne un descripteur de socket 'socket_ds' a utiliser lors des lectures et
des ecritures et -1 en cas d'erreur.
L'appel est bloquant tant que la socket n'a pas ete ouverte.
*/
int CSOCKIMPORTEXPORT
tsp_open_socket(char *transport, char *host, char *service, int type);


/*
TSP_CLOSE_SOCKET : ferme la socket de descripteur 'socket_ds'.
*/
#ifdef WIN32
#define	tsp_close_socket(socket_ds)	closesocket(socket_ds)
#else
#define	tsp_close_socket(socket_ds)	close(socket_ds)
#endif


/*
TSP_WRITE_SOCKET : envoie un buffer 'buffer' de longueur 'length' sur la socket
		dont le descripteur est 'socket_ds'.

Retourne 0 en cas de succes et -1 en cas d'echec
*/
int CSOCKIMPORTEXPORT
tsp_write_socket(int socket_ds, void *buffer, int length);


/*
TSP_READ_SOCKET : lit un message de n octets et les stoque dans un buffer
		  'buffer' de taille maxi 'length'.

Retourne le nombre d'octets lus ou -1 en cas d'erreur.
*/
int CSOCKIMPORTEXPORT
tsp_read_socket(int socket_ds, void *buffer, int length);


#endif /* _TSP_SOCK_H */
