/*
 * voice_unit_service.cpp
 *
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */

#ifdef WIN32
#ifdef CSTADLL
#define CSTADLLIMPORTEXPORT __declspec(dllexport)
#else
#define CSTADLLIMPORTEXPORT __declspec(dllimport)
#endif /* CSTADLL */
#else
#define CSTADLLIMPORTEXPORT
#endif /* WIN32 */

#include <stlport/iosfwd>
#include <stlport/new>
using namespace _STL;


#include <time.h>

extern "C"
{
#include "asn-incl.h"
#include "csta_defs.h"
}
#include "csta_config.h"
#include "csta_api.h"
#include "csta_request_api.h"
#include "csta_response_api.h"
#include "csta_event_api.h"
extern "C"
{
#include "log.h"
#include "tspsock.h"
}
#include "cstasim.h"
#include "tables.h"
#include "voice_unit_services.h"



static int monitor_id = 1;
static unsigned long conn_id = 1;
static int fdcsta = -1, fdserver = -1;
extern FILE *logfile;

#define DEBUG_CSTATEST




handler_entry Voice_unit_services_request_handlers[] =
{
	OV_CONCATENATEMESSAGE,	received_roiv_CONCATENATEMESSAGE,
	OV_DELETEMESSAGE,	received_roiv_DELETEMESSAGE,
	OV_PLAYMESSAGE,		received_roiv_PLAYMESSAGE,
	OV_QUERYVOICEATTRIBUTE,	received_roiv_QUERYVOICEATTRIBUTE,
	OV_RECORDMESSAGE,	received_roiv_RECORDMESSAGE,
	OV_REPOSITION,		received_roiv_REPOSITION,
	OV_RESUME,		received_roiv_RESUME,
	OV_REVIEW,		received_roiv_REVIEW,
	OV_SETVOICEATTRIBUTE,	received_roiv_SETVOICEATTRIBUTE,
	OV_STOP,		received_roiv_STOP,
	OV_SUSPEND,		received_roiv_SUSPEND,
	OV_SYNTHESIZEMESSAGE,	received_roiv_SYNTHESIZEMESSAGE,
	-1,			NULL
};

static int
received_roiv_CONCATENATEMESSAGE(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_CONCATENATEMESSAGE\n");
	return 0;
}

static int
received_roiv_DELETEMESSAGE(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_DELETEMESSAGE\n");
	return 0;
}

static int
received_roiv_PLAYMESSAGE(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_PLAYMESSAGE\n");
	return 0;
}

static int
received_roiv_QUERYVOICEATTRIBUTE(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_QUERYVOICEATTRIBUTE\n");
	return 0;
}

static int
received_roiv_RECORDMESSAGE(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_RECORDMESSAGE\n");
	return 0;
}

static int
received_roiv_REPOSITION(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_REPOSITION\n");
	return 0;
}

static int
received_roiv_RESUME(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_RESUME\n");
	return 0;
}

static int
received_roiv_REVIEW(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_REVIEW\n");
	return 0;
}

static int
received_roiv_SETVOICEATTRIBUTE(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_SETVOICEATTRIBUTE\n");
	return 0;
}

static int
received_roiv_STOP(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_STOP\n");
	return 0;
}

static int
received_roiv_SUSPEND(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_SUSPEND\n");
	return 0;
}

static int
received_roiv_SYNTHESIZEMESSAGE(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_SYNTHESIZEMESSAGE\n");
	return 0;
}
