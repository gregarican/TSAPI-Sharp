/*
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 *
 */


#ifndef __DEVICE_TABLE_H__
#define __DEVICE_TABLE_H__


#include <stlport/hash_map>
#include <stlport/string>

using namespace _STL;


typedef hash_map <string, monitorid_t>  device_map;
typedef hash_map <monitorid_t, string>  monitor_map;

class device_table
{

public:

	device_table();

	int add(device_t, monitorid_t);
	int remove(device_t);
	int remove(monitorid_t);
	monitorid_t find(device_t);
	device_t *find(monitorid_t);

private:

	device_map devices;
	monitor_map monitors;
	device_map::iterator device_iter;
	monitor_map::iterator monitor_iter;
};

#endif /* __DEVICE_TABLE_H__ */
