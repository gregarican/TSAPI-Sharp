/*
 * connection.cpp
 *
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */

#ifdef WIN32
#ifdef CSTADLL
#define CSTADLLIMPORTEXPORT __declspec(dllexport)
#else
#define CSTADLLIMPORTEXPORT __declspec(dllimport)
#endif /* CSTADLL */
#else
#define CSTADLLIMPORTEXPORT
#endif /* WIN32 */

#include <stlport/iosfwd>
#include <stlport/new>
#include <stlport/memory>
#include <stlport/string>
#include <stlport/hash_map>
#include <stlport/vector>
using namespace _STL;

#include "csta_config.h"
#include <stlport/string>
#include "connection.h"


connection_t::
connection_t() {}

connection_t::
connection_t(const connection_t& src)
{
	connid = src.connid;
	device = src.device;
	state = src.state;
	role = src.role;
}

connection_t::
~connection_t() {}

connection_t&
connection_t::
operator= (const connection_t& src)
{
	if (*this == src)
	{
		return *this;
	}

	connid = src.connid;
	device = src.device;
	state = src.state;
	role = src.role;

	return *this;
}

int
connection_t::
operator== (const connection_t& src)
{
	int same = 0;

	if (*this == src)
	{
		same = 1;
	}
	else
	{
		//if (connid == src.connid && device == src.device && state == src.state && role == src.role)
		if (connid == src.connid && device == src.device)
		{
			same = 1;
		}
	}

	return same;
}


