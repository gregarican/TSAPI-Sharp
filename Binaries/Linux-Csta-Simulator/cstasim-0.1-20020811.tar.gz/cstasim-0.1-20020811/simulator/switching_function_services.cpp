/*
 * switching_function_services.cpp
 *
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */

#ifdef WIN32
#ifdef CSTADLL
#define CSTADLLIMPORTEXPORT __declspec(dllexport)
#else
#define CSTADLLIMPORTEXPORT __declspec(dllimport)
#endif /* CSTADLL */
#else
#define CSTADLLIMPORTEXPORT
#endif /* WIN32 */

#include <stlport/iosfwd>
#include <stlport/new>
using namespace _STL;

extern "C"
{
#include "asn-incl.h"
#include "csta_defs.h"
}
#include "csta_config.h"
#include "csta_api.h"
#include "csta_request_api.h"
#include "csta_response_api.h"
#include "csta_event_api.h"
extern "C"
{
#include "log.h"
#include "tspsock.h"
}
#include "cstasim.h"
#include "tables.h"
#include "switching_function_services.h"
#ifndef WIN32
#include <unistd.h>
#endif


static char enc_buff[8192];
#define ENC_BUFF_LEN sizeof(enc_buff);

static unsigned long conn_id = 1;
extern FILE *logfile;

#define NEXT_CONNID	++conn_id
#define MAX_DEVICE_LEN 32

#define DEBUG_CSTATEST




extern int add_device_to_call(unsigned long, char *);


handler_entry Switching_function_service_request_handlers[] =
{
	OV_ALTERNATECALL,	received_roiv_ALTERNATECALL,
	OV_ANSWERCALL,		received_roiv_ANSWERCALL,
	OV_ASSOCIATEDATA,	received_roiv_ASSOCIATEDATA,
	OV_CALLCOMPLETION,	received_roiv_CALLCOMPLETION,
	OV_CLEARCALL,		received_roiv_CLEARCALL,
	OV_CLEARCONNECTION,	received_roiv_CLEARCONNECTION,
	OV_CONFERENCECALL,	received_roiv_CONFERENCECALL,
	OV_CONSULTATIONCALL,	received_roiv_CONSULTATIONCALL,
	OV_DIVERTCALL,		received_roiv_DIVERTCALL,
	OV_HOLDCALL,		received_roiv_HOLDCALL,
	OV_MAKECALL,		received_roiv_MAKECALL,
	OV_MAKEPREDICTIVECALL,	received_roiv_MAKEPREDICTIVECALL,
	OV_PARKCALL,		received_roiv_PARKCALL,
	OV_QUERYDEVICE,		received_roiv_QUERYDEVICE,
	OV_RECONNECTCALL,	received_roiv_RECONNECTCALL,
	OV_RETRIEVECALL,	received_roiv_RETRIEVECALL,
	OV_SENDDTMFTONES,	received_roiv_SENDDTMFTONES,
	OV_SETFEATURE,		received_roiv_SETFEATURE,
	OV_SINGLESTEPCONF,	received_roiv_SINGLESTEPCONF,
	OV_SINGLESTEPTRANS,	received_roiv_SINGLESTEPTRANS,
	OV_TRANSFERCALL,	received_roiv_TRANSFERCALL,
	-1,			NULL
};

static int
received_roiv_ALTERNATECALL(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	AlternateCallArgument *request = (AlternateCallArgument *) roivapdu->argument.value;
	int len;

	fprintf(logfile, "received_roiv_ALTERNATECALL\n");
	PrintAlternateCallArgument(logfile, request, 0);

	len = csta_response_AlternateCall(enc_buff, sizeof(enc_buff), roivapdu->invokeID, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	return 0;
}

static int
received_roiv_ANSWERCALL(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	AnswerCallArgument *request = (AnswerCallArgument *) roivapdu->argument.value;
	monitorid_t callingmon;
	monitorid_t calledmon;
	MonitorCrossRefID calling_mid = {0};
	MonitorCrossRefID called_mid = {0};
	device_t *p;
	device_t calling_party = {0};
	device_t called_party = {0};
	connid_t connid = 0;
	CorrelatorData correlator_data= {0};
	LocalConnectionState connection_state;
	EventCause cause;
	EstablishedEvent *establishedEvent;
	int len;

	fprintf(logfile, "received_roiv_ANSWERCALL\n");
	PrintAnswerCallArgument(logfile, request, 0);

	csta_get_device(called_party, sizeof(called_party), request->a.callToBeAnswered->device->a.staticID->a.dialingNumber);
	calledmon = device_table_find(called_party);
	if (calledmon == 0)
	{
		len = csta_failure_response(
						enc_buff,
						sizeof(enc_buff),
						roivapdu->invokeID,
						UniversalFailure::UNIVERSALFAILURE_OPERATIONALERRORS,
						OBJECTNOTKNOWN);
		if (tsp_write_socket(sd, enc_buff, len) < 0)
		{
			perror("cstasim.c: tsp_write_socket()");
		}

		return 0;
	}

	csta_get_connid(&connid, &request->a.callToBeAnswered->call);

	connection_state = (LocalConnectionState) get_connection_state(connid, called_party);
	if (connection_state != LCS_ALERTING)
	{
		len = csta_failure_response(
						enc_buff,
						sizeof(enc_buff),
						roivapdu->invokeID,
						UniversalFailure::UNIVERSALFAILURE_STATEERRORS,
						NOCALLTOANSWER);
		if (tsp_write_socket(sd, enc_buff, len) < 0)
		{
			perror("cstasim.c: tsp_write_socket()");
		}

		return 0;
	}
	else
	{
		len = csta_response_AnswerCall(enc_buff, sizeof(enc_buff), roivapdu->invokeID, NULL);
	}
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	p = get_device_by_role(connid, dr_calling_party);
	if (p)
	{
		strcpy(calling_party, *p);
	}

	callingmon = device_table_find(calling_party);

	/*
	 *  Send established to called party.
	 */

	establishedEvent = (EstablishedEvent *) Asn1Alloc(sizeof(EstablishedEvent));
        csta_set_connectionid(&establishedEvent->establishedConnection, called_party, &connid);
	csta_set_SubjectDeviceID(&establishedEvent->answeringDevice, called_party);
	csta_set_CallingDeviceID(&establishedEvent->callingDevice, calling_party);
	csta_set_CalledDeviceID(&establishedEvent->calledDevice, called_party);
	csta_set_RedirectionDeviceID(&establishedEvent->lastRedirectionDevice,0,RedirectionDeviceID::REDIRECTIONDEVICEID_NOTREQUIRED);
	connection_state = LCS_CONNECT;
	cause = EC_NEWCALL;
        establishedEvent->localConnectionInfo = &connection_state;
        establishedEvent->cause = &cause;
	setoctet(&called_mid, calledmon);

	len = csta_encode_EstablishedEvent(enc_buff, sizeof(enc_buff), called_mid, establishedEvent, 0);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	set_connection_state(connid, called_party, LCS_CONNECT);
	
	/*
	 *  Send it again with crossference id of calling party.
	 */

	/*
	 *  It is a waste to reset of these fields when everything is the same except for the crosref id FIXME
	 */
	 
	establishedEvent = (EstablishedEvent *) Asn1Alloc(sizeof(EstablishedEvent));
        csta_set_connectionid(&establishedEvent->establishedConnection, called_party, &connid);
	csta_set_SubjectDeviceID(&establishedEvent->answeringDevice, called_party);
	csta_set_CallingDeviceID(&establishedEvent->callingDevice, calling_party);
	csta_set_CalledDeviceID(&establishedEvent->calledDevice, called_party);
	csta_set_RedirectionDeviceID(&establishedEvent->lastRedirectionDevice,0,RedirectionDeviceID::REDIRECTIONDEVICEID_NOTREQUIRED);
	connection_state = LCS_CONNECT;
	cause = EC_NEWCALL;
        establishedEvent->localConnectionInfo = &connection_state;
        establishedEvent->cause = &cause;
	setoctet(&calling_mid, callingmon);

	len = csta_encode_EstablishedEvent(enc_buff, sizeof(enc_buff), calling_mid, establishedEvent, 0);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	set_connection_state(connid, called_party, LCS_CONNECT);
	return 0;
}

static int
received_roiv_ASSOCIATEDATA(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	int len;

	fprintf(logfile, "received_roiv_ASSOCIATEDATA\n");

	len = csta_response_AssociateData(enc_buff, sizeof(enc_buff), roivapdu->invokeID, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	return 0;
}

static int
received_roiv_CALLCOMPLETION(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	int len;

	fprintf(logfile, "received_roiv_CALLCOMPLETION\n");

	len = csta_response_CallCompletion(enc_buff, sizeof(enc_buff), roivapdu->invokeID, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	return 0;
}

static int
received_roiv_CLEARCALL(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearCallArgument *request = (ClearCallArgument *) roivapdu->argument.value;
	CallClearedEvent *callClearedEvent;
	ConnectionID* callToBeCleared;
	connid_t connid;
	device_t *p;
	device_t device;
	monitorid_t mid;
	MonitorCrossRefID crossRefIdentifier = {0};
	CorrelatorData correlatorData= {0};
	LocalConnectionState localConnectionInfo;
	EventCause cause;
	CSTACommonArguments* extensions = 0;
	device_list devicelist;
	device_list::iterator i;
	device_list::iterator j;
	int len;


	fprintf(logfile, "received_roiv_CLEARCALL\n");
	PrintClearCallArgument(logfile, request, 0);

	len = csta_response_ClearCall(enc_buff, sizeof(enc_buff), roivapdu->invokeID, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	if (request->choiceId == ClearCallArgument::CLEARCALLARGUMENT_CLEARCALLARGUMENTSEQ)
	{
		callToBeCleared = request->a.clearCallArgumentSeq->callToBeCleared;
	}
	else
	{
		callToBeCleared = request->a.callToBeCleared;
	}
	csta_get_connid(&connid, &callToBeCleared->call);

	devicelist = get_devices_for_call(connid);	
	j = devicelist.end();
	for (i = devicelist.begin() ; i != j ; i++)
	{
		p = (device_t *) i->c_str();
		if (p)
		{
			strcpy(device, *p);
		}
		mid = device_table_find(device);
		setoctet(&crossRefIdentifier, mid);

		callClearedEvent = (CallClearedEvent *) Asn1Alloc(sizeof(CallClearedEvent));
        	csta_set_connectionid(&callClearedEvent->clearedCall, device, &connid);
		localConnectionInfo = LCS_NULL;
		cause = EC_NORMALCLEARING;  /* this value needs to be settable FIXME */
        	callClearedEvent->localConnectionInfo = &localConnectionInfo;
        	callClearedEvent->cause = &cause;
        	callClearedEvent->correlatorData = correlatorData;
		set_connection_state(connid, device, LCS_NULL);

		len = csta_encode_CallClearedEvent(enc_buff, sizeof(enc_buff), crossRefIdentifier, callClearedEvent, 0);
		if (tsp_write_socket(sd, enc_buff, len) < 0)
		{
			perror("cstasim.c: tsp_write_socket()");
		}
	}

	destroy_call(connid);

	return 0;
}

static int
received_roiv_CLEARCONNECTION(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;
	ConnectionClearedEvent *connectionClearedEvent;
	CallClearedEvent *callClearedEvent;
	connid_t connid;
	device_t releasing_device;
	CorrelatorData correlatorData= {0};
	LocalConnectionState localConnectionInfo;
	EventCause cause;
	CSTACommonArguments* extensions = 0;
	monitorid_t mid;
	MonitorCrossRefID refid;
	device_t *p;
	device_t device;
	device_list devicelist;
	device_list::iterator i;
	device_list::iterator j;
	int len;

	fprintf(logfile, "received_roiv_CLEARCONNECTION\n");
	PrintClearConnectionArgument(logfile, request, 0);

	/*
	 *  Validation required FIXME.
	 */


	connectionClearedEvent = (ConnectionClearedEvent *) Asn1Alloc(sizeof(ConnectionClearedEvent));
	if (request->choiceId == ClearConnectionArgument::CLEARCONNECTIONARGUMENT_CONNECTIONTOBECLEARED)
	{
		connectionClearedEvent->droppedConnection = request->a.connectionToBeCleared;
	}
	else
	{
		connectionClearedEvent->droppedConnection = request->a.clearConnectionArgumentSeq->connectionToBeCleared;
		extensions = request->a.clearConnectionArgumentSeq->extensions;
	}
	csta_get_connid(&connid, &connectionClearedEvent->droppedConnection->call);

	/*
	 *  send extensions back with response FIXME.
	 */
	len = csta_response_ClearConnection(enc_buff, sizeof(enc_buff), roivapdu->invokeID, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	csta_get_device(releasing_device, sizeof(releasing_device), connectionClearedEvent->droppedConnection->device->a.staticID->a.dialingNumber);
	mid = device_table_find(releasing_device);

	if (get_connection_count(connid) > 2)
	{
		csta_set_SubjectDeviceID(&connectionClearedEvent->releasingDevice, releasing_device);
		localConnectionInfo = LCS_NULL;
		cause = EC_NORMALCLEARING;  /* this value needs to be settable FIXME */
        	connectionClearedEvent->localConnectionInfo = &localConnectionInfo;
        	connectionClearedEvent->cause = &cause;
        	connectionClearedEvent->correlatorData = correlatorData;
		setoctet(&refid, mid);

		remove_device_from_call(connid, releasing_device);

		len = csta_encode_ConnectionClearedEvent(enc_buff, sizeof(enc_buff), refid, connectionClearedEvent, 0);
		if (tsp_write_socket(sd, enc_buff, len) < 0)
		{
			perror("cstasim.c: tsp_write_socket()");
		}
	}
	else
	{
		devicelist = get_devices_for_call(connid);	
		j = devicelist.end();
		for (i = devicelist.begin() ; i != j ; i++)
		{
			p = (device_t *) i->c_str();
			if (p)
			{
				strcpy(device, *p);
				mid = device_table_find(device);
				setoctet(&refid, mid);

				callClearedEvent = (CallClearedEvent *) Asn1Alloc(sizeof(CallClearedEvent));
        			csta_set_connectionid(&callClearedEvent->clearedCall, device, &connid);
				localConnectionInfo = LCS_NULL;
				cause = EC_NORMALCLEARING;  /* this value needs to be settable FIXME */
        			callClearedEvent->localConnectionInfo = &localConnectionInfo;
        			callClearedEvent->cause = &cause;
        			callClearedEvent->correlatorData = correlatorData;

				len = csta_encode_CallClearedEvent(enc_buff, sizeof(enc_buff), refid, callClearedEvent, 0);
				if (tsp_write_socket(sd, enc_buff, len) < 0)
				{
					perror("cstasim.c: tsp_write_socket()");
				}
			}
		}

		destroy_call(connid);
	}

	return 0;
}

static int
received_roiv_CONFERENCECALL(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ConferenceCallArgument *request = (ConferenceCallArgument *) roivapdu->argument.value;
	int len;

	fprintf(logfile, "received_roiv_CONFERENCECALL\n");
	PrintConferenceCallArgument(logfile, request, 0);
	return 0;
}

static int
received_roiv_CONSULTATIONCALL(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ConsultationCallArgument *request = (ConsultationCallArgument *) roivapdu->argument.value;
	connid_t connid;
	char calling_party[MAX_DEVICE_LEN];
	HeldEvent *heldEvent;
	CorrelatorData correlatorData= {0};
	LocalConnectionState localConnectionInfo;
	EventCause cause;
	MonitorCrossRefID crossRefIdentifier;
	int len;

	fprintf(logfile, "received_roiv_CONSULTATIONCALL\n");
	PrintConsultationCallArgument(logfile, request, 0);

	if (request->extensions)
	{
	}

	
	csta_get_connid(&connid, &request->existingCall->call);
	csta_get_device(calling_party, sizeof(calling_party), request->existingCall->device->a.staticID->a.dialingNumber);
	

	heldEvent = (HeldEvent *) Asn1Alloc(sizeof(HeldEvent));
       	csta_set_connectionid(&heldEvent->heldConnection, calling_party, &connid);
	csta_set_SubjectDeviceID(&heldEvent->holdingDevice, calling_party);
	localConnectionInfo = LCS_HOLD;
	cause = EC_CONSULTATION;
        heldEvent->localConnectionInfo = &localConnectionInfo;
        heldEvent->cause = &cause;
        heldEvent->correlatorData = correlatorData;

	set_connection_state(connid, calling_party, LCS_HOLD);
	len = csta_encode_HeldEvent(enc_buff, sizeof(enc_buff), crossRefIdentifier, heldEvent, 0);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	heldEvent = (HeldEvent *) Asn1Alloc(sizeof(HeldEvent));
       	csta_set_connectionid(&heldEvent->heldConnection, calling_party, &connid);
	csta_set_SubjectDeviceID(&heldEvent->holdingDevice, calling_party);
	localConnectionInfo = LCS_CONNECT; /* this may be incorrect if other party has held the call FIXME */
	cause = EC_CONSULTATION;
        heldEvent->localConnectionInfo = &localConnectionInfo;
        heldEvent->cause = &cause;
        heldEvent->correlatorData = correlatorData;

	len = csta_encode_HeldEvent(enc_buff, sizeof(enc_buff), crossRefIdentifier, heldEvent, 0);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	return 0;
}

static int
received_roiv_DIVERTCALL(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	DivertCallArgument *request = (DivertCallArgument *) roivapdu->argument.value;
	int len;

	fprintf(logfile, "received_roiv_DIVERTCALL\n");
	PrintDivertCallArgument(logfile, request, 0);

	len = csta_response_DivertCall(enc_buff, sizeof(enc_buff), roivapdu->invokeID, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	return 0;
}

static int
received_roiv_HOLDCALL(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	HoldCallArgument *request = (HoldCallArgument *) roivapdu->argument.value;
	connid_t connid;
	char device[MAX_DEVICE_LEN];
	HeldEvent *heldEvent;
	CorrelatorData correlatorData= {0};
	LocalConnectionState localConnectionInfo;
	EventCause cause;
	MonitorCrossRefID crossRefIdentifier;
	int len;

	fprintf(logfile, "received_roiv_HOLDCALL\n");
	PrintHoldCallArgument(logfile, request, 0);

	len = csta_response_HoldCall(enc_buff, sizeof(enc_buff), roivapdu->invokeID, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	if (request->extensions)
	{
	}

	
	csta_get_connid(&connid, &request->callToBeHeld->call);
	csta_get_device(device, sizeof(device), request->callToBeHeld->device->a.staticID->a.dialingNumber);

	heldEvent = (HeldEvent *) Asn1Alloc(sizeof(HeldEvent));
       	csta_set_connectionid(&heldEvent->heldConnection, device, &connid);
	csta_set_SubjectDeviceID(&heldEvent->holdingDevice, device);
	localConnectionInfo = LCS_HOLD;
	cause = EC_CONSULTATION;
        heldEvent->localConnectionInfo = &localConnectionInfo;
        heldEvent->cause = &cause;
        heldEvent->correlatorData = correlatorData;

	set_connection_state(connid, device, LCS_HOLD);
	len = csta_encode_HeldEvent(enc_buff, sizeof(enc_buff), crossRefIdentifier, heldEvent, 0);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	return 0;
}

static int
received_roiv_MAKECALL(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	MakeCallArgument *request = (MakeCallArgument *) roivapdu->argument.value;
	connid_t connid;
	monitorid_t calledmon;
	monitorid_t callingmon;
	MonitorCrossRefID calling_mid = {0};
	MonitorCrossRefID called_mid = {0};
	char calling_party[MAX_DEVICE_LEN];
	char called_party[MAX_DEVICE_LEN];
	CorrelatorData correlator_data= {0};
	LocalConnectionState connection_state;
	EventCause cause;
	ServiceInitiatedEvent *serviceInitiatedEvent;
	DeliveredEvent *deliveredEvent;
	OriginatedEvent *originatedEvent;
	int len;

	fprintf(logfile, "received_roiv_MAKECALL\n");
	PrintMakeCallArgument(logfile, request, 0);

	/*
	 *  Verify connection states.  If either party is not available
	 *  send a failure.  FIXME.
	 */

	connid = create_call();
	csta_get_device(calling_party, sizeof(calling_party), request->callingDevice->a.dialingNumber);
	callingmon = device_table_find(calling_party);
	if (callingmon == 0)
	{
		len = csta_failure_response(
						enc_buff,
						sizeof(enc_buff),
						roivapdu->invokeID,
						UniversalFailure::UNIVERSALFAILURE_OPERATIONALERRORS,
						OBJECTNOTKNOWN);
		if (tsp_write_socket(sd, enc_buff, len) < 0)
		{
			perror("cstasim.c: tsp_write_socket()");
		}

		return 0;
	}
	csta_get_device(called_party, sizeof(called_party), request->calledDirectoryNumber->a.deviceIdentifier->a.deviceIdentifier->a.dialingNumber);
	calledmon = device_table_find(called_party);
	
	len = csta_response_MakeCall(enc_buff, sizeof(enc_buff), roivapdu->invokeID, calling_party, connid, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	add_device_to_call(connid, calling_party, LCS_INITIATE, dr_calling_party);
	add_device_to_call(connid, called_party, LCS_ALERTING, dr_called_party);

        serviceInitiatedEvent = (ServiceInitiatedEvent *) Asn1Alloc(sizeof(ServiceInitiatedEvent));
        csta_set_connectionid(&serviceInitiatedEvent->initiatedConnection, calling_party, &connid);
	connection_state = LCS_CONNECT;
	cause = EC_MAKECALL;
        serviceInitiatedEvent->localConnectionInfo = &connection_state;
        serviceInitiatedEvent->cause = &cause;
	setoctet(&calling_mid, callingmon);
	len = csta_encode_ServiceInitiatedEvent(enc_buff, sizeof(enc_buff), calling_mid, serviceInitiatedEvent, 0);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}


	/*
	 *  Send originated event to the calling party.
	 */

        originatedEvent = (OriginatedEvent *) Asn1Alloc(sizeof(OriginatedEvent));
        csta_set_connectionid(&originatedEvent->originatedConnection, calling_party, &connid);
	csta_set_CallingDeviceID(&originatedEvent->callingDevice, calling_party);
	csta_set_CalledDeviceID(&originatedEvent->calledDevice, called_party);
	/*
	 *  If the call is exiting the switching subdomain subject deviceid must be populated. FIXME
	 */
	csta_set_SubjectDeviceID(&originatedEvent->originatingDevice, NULL, SubjectDeviceID::SUBJECTDEVICEID_NOTREQUIRED);
	connection_state = LCS_CONNECT;
	cause = EC_NEWCALL;
        originatedEvent->localConnectionInfo = &connection_state;
        originatedEvent->cause = &cause;
	setoctet(&calling_mid, callingmon);

	len = csta_encode_OriginatedEvent(enc_buff, sizeof(enc_buff), calling_mid, originatedEvent, 0);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	set_connection_state(connid, calling_party, LCS_CONNECT);

	/*
	 *  Send delivered event to the calling party.
	 */

        deliveredEvent = (DeliveredEvent *) Asn1Alloc(sizeof(DeliveredEvent));
        csta_set_connectionid(&deliveredEvent->connection, calling_party, &connid);
	csta_set_SubjectDeviceID(&deliveredEvent->alertingDevice, called_party);
	csta_set_CallingDeviceID(&deliveredEvent->callingDevice, calling_party);
	csta_set_CalledDeviceID(&deliveredEvent->calledDevice, called_party);
	csta_set_RedirectionDeviceID(&deliveredEvent->lastRedirectionDevice,0,RedirectionDeviceID::REDIRECTIONDEVICEID_NOTREQUIRED);

	connection_state = LCS_CONNECT;
	cause = EC_NEWCALL;
        deliveredEvent->localConnectionInfo = &connection_state;
        deliveredEvent->cause = &cause;
	setoctet(&calling_mid, callingmon);

	len = csta_encode_DeliveredEvent(enc_buff, sizeof(enc_buff), calling_mid, deliveredEvent, 0);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	if (calledmon)
	{
		/*
		 *  Send delivered event to the called party.
		 */

		deliveredEvent = (DeliveredEvent *) Asn1Alloc(sizeof(DeliveredEvent));
		csta_set_connectionid(&deliveredEvent->connection, called_party, &connid);
		csta_set_SubjectDeviceID(&deliveredEvent->alertingDevice, called_party);
		csta_set_CallingDeviceID(&deliveredEvent->callingDevice, calling_party);
		csta_set_CalledDeviceID(&deliveredEvent->calledDevice, called_party);
		csta_set_RedirectionDeviceID(&deliveredEvent->lastRedirectionDevice,0,
									RedirectionDeviceID::REDIRECTIONDEVICEID_NOTREQUIRED);

		connection_state = LCS_ALERTING;
		cause = EC_NEWCALL;
        	deliveredEvent->localConnectionInfo = &connection_state;
        	deliveredEvent->cause = &cause;
		setoctet(&called_mid, calledmon);

		len = csta_encode_DeliveredEvent(enc_buff, sizeof(enc_buff), called_mid, deliveredEvent, 0);
		if (tsp_write_socket(sd, enc_buff, len) < 0)
		{
			perror("cstasim.c: tsp_write_socket()");
		}
	}

	set_connection_state(connid, called_party, LCS_ALERTING);


	return 0;
}

static int
received_roiv_MAKEPREDICTIVECALL(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	MakePredictiveCallArgument *request = (MakePredictiveCallArgument *) roivapdu->argument.value;
	connid_t connid;
	char calling_party[MAX_DEVICE_LEN];
	char called_party[MAX_DEVICE_LEN];
	int len;

	fprintf(logfile, "received_roiv_MAKECALL\n");
	PrintMakePredictiveCallArgument(logfile, request, 0);

	connid = create_call();
	csta_get_device(calling_party, sizeof(calling_party), request->callingDevice->a.dialingNumber);
	csta_get_device(called_party, sizeof(called_party), request->calledDirectoryNumber->a.deviceIdentifier->a.deviceIdentifier->a.dialingNumber);

	len = csta_response_MakePredictiveCall(enc_buff, sizeof(enc_buff), roivapdu->invokeID, calling_party, connid, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	add_device_to_call(connid, calling_party, 0, dr_calling_party);
	add_device_to_call(connid, called_party, 0, dr_called_party);

	return 0;
}

static int
received_roiv_PARKCALL(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ParkCallArgument *request = (ParkCallArgument *) roivapdu->argument.value;
	int len;

	fprintf(logfile, "received_roiv_PARKCALL\n");
	PrintParkCallArgument(logfile, request, 0);

	len = csta_response_ParkCall(enc_buff, sizeof(enc_buff), roivapdu->invokeID, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	return 0;
}

static int
received_roiv_QUERYDEVICE(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	QueryDeviceArgument *request = (QueryDeviceArgument *) roivapdu->argument.value;
	int len;

	fprintf(logfile, "received_roiv_QUERYDEVICE\n");
	PrintQueryDeviceArgument(logfile, request, 0);
	return 0;
}

static int
received_roiv_RECONNECTCALL(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ReconnectCallArgument *request = (ReconnectCallArgument *) roivapdu->argument.value;
	int len;

	fprintf(logfile, "received_roiv_RECONNECTCALL\n");
	PrintReconnectCallArgument(logfile, request, 0);

	len = csta_response_ReconnectCall(enc_buff, sizeof(enc_buff), roivapdu->invokeID, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	return 0;
}

static int
received_roiv_RETRIEVECALL(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	RetrieveCallArgument *request = (RetrieveCallArgument *) roivapdu->argument.value;
	int len;

	fprintf(logfile, "received_roiv_RETRIEVECALL\n");
	PrintRetrieveCallArgument(logfile, request, 0);

	len = csta_response_RetrieveCall(enc_buff, sizeof(enc_buff), roivapdu->invokeID, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	return 0;
}

static int
received_roiv_SENDDTMFTONES(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	SendDTMFTonesArgument *request = (SendDTMFTonesArgument *) roivapdu->argument.value;
	int len;

	fprintf(logfile, "received_roiv_SENDDTMFTONES\n");
	PrintSendDTMFTonesArgument(logfile, request, 0);

	len = csta_response_SendDTMFTones(enc_buff, sizeof(enc_buff), roivapdu->invokeID, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	return 0;
}

static int
received_roiv_SETFEATURE(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	SetFeatureArgument *args = (SetFeatureArgument *) roivapdu->argument.value;
	AgentParameter *agent_param;
	monitorid_t mid;
	MonitorCrossRefID crossRefIdentifier = {0};
	EventCause cause;
	int len;

	fprintf(logfile, "received_roiv_SETFEATURE\n");
	PrintSetFeatureArgument(logfile, args, 0);


	len = csta_response_SetFeature(enc_buff, sizeof(enc_buff), roivapdu->invokeID, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
		perror("cstasim.c: tsp_write_socket()");
	}

	switch(args->feature->choiceId)
	{
	case SetDeviceFeature::SETDEVICEFEATURE_REQUESTEDAGENTSTATE:

		agent_param = args->feature->a.requestedAgentState;
		switch(agent_param->choiceId)
		{
                case AgentParameter::AGENTPARAMETER_AGENTBUSY:

			len = csta_AgentBusyEvent (enc_buff, sizeof(enc_buff), crossRefIdentifier, "PHONY", NULL, NULL, cause, NULL);
			if (tsp_write_socket(sd, enc_buff, len) < 0)
			{
				perror("cstasim.c: tsp_write_socket()");
			}

			break;

                case AgentParameter::AGENTPARAMETER_AGENTLOGGEDIN:

			len = csta_LoggedOnEvent (enc_buff, sizeof(enc_buff), crossRefIdentifier,
											"PHONY", "a120", NULL, NULL, cause, NULL);
			if (tsp_write_socket(sd, enc_buff, len) < 0)
			{
				perror("cstasim.c: tsp_write_socket()");
			}

			break;

                case AgentParameter::AGENTPARAMETER_AGENTLOGGEDOUT:

			len = csta_LoggedOffEvent (enc_buff, sizeof(enc_buff), crossRefIdentifier,
											"PHONY", "a120", NULL, NULL, cause, NULL);
			if (tsp_write_socket(sd, enc_buff, len) < 0)
			{
				perror("cstasim.c: tsp_write_socket()");
			}

			break;

                case AgentParameter::AGENTPARAMETER_AGENTNOTREADY:

			len = csta_NotReadyEvent (enc_buff, sizeof(enc_buff), crossRefIdentifier, "PHONY", NULL, cause, NULL);
			if (tsp_write_socket(sd, enc_buff, len) < 0)
			{
				perror("cstasim.c: tsp_write_socket()");
			}

			break;

                case AgentParameter::AGENTPARAMETER_AGENTREADY:

			len = csta_ReadyEvent (enc_buff, sizeof(enc_buff), crossRefIdentifier, "PHONY", NULL, cause, NULL);
			if (tsp_write_socket(sd, enc_buff, len) < 0)
			{
				perror("cstasim.c: tsp_write_socket()");
			}

			break;

                case AgentParameter::AGENTPARAMETER_AGENTWORKINGAFTERCALL:

			len = csta_WorkingAfterCallEvent (enc_buff, sizeof(enc_buff), crossRefIdentifier,
												"PHONY", NULL, cause, NULL, NULL);
			if (tsp_write_socket(sd, enc_buff, len) < 0)
			{
				perror("cstasim.c: tsp_write_socket()");
			}

			break;

		}

		break;
	}

	return 0;
}

static int
received_roiv_SINGLESTEPCONF(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	SingleStepConfArgument *request = (SingleStepConfArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_SINGLESTEPCONF\n");
	PrintSingleStepConfArgument(logfile, request, 0);
	return 0;
}

static int
received_roiv_SINGLESTEPTRANS(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	SingleStepTransArgument *request = (SingleStepTransArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_SINGLESTEPTRANS\n");
	PrintSingleStepTransArgument(logfile, request, 0);
	return 0;
}

static int
received_roiv_TRANSFERCALL(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	TransferCallArgument *request = (TransferCallArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_TRANSFERCALL\n");
	PrintTransferCallArgument(logfile, request, 0);
	return 0;
}
