

#ifdef WIN32
#ifdef CSTADLL
#define CSTADLLIMPORTEXPORT __declspec(dllexport)
#else
#define CSTADLLIMPORTEXPORT __declspec(dllimport)
#endif /* CSTADLL */
#else
#define CSTADLLIMPORTEXPORT
#endif /* WIN32 */

#include <stlport/iosfwd>
#include <stlport/new>
#include <stlport/memory>
#include <stlport/string>
#include <stlport/hash_map>
#include <stlport/vector>
using namespace _STL;

#include "csta_config.h"
#include "device_table.h"





device_table::
device_table()
{
	device_iter = devices.begin();
	monitor_iter = monitors.begin();
}

int device_table::
add(device_t device, monitorid_t crossrefid)
{
	monitor_map::iterator i;
	device_map::iterator j;

	i = monitors.find(crossrefid);
	if (i == monitors.end())
	{
		j = devices.find(device);
		if (j == devices.end())
		{
			devices[device] = crossrefid;
			monitors[crossrefid] = device;
		}
	}

	return 0;
}
	
int device_table::
remove(device_t device)
{
	device_map::iterator i;
	monitor_map::iterator j;
	monitorid_t monitor;

	i = devices.find(device);
	if (i != devices.end())
	{
		monitor = (*i).second;
		j = monitors.find(monitor);
		if (j != monitors.end())
		{
			monitors.erase(j);
		}
		devices.erase(i);
	}

	return 0;
}

int device_table::
remove(monitorid_t monitor_id)
{
	monitor_map::iterator i;
	device_map::iterator j;
	string device;

	i = monitors.find(monitor_id);
	if (i != monitors.end())
	{
		device = (*i).second;
		j = devices.find(device);
		if (j != devices.end())
		{
			devices.erase(j);
		}
		monitors.erase(i);
	}

	return 0;
}

monitorid_t device_table::
find(device_t device)
{
	device_map::iterator i;

	i = devices.find(device);
	if (i != devices.end())
	{
		return (*i).second;
	}

	return 0;
}

device_t *device_table::
find(monitorid_t monitor_id)
{
	monitor_map::iterator i;
	string device;

	i = monitors.find(monitor_id);
	if (i != monitors.end())
	{
		device = (*i).second;
		return (device_t *) device.c_str();
	}

	return 0;
}
