/*
 * cstasim.c : csta simulator application
 *
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 *
 * Based on work from :
 * Julien Gaulmin <julien.gaulmin@fr.alcove.com>
 * Francisco Espinoza Junior and Philippe de M. Sevestre
 * Dedalus Engenharia S/C Ltda - Convenio GMK/FDTE
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */


#ifdef WIN32
#ifdef CSTADLL
#define CSTADLLIMPORTEXPORT __declspec(dllexport)
#else
#define CSTADLLIMPORTEXPORT __declspec(dllimport)
#endif /* CSTADLL */
#else
#define CSTADLLIMPORTEXPORT
#endif /* WIN32 */

#include <stlport/iosfwd>
#include <stlport/new>
using namespace _STL;

extern "C"
{
#include "asn-incl.h"
#include "csta_defs.h"
}
#include "csta_config.h"
#include "csta_api.h"
#include "csta_request_api.h"
#include "csta_response_api.h"
#include "csta_event_api.h"
extern "C"
{
#include "log.h"
#include "tspsock.h"
}
#include "cstasim.h"
#include "tables.h"
#include "device_table.h"
#include "status_reporting_services.h"


static char enc_buff[8192];
#define ENC_BUFF_LEN sizeof(enc_buff);

static long monitor_id = 1;
extern FILE *logfile;

#define NEXT_MONITORID	++monitor_id
#define MAX_DEVICE_LEN 32

#define DEBUG_CSTATEST




handler_entry Status_reporting_services_request_handlers[] =
{
	OV_MONITORSTART,	received_roiv_MONITORSTART,
	OV_CHANGEMONITORFILTER,	received_roiv_CHANGEMONITORFILTER,
	OV_MONITORSTOP,		received_roiv_MONITORSTOP,
	OV_SNAPSHOTDEVICE,	received_roiv_SNAPSHOTDEVICE,
	OV_SNAPSHOTCALL,	received_roiv_SNAPSHOTCALL,
	-1,			NULL
};

static int
received_roiv_MONITORSTART(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	MonitorStartArgument *request = (MonitorStartArgument *) roivapdu->argument.value;
	char monitor_device[MAX_DEVICE_LEN];
	device_t device;
	monitorid_t monitor = NEXT_MONITORID;
	int len;

	fprintf(logfile, "received_roiv_MONITORSTART\n");
	PrintMonitorStartArgument(logfile, request, 0);

	csta_get_device(monitor_device, sizeof(monitor_device), request->monitorObject->a.device->a.dialingNumber);
	device_table_add(monitor_device, monitor);

	len = csta_response_MonitorStart(enc_buff, sizeof(enc_buff), roivapdu->invokeID, monitor, request->monitorFilter, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
       		perror("cstasim.c: MONITORSTART(): tsp_write_socket()");
       		return -1;
       	}
}

static int
received_roiv_CHANGEMONITORFILTER(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ChangeMonitorFilterArgument *request = (ChangeMonitorFilterArgument *) roivapdu->argument.value;
	int len;

	fprintf(logfile, "received_roiv_CHANGEMONITORFILTER\n");
	PrintChangeMonitorFilterArgument(logfile, request, 0);

	len = csta_response_ChangeMonitorFilter(enc_buff, sizeof(enc_buff), roivapdu->invokeID, request->filterlist, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
       		perror("cstasim.c: ChangeMonitorFilter: tsp_write_socket()");
       		return -1;
       	}
	return 0;
}

static int
received_roiv_MONITORSTOP(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	MonitorStopArgument *request = (MonitorStopArgument *) roivapdu->argument.value;
	monitorid_t monitor;
	int len;

	fprintf(logfile, "received_roiv_MONITORSTOP\n");
	PrintMonitorStopArgument(logfile, request, 0);

	memcpy(&monitor, request->a.crossRefIdentifier->octs, sizeof(monitor)); //FIXME add utility functions
	device_table_remove(monitor);

	len = csta_response_MonitorStop(enc_buff, sizeof(enc_buff), roivapdu->invokeID, NULL);
	if (tsp_write_socket(sd, enc_buff, len) < 0)
	{
       		perror("cstasim.c: MonitorStart(): tsp_write_socket()");
       		return -1;
       	}
}

static int
received_roiv_SNAPSHOTDEVICE(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_SNAPSHOTDEVICE\n");
	return 0;
}

static int
received_roiv_SNAPSHOTCALL(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_SNAPSHOTCALL\n");
	return 0;
}
