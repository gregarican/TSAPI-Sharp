/*
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 *
 */


#ifdef WIN32
#ifdef CSTADLL
#define CSTADLLIMPORTEXPORT __declspec(dllexport)
#else
#define CSTADLLIMPORTEXPORT __declspec(dllimport)
#endif /* CSTADLL */
#else
#define CSTADLLIMPORTEXPORT
#endif /* WIN32 */

#include <stlport/iosfwd>
#include <stlport/new>
#include <stlport/memory>
#include <stlport/string>
#include <stlport/hash_map>
#include <stlport/vector>
using namespace _STL;


#include "tables.h"


static device_table devices;
static call_table calls;


/*
 *  Call table management functions.
 */

int
add_device_to_call(connid_t connid, device_t device, int state, int role)
{
	return calls.add_device(connid, device, state, role);
}

int
remove_device_from_call(connid_t connid, device_t device)
{
	return calls.remove_device(connid, device);
}

connid_t
create_call(void)
{
	return calls.create_call();
}

void
destroy_call(connid_t connid)
{
	calls.destroy_call(connid);
}

int
set_connection_state(connid_t connid, device_t device, int state)
{
	return calls.set_connection_state(connid, device, state);
}

int
get_connection_state(connid_t connid, device_t device)
{
	return calls.get_connection_state(connid, device);
}

device_t *
get_device_by_role(connid_t connid, int role)
{
	return calls.get_device_by_role(connid, role);
}

device_list
get_devices_for_call(connid_t connid)
{
	return calls.get_devices_for_call(connid);
}

long
get_connection_count(connid_t connid)
{
	return calls.get_connection_count(connid);
}


/*
 *  Device table functions.
 */

int
device_table_add(device_t device, monitorid_t crossrefid)
{
	return devices.add(device, crossrefid);
}
	
int
device_table_remove(device_t device)
{
	return devices.remove(device);
}

int
device_table_remove(monitorid_t monitor_id)
{
	return devices.remove(monitor_id);
}

monitorid_t
device_table_find(device_t device)
{
	return devices.find(device);
}

device_t *
device_table_find(monitorid_t monitor_id)
{
	return devices.find(monitor_id);
}
