/*
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 *
 */

#ifndef __TABLES_H__
#define __TABLES_H__

#include "csta_config.h"
#include "device_table.h"
#include "connection.h"
#include "call.h"
#include "call_table.h"

static char __tables_h__[] = "$Id: tables.h,v 1.10 2002/08/02 03:26:25 jecode Exp $";


#define MAX_DEVICE_LEN 32

connid_t create_call(void);
void destroy_call(connid_t);
int set_connection_state(connid_t, device_t, int);
int get_connection_state(connid_t connid, device_t device);
int add_device_to_call(connid_t connid, device_t device, int state, int role);
int remove_device_from_call(connid_t connid, device_t device);
device_t *get_device_by_role(connid_t connid, int role);
long get_connection_count(connid_t connid);
device_list get_devices_for_call(connid_t connid);

int device_table_add(device_t device, monitorid_t crossrefid);
int device_table_remove(device_t device);
int device_table_remove(monitorid_t monitor_id);
monitorid_t device_table_find(device_t device);
device_t *device_table_find(monitorid_t monitor_id);







#endif
