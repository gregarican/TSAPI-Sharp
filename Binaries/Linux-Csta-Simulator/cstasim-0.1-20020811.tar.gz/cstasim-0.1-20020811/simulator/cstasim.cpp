/*
 * cstasim.c : csta simulator application
 *
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 *
 * Based on work from :
 * Julien Gaulmin <julien.gaulmin@fr.alcove.com>
 * Francisco Espinoza Junior and Philippe de M. Sevestre
 * Dedalus Engenharia S/C Ltda - Convenio GMK/FDTE
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */

#ifdef WIN32
#ifdef CSTADLL
#define CSTADLLIMPORTEXPORT __declspec(dllexport)
#else
#define CSTADLLIMPORTEXPORT __declspec(dllimport)
#endif /* CSTADLL */
#else
#define CSTADLLIMPORTEXPORT
#endif /* WIN32 */

#include <stlport/iosfwd>
#include <stlport/new>
using namespace _STL;

#ifndef WIN32
#include <poll.h>
#include <signal.h>
#endif
#include <time.h>

extern "C"
{
#include "asn-incl.h"
#include "csta_defs.h"
}
#include "csta_config.h"
#include "csta_api.h"
#include "csta_request_api.h"
#include "csta_response_api.h"
#include "csta_event_api.h"
extern "C"
{
#include "log.h"
#include "tspsock.h"
}
#include "cstasim.h"
#include "tables.h"
#include "utils.h"

#define INFTIM          -1
static time_t tm;
static char logpath[] = "cstasim.log";
FILE *logfile;

#define DEBUG_CSTATEST

extern handler_entry Switching_function_service_request_handlers[];
extern handler_entry Status_reporting_services_request_handlers[];
extern handler_entry Computing_function_services_request_handlers[];
extern handler_entry Bidirectional_services_request_handlers[];
extern handler_entry Status_reporting_services_request_handlers[];
extern handler_entry Input_output_services_request_handlers[];
extern handler_entry Voice_unit_services_request_handlers[];

static inline int received_ROSEAPDUS_ROIV_APDU(CONNHANDLE, ROSEapdus *);
static inline int received_ROSEAPDUS_RORS_APDU(CONNHANDLE, ROSEapdus *);
static inline int received_ROSEAPDUS_ROER_APDU(CONNHANDLE, ROSEapdus *);
static inline int received_ROSEAPDUS_RORJ_APDU(CONNHANDLE, ROSEapdus *);

int
main(int argc, char **argv)
{
	int fdserver = -1;
	int test;
	int len;

#ifdef WIN32
	WSADATA wsd;

	WSAStartup(MAKEWORD(1,1), &wsd);


	__asm int(3);
#endif
	

	logfile = fopen(logpath, "a");
	logsetlevel(LOG_DEBUG);
	loginit(logfile);

	csta_init();

	fdserver = tsp_open_socket("tcp", NULL, "3333", SERVER);
	if (fdserver < 0)
	{
		perror("cstasim.c: main(): tsp_open_socket(SERVER)");
		exit(-1);
	}

	tm = time(NULL);
	fprintf(logfile, "\n********************************************************************************\n");
	fprintf(logfile, "\n\nRestarted on %s", ctime(&tm));
	fprintf(logfile, "\n--------------------------------------------------------------------------------\n");

	if (fdserver > 0)
	{
		for(;;)
		{
			poll_input(fdserver);
		}
	}
}

void
poll_input(int sd)
{
	fd_set readfds;
	fd_set writefds;
	
	FD_ZERO(&writefds);
	FD_ZERO(&readfds);
	FD_SET(sd, &readfds);
	FD_SET(sd, &writefds);

	if (select(sd + 1, &readfds, &writefds, NULL, NULL) > 0)
	{
		if (FD_ISSET(sd, &readfds))
		{
			dump(sd);
		}
	}
}

int
dump(int fd) 
{
	static char buf[8192];
	int error, size;
	ROSEapdus *pdu;

	tm = time(NULL);

	size = tsp_read_socket(fd, buf, sizeof(buf));
	if (size < 0)
	{
		perror("cstasim.c: dump(): tsp_read_socket()");
		return(-1);
	}

	logdump(LOG_DEBUG, buf, size);
	printf("\n");

	pdu = csta_decode_message(buf, size);

	if (pdu)
	{
		switch (pdu->choiceId)
		{
		case ROSEapdus::ROSEAPDUS_ROIV_APDU:
			received_ROSEAPDUS_ROIV_APDU(fd, pdu);
			break;

		case ROSEapdus::ROSEAPDUS_RORS_APDU:
			received_ROSEAPDUS_RORS_APDU(fd, pdu);
			break;

		case ROSEapdus::ROSEAPDUS_ROER_APDU:
			received_ROSEAPDUS_ROER_APDU(fd, pdu);
			break;

		case ROSEapdus::ROSEAPDUS_RORJ_APDU:
			received_ROSEAPDUS_RORJ_APDU(fd, pdu);
			break;
		}

		csta_release_memory();
	}


	fprintf(logfile, "\n\n--------------------------------------------------------------------------------\n\n");

	return(0);
}

static inline int
received_ROSEAPDUS_ROIV_APDU(CONNHANDLE sd, ROSEapdus *pdu)
{
	int status = -1;
	ROIVapdu *roivapdu = pdu->a.roiv_apdu;
	void *data;
	handler_entry *table = 0;
	message_handler handler;
	long subtype = -1;


	switch (roivapdu->operation_value)
	{

	/*
	 *  Switching function services
	 */

	case OV_ALTERNATECALL:
	case OV_ANSWERCALL:
	case OV_ASSOCIATEDATA:
	case OV_CALLCOMPLETION:
	case OV_CLEARCALL:
	case OV_CLEARCONNECTION:
	case OV_CONFERENCECALL:
	case OV_CONSULTATIONCALL:
	case OV_DIVERTCALL:
	case OV_HOLDCALL:
	case OV_MAKECALL:
	case OV_MAKEPREDICTIVECALL:
	case OV_PARKCALL:
	case OV_QUERYDEVICE:
	case OV_RECONNECTCALL:
	case OV_RETRIEVECALL:
	case OV_SENDDTMFTONES:
	case OV_SETFEATURE:
	case OV_SINGLESTEPCONF:
	case OV_SINGLESTEPTRANS:
	case OV_TRANSFERCALL:

		/* data =  (roivapdu->argument.value); */
		table = Switching_function_service_request_handlers;
		subtype = roivapdu->operation_value;
		break;

	/*
	 *  Computing function services
	 */

	case OV_ROUTEREQUEST:
	case OV_REROUTEREQUEST:
	case OV_ROUTESELECTREQUEST:
	case OV_ROUTEUSEDREQUEST:
	case OV_ROUTEENDREQUEST:

		/* data =  (roivapdu->argument.value); */
		table = Computing_function_services_request_handlers;
		subtype = roivapdu->operation_value;
		break;


	/*
	 *  Bidirectional services
	 */

	case OV_ESCAPESERVICE:
	case OV_SYSTEMSTATUS:

		/* data =  (roivapdu->argument.value);*/
		table = Bidirectional_services_request_handlers;
		subtype = roivapdu->operation_value;
		break;

	/*
	 *  Status reporting services
	 */

	case OV_MONITORSTART:
	case OV_CHANGEMONITORFILTER:
	case OV_MONITORSTOP:
	case OV_SNAPSHOTDEVICE:
	case OV_SNAPSHOTCALL:

		/* data =  (roivapdu->argument.value);*/
		table = Status_reporting_services_request_handlers;
		subtype = roivapdu->operation_value;
		break;


	/*
	 *  Input/output services
	 */

	case OV_STARTDATAPATH:
	case OV_STOPDATAPATH:
	case OV_SENDDATA:
	case OV_SENDMULTICASTDATA:
	case OV_SENDBROADCASTDATA:
	case OV_SUSPENDDATAPATH:
	case OV_DATAPATHSUSPENDED:
	case OV_RESUMEDATAPATH:
	case OV_DATAPATHRESUMED:
	case OV_FASTDATA:

		/*data =  (roivapdu->argument.value); */
		table = Input_output_services_request_handlers;
		subtype = roivapdu->operation_value;
		break;

	/*
	 *  Voice unit services
	 */

	case OV_CONCATENATEMESSAGE:
	case OV_DELETEMESSAGE:
	case OV_PLAYMESSAGE:
	case OV_QUERYVOICEATTRIBUTE:
	case OV_RECORDMESSAGE:
	case OV_REPOSITION:
	case OV_RESUME:
	case OV_REVIEW:
	case OV_SETVOICEATTRIBUTE:
	case OV_STOP:
	case OV_SUSPEND:
	case OV_SYNTHESIZEMESSAGE:

		/* data =  (roivapdu->argument.value); */
		table = Voice_unit_services_request_handlers;
		subtype = roivapdu->operation_value;
		break;

	}

	if (table)
	{
		handler = find_handler(subtype, table);
		if (handler)
		{
			status = handler(sd, (void *) roivapdu);
		}
	}

	return status;
}

static inline int
received_ROSEAPDUS_RORS_APDU(CONNHANDLE sd, ROSEapdus *pdu)
{
	int status = -1;
	RORSapdu *rorsapdu = pdu->a.rors_apdu;
	message_handler handler;
	long subtype = -1;


	if (rorsapdu->rORSapduSeq)
	{
		switch (rorsapdu->rORSapduSeq->operation_value)
		{

		/*
		 *  Bidirectional services
		 */

		case OV_ESCAPESERVICE:
		case OV_SYSTEMSTATUS:

/*
			data =  (rorsapdu->rORSapduSeq->result.value);
			table = Bidirectional_services_response_handlers;
			subtype = rorsapdu->rORSapduSeq->operation_value;
*/
			break;

		}

	}

	return status;
}

static inline int
received_ROSEAPDUS_ROER_APDU(CONNHANDLE sd, ROSEapdus *pdu)
{
	ROERapdu *roerapdu = pdu->a.roer_apdu;

	fprintf(logfile, "\nreceived_ROSEAPDUS_ROER_APDU");

	return 0;
}

static inline int
received_ROSEAPDUS_RORJ_APDU(CONNHANDLE sd, ROSEapdus *pdu)
{
	RORJapdu *rorjapdu = pdu->a.rorj_apdu;

	fprintf(logfile, "\nreceived_ROSEAPDUS_RORJ_APDU");
	PrintRORJapdu(logfile, rorjapdu, 0);

	return 0;
}
