/*
 * call_table.cpp
 *
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */

#ifdef WIN32
#ifdef CSTADLL
#define CSTADLLIMPORTEXPORT __declspec(dllexport)
#else
#define CSTADLLIMPORTEXPORT __declspec(dllimport)
#endif /* CSTADLL */
#else
#define CSTADLLIMPORTEXPORT
#endif /* WIN32 */

#include <stlport/iosfwd>
#include <stlport/new>
#include <stlport/memory>
#include <stlport/string>
#include <stlport/hash_map>
#include <stlport/vector>
using namespace _STL;

#include "call_table.h"

call_table::
call_table()
{
	next_connid = 1;
	call_iter = calls.begin();
}

call_table::
~call_table()
{
}

connid_t call_table::
create_call(void)
{
	call_t *new_call;
	connid_t connid = 0;

	new_call = new(call_t);
	connid = ++next_connid;
	calls[connid] = *new_call;

	return connid;
}

int call_table::
destroy_call(connid_t connid)
{
	call_map::iterator i;

	i = calls.find(connid);
	if (i != calls.end())
	{
		calls.erase(i);
	}

	return 0;
}

connection_t *call_table::
find_connection(connid_t connid, device_t device)
{
	connection_list::iterator conn_iter;
	connection_list::iterator conn_end;
	connection_t *connection = 0;

	call_iter = calls.find(connid);
	if (call_iter != calls.end())
	{
		conn_iter = (*call_iter).second.connections.begin();
		conn_end = (*call_iter).second.connections.end();
		for ( ; conn_iter != conn_end ; conn_iter++)
		{
			if (conn_iter->device == device)
			{
				break;
			}
		}
		if (conn_iter != conn_end)
		{
			connection = conn_iter;
		}
	}

	return connection;
}

int call_table::
add_device(connid_t connid, device_t device, int state, int role)
{
	int status = 0;
	connection_t *connection;

	connection = find_connection(connid, device);
	if (connection == 0)
	{
		connection = new(connection_t);
		connection->device = device;
		connection->connid = connid;
		connection->state = state;
		connection->role = role;

		/*
		 *  The private member call_iter is set when
		 *  find_connection is called.
		 */

		(*call_iter).second.connections.push_back(*connection);
	}
	else
	{
		status = -1;
	}

	return status;
}

int call_table::
remove_device(connid_t connid, device_t device)
{
	int status = 0;
	connection_t *connection;

	connection = find_connection(connid, device);
	if (connection)
	{
		(*call_iter).second.connections.erase(connection);
	}

	return status;
}

int call_table::
set_connection_state(connid_t connid, device_t device, int state)
{
	int status = 0;
	connection_t *connection;

	connection = find_connection(connid, device);
	if (connection)
	{
		connection->state = state;
	}
	else
	{
		status = -1;
	}

	return status;
}

int call_table::
get_connection_state(connid_t connid, device_t device)
{
	int state;
	connection_t *connection;

	connection = find_connection(connid, device);
	if (connection)
	{
		state = connection->state;
	}
	else
	{
		state = 0;
	}

	return state;
}

int call_table::
set_device_role(connid_t connid, device_t device, int role)
{
	int status = 0;
	connection_t *connection;

	connection = find_connection(connid, device);
	if (connection)
	{
		connection->role = role;
	}
	else
	{
		status = -1;
	}

	return status;
}

int call_table::
get_device_role(connid_t connid, device_t device)
{
	int role;
	connection_t *connection;

	connection = find_connection(connid, device);
	if (connection)
	{
		role = connection->role;
	}
	else
	{
		role = 0;
	}

	return role;
}

device_t *call_table::
get_device_by_role(connid_t connid, int role)
{
	connection_list::iterator conn_iter;
	connection_list::iterator conn_end;
	connection_t *connection = 0;
	device_t *device = 0;

	call_iter = calls.find(connid);
	if (call_iter != calls.end())
	{
		conn_iter = (*call_iter).second.connections.begin();
		conn_end = (*call_iter).second.connections.end();
		for ( ; conn_iter != conn_end ; conn_iter++)
		{
			if (conn_iter->role == role)
			{
				break;
			}
		}
		if (conn_iter != conn_end)
		{
			device = (device_t *) conn_iter->device.c_str();
		}
	}

	return device;
}

device_list call_table::
get_devices_for_call(connid_t connid)
{
	connection_list::iterator conn_iter;
	connection_list::iterator conn_end;
	device_list devices;

	call_iter = calls.find(connid);
	if (call_iter != calls.end())
	{
		conn_iter = (*call_iter).second.connections.begin();
		conn_end = (*call_iter).second.connections.end();
		for ( ; conn_iter != conn_end ; conn_iter++)
		{
			devices.push_back(conn_iter->device);
		}
	}

	return devices;
}

long call_table::
get_connection_count(connid_t connid)
{
	call_iter = calls.find(connid);
	if (call_iter != calls.end())
	{
		return (*call_iter).second.connections.size();
	}

	return 0;
}
