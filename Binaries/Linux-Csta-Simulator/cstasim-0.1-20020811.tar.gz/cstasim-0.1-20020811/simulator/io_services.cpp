/*
 * io_services.cpp
 *
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */

#ifdef WIN32
#ifdef CSTADLL
#define CSTADLLIMPORTEXPORT __declspec(dllexport)
#else
#define CSTADLLIMPORTEXPORT __declspec(dllimport)
#endif /* CSTADLL */
#else
#define CSTADLLIMPORTEXPORT
#endif /* WIN32 */

#include <stlport/iosfwd>
#include <stlport/new>
using namespace _STL;


#include <time.h>

extern "C"
{
#include "asn-incl.h"
#include "csta_defs.h"
}
#include "csta_config.h"
#include "csta_api.h"
#include "csta_request_api.h"
#include "csta_response_api.h"
#include "csta_event_api.h"
extern "C"
{
#include "log.h"
#include "tspsock.h"
}
#include "cstasim.h"
#include "tables.h"
#include "io_services.h"


extern FILE *logfile;

#define DEBUG_CSTATEST




handler_entry Input_output_services_request_handlers[] =
{
	OV_STARTDATAPATH,	received_roiv_STARTDATAPATH,
	OV_STOPDATAPATH,	received_roiv_STOPDATAPATH,
	OV_SENDDATA,		received_roiv_SENDDATA,
	OV_SENDMULTICASTDATA,	received_roiv_SENDMULTICASTDATA,
	OV_SENDBROADCASTDATA,	received_roiv_SENDBROADCASTDATA,
	OV_SUSPENDDATAPATH,	received_roiv_SUSPENDDATAPATH,
	OV_DATAPATHSUSPENDED,	received_roiv_DATAPATHSUSPENDED,
	OV_RESUMEDATAPATH,	received_roiv_RESUMEDATAPATH,
	OV_DATAPATHRESUMED,	received_roiv_DATAPATHRESUMED,
	OV_FASTDATA,		received_roiv_FASTDATA,
	-1,			NULL
};

static int
received_roiv_STARTDATAPATH(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_STARTDATAPATH\n");
	return 0;
}

static int
received_roiv_STOPDATAPATH(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_STOPDATAPATH\n");
	return 0;
}

static int
received_roiv_SENDDATA(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_SENDDATA\n");
	return 0;
}

static int
received_roiv_SENDMULTICASTDATA(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_SENDMULTICASTDATA\n");
	return 0;
}

static int
received_roiv_SENDBROADCASTDATA(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_SENDBROADCASTDATA\n");
	return 0;
}

static int
received_roiv_SUSPENDDATAPATH(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_SUSPENDDATAPATH\n");
	return 0;
}

static int
received_roiv_DATAPATHSUSPENDED(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_DATAPATHSUSPENDED\n");
	return 0;
}

static int
received_roiv_RESUMEDATAPATH(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_RESUMEDATAPATH\n");
	return 0;
}

static int
received_roiv_DATAPATHRESUMED(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_DATAPATHRESUMED\n");
	return 0;
}

static int
received_roiv_FASTDATA(CONNHANDLE sd, void *data)
{
	ROIVapdu *roivapdu = (ROIVapdu *) data;
	ClearConnectionArgument *request = (ClearConnectionArgument *) roivapdu->argument.value;

	fprintf(logfile, "received_roiv_FASTDATA\n");
	return 0;
}
