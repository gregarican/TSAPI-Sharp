#include <ace/Basic_Types.h>

/*
 *  Below are the parameter size contraints imposed by
 *  CSTA phase II.  As well as definitions of the primitive
 *  type used by the system.
 */

#define MAX_APLLICATION_CORRELATOR_SIZE	32
#define MAX_PUBLIC_TON			32
#define MAX_PRIVATE_TON			32
#define MAX_NUMBER_DIGITS		32
#define MAX_DYNAMIC_ID			32
#define MAX_AGENT_ID			16
#define MAX_AGENT_PASSWORD		16
#define MAX_ACCOUNT_INFO		32
#define MAX_AUTH_CODE			16
#define MAX_SETUP_VALUES		260
#define MAX_IO_DATA			8192
#define MAX_MESSAGE_ID			256


/*
 *  The specification states the call part of a ConnectionID
 *  can be up to eight bytes.  Some clients won't work with
 *  this value.

typedef ACE_UINT64 connid_t;

 */

typedef ACE_UINT32 connid_t;
typedef ACE_UINT32 monitorid_t;
typedef char application_correlator_t[MAX_APLLICATION_CORRELATOR_SIZE];
typedef char public_ton_t[MAX_APLLICATION_CORRELATOR_SIZE];
typedef char private_ton_t[MAX_APLLICATION_CORRELATOR_SIZE];
typedef char device_t[MAX_NUMBER_DIGITS];
typedef ACE_UINT32 device_number_t;
typedef char dynamicid_t[MAX_DYNAMIC_ID];
typedef char agentid_t[MAX_AGENT_ID];
typedef char agent_password_t[MAX_AGENT_PASSWORD];
typedef char account_info_t[MAX_ACCOUNT_INFO];
typedef char auth_code_t[MAX_AUTH_CODE];
typedef char setup_values_t[MAX_SETUP_VALUES];
typedef ACE_UINT32 routing_crossrefid_t;
typedef ACE_UINT32 review_variable_t;
typedef ACE_UINT32 period_t;
typedef ACE_UINT32 speed_t;
typedef ACE_UINT16 number_ahead_in_queue_t;
typedef ACE_UINT16 number_in_queue_t;
typedef ACE_UINT32 io_crossrefid_t;
typedef char io_data_t[MAX_IO_DATA];
typedef char messageid_t[MAX_IO_DATA];

