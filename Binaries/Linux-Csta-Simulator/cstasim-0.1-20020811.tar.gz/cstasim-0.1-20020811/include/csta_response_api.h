


#ifndef	_CSTA_RESPONSE_H_
#define	_CSTA_RESPONSE_H_


#ifdef __cplusplus
extern "C"
{
#endif

/* Basic Call Control Services*/

CSTADLLIMPORTEXPORT int
csta_failure_response(
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	UniversalFailure::UniversalFailureChoiceId error_class,
	int error
);

CSTADLLIMPORTEXPORT int csta_response_AlternateCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_AnswerCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_AssociateData (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_CallCompletion (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_ClearCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_ClearConnection (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_ConferenceCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_ConsultationCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_DivertCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_HoldCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_MakeCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_MakePredictiveCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_ParkCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_QueryDevice (
        char *buff,
        int buff_len,
        InvokeIDType invokeID,
        device_t device,
        QueryDeviceFeature feature,
        CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_ReconnectCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_RetrieveCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_SendDTMFTones (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_SetFeature (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_SingleStepConference (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_SingleStepTransfer (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_TransferCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
);

/*
 *  Status Reporting Services
 */

CSTADLLIMPORTEXPORT int csta_response_MonitorStart (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	monitorid_t monitorCrossRefID,
	MonitorFilter *monitorFilter,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_ChangeMonitorFilter (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	MonitorFilter *filterlist,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_response_MonitorStop (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

/* Snapshot Services*/

CSTADLLIMPORTEXPORT int csta_SnapshotCallReq (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	ConnectionID *snapshotObj,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_SnapshotDeviceReq (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	DeviceID *snapshotObj,
	CSTAPrivateData *privateData
);

/* Routing Services*/

CSTADLLIMPORTEXPORT int csta_RouteRegisterReq (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	DeviceID *routingDevice,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_RouteRegisterCancel (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	/*RouteRegisterReqID routeRegisterReqID, FIXME */
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_RouteSelect (
	char *buff,
	int buff_len,
	/*RouteRegisterReqID routeRegisterReqID, FIXME */
	RoutingCrossRefID routingCrossRefID,
	DeviceID *routeSelected,
	RetryValue remainRetry,
	SetupValues *setupInformation,
	AsnBool routeUsedReq,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_RouteEnd (
	char *buff,
	int buff_len,
	RoutingCrossRefID routingCrossRefID,
	UniversalFailure errorValue,
	CSTAPrivateData *privateData
);

/* Escape Services*/

CSTADLLIMPORTEXPORT int csta_EscapeService (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_EscapeServiceConf (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	UniversalFailure error,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_SendPrivateEvent (
	char *buff,
	int buff_len,
	CSTAPrivateData *privateData
);

/* Maintenance Services*/

CSTADLLIMPORTEXPORT int csta_SysStatReq (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_SysStatStart (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	/*SystemStatusFilter statusFilter, FIXME */
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_SysStatStop (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_ChangeSysStatFilter (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	/*SystemStatusFilter statusFilter, FIXME */
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_SysStatReqConf (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	SystemStatus systemStatus,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_SysStatEvent (
	char *buff,
	int buff_len,
	SystemStatus systemStatus,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_GetAPICaps (
	char *buff,
	int buff_len,
	InvokeIDType invokeID
);

CSTADLLIMPORTEXPORT int csta_QueryCallMonitor (
	char *buff,
	int buff_len,
	InvokeIDType invokeID
);


#ifdef __cplusplus
}
#endif

#endif
