


#ifndef	_CSTA_REQUEST_H_
#define	_CSTA_REQUEST_H_



#ifdef __cplusplus
extern "C"
{
#endif

/* Basic Call Control Services*/

CSTADLLIMPORTEXPORT int csta_request_AlternateCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t activecall,
	connid_t heldcall,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_AnswerCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_request_AssociateData (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	char *accountCode,
	char *authCode,
	char *correlatorData,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_CallCompletion (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	int feature,
	ConnectionID *call,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_ClearCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	connid_t connid,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_ClearConnection (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_ConferenceCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t activecall,
	connid_t heldcall,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_ConsultationCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t calling_device,
	connid_t activecall,
	device_t called_device,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_DivertCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	int diversion_type,
	device_t source,
	connid_t connid,
	device_t destination,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_HoldCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	AsnBool reservation,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_MakeCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t callingDevice,
	device_t calledDevice,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_MakePredictiveCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t callingDevice,
	device_t calledDevice,
	AllocationState allocationState,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_ParkCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t callToPark,
	device_t parkTo,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_QueryDevice (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	QueryDeviceFeature feature,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_ReconnectCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t conn_to_clear,
	connid_t conn_to_retrieve,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_RetrieveCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t heldCall,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_request_SendDTMFTones (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	char *charactersToSend,
	int toneDuration,
	int pauseDuration,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_SetMessageWaiting (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	int state,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_SetDoNotDisturb (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	int state,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_SetForwarding (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	ForwardingType forwardingType,
	int forwardingOn,
	device_t forwardingDestination,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_SetAgentState (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	AgentParameter::AgentParameterChoiceId agentMode,
	agentid_t agentID,
	device_t agentGroup,
	agent_password_t agentPassword,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_request_EnableRouting (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	int state,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_request_AutoAnswer (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	int state,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_request_MicrophoneMute (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	int state,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_request_SpeakerMute (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	int state,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_request_SpeakerVolume (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	int level,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_request_SingleStepConference (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t calling_device,
	connid_t existingcall,
	device_t deviceToJoin,
	ParticipationType participation,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_request_SingleStepTransfer (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t calling_device,
	connid_t existingcall,
	device_t destination,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_TransferCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t activecall,
	connid_t heldcall,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_QueryMsgWaitingInd (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	DeviceID *device,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_QueryDoNotDisturb (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	DeviceID *device,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_QueryForwarding (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	DeviceID *device,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_QueryAgentState (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	DeviceID *device,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_QueryLastNumber (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	DeviceID *device,
	CSTAPrivateData *privateData
);

/* Monitor Services*/

CSTADLLIMPORTEXPORT int csta_request_MonitorStart (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	MonitorFilter *monitorFilter,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_ChangeMonitorFilter (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	monitorid_t monitorid,
	MonitorFilter *filterlist,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_MonitorStop (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	monitorid_t monitorCrossRefID,
	CSTAPrivateData *privateData
);

/* Snapshot Services*/

CSTADLLIMPORTEXPORT int csta_request_SnapshotCallReq (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	ConnectionID *snapshotObj,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_SnapshotDeviceReq (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	DeviceID *snapshotObj,
	CSTAPrivateData *privateData
);

/* Routing Services*/

CSTADLLIMPORTEXPORT int csta_request_RouteRegisterReq (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	DeviceID *routingDevice,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_RouteRegisterCancel (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	/*RouteRegisterReqID routeRegisterReqID, FIXME */
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_RouteSelect (
	char *buff,
	int buff_len,
	/*RouteRegisterReqID routeRegisterReqID, FIXME */
	RoutingCrossRefID routingCrossRefID,
	DeviceID *routeSelected,
	RetryValue remainRetry,
	SetupValues *setupInformation,
	AsnBool routeUsedReq,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_RouteEnd (
	char *buff,
	int buff_len,
	RoutingCrossRefID routingCrossRefID,
	UniversalFailure errorValue,
	CSTAPrivateData *privateData
);

/* Escape Services*/

CSTADLLIMPORTEXPORT int csta_request_EscapeService (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_EscapeServiceConf (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	UniversalFailure error,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_SendPrivateEvent (
	char *buff,
	int buff_len,
	CSTAPrivateData *privateData
);

/* Maintenance Services*/

CSTADLLIMPORTEXPORT int csta_request_SysStatReq (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_SysStatStart (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	/*SystemStatusFilter statusFilter, FIXME */
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_SysStatStop (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_ChangeSysStatFilter (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	/*SystemStatusFilter statusFilter, FIXME */
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_SysStatReqConf (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	SystemStatus systemStatus,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_SysStatEvent (
	char *buff,
	int buff_len,
	SystemStatus systemStatus,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int csta_request_GetAPICaps (
	char *buff,
	int buff_len,
	InvokeIDType invokeID
);

CSTADLLIMPORTEXPORT int csta_request_QueryCallMonitor (
	char *buff,
	int buff_len,
	InvokeIDType invokeID
);


#ifdef __cplusplus
}
#endif

#endif
