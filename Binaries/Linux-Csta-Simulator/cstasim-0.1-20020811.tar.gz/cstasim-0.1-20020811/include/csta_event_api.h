
#ifndef _CSTA_EVENT_API_H_
#define _CSTA_EVENT_API_H_


#ifdef __cplusplus
extern "C"
{
#endif


CSTADLLIMPORTEXPORT int
csta_AgentBusyEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	device_t device,
	agentid_t agentid,
	device_t group,
	EventCause cause,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_LoggedOnEvent (
        char *buff,
        int len,
	MonitorCrossRefID crossRefIdentifier,
        device_t device,
        agentid_t agentid,
        agent_password_t password,
        device_t group,
        EventCause cause,
        CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_LoggedOffEvent (
        char *buff,
        int len,
	MonitorCrossRefID crossRefIdentifier,
        device_t device,
        agentid_t agentid,
        agent_password_t password,
        device_t group,
        EventCause cause,
        CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_NotReadyEvent (
        char *buff,
        int len,
	MonitorCrossRefID crossRefIdentifier,
        device_t device,
        agentid_t agentid,
        EventCause cause,
        CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_ReadyEvent (
        char *buff,
        int len,
	MonitorCrossRefID crossRefIdentifier,
        device_t device,
        agentid_t agentid,
        EventCause cause,
        CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_WorkingAfterCallEvent (
        char *buff,
        int len,
	MonitorCrossRefID crossRefIdentifier,
        device_t device,
        agentid_t agentid,
        EventCause cause,
        device_t group,
        CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_encode_CallClearedEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	CallClearedEvent *callClearedEvent,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_encode_ConnectionClearedEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	ConnectionClearedEvent *connectionClearedEvent,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_encode_DeliveredEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	DeliveredEvent *deliveredEvent,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_encode_EstablishedEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	EstablishedEvent *establishedEvent,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_encode_HeldEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	HeldEvent *heldEvent,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_encode_OriginatedEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	OriginatedEvent *originatedEvent,
	CSTAPrivateData *privateData
);

CSTADLLIMPORTEXPORT int
csta_encode_ServiceInitiatedEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	ServiceInitiatedEvent *serviceInitiatedEvent,
	CSTAPrivateData *privateData
);

#ifdef __cplusplus
}
#endif

#endif /* _CSTA_EVENT_API_H_ */
