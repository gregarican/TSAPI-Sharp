/* -*- C++ -*- */
// config-aix-4.1.x.h,v 4.41 2001/09/05 15:52:29 shuston Exp

#ifndef ACE_AIX_VERS
# define ACE_AIX_VERS 401
#endif

#include "ace/config-aix-4.x.h"
