/* -*- C++ -*- */
// config-sco-5.0.0-fsu-pthread.h,v 4.18 2000/03/23 21:27:02 nanbor Exp

#ifndef ACE_CONFIG_H
#define ACE_CONFIG_H
#include "ace/pre.h"

#include "ace/config-g++-common.h"
#include "ace/config-sco-5.0.0.h"
#include "ace/config-fsu-pthread.h"

#define ACE_HAS_GNU_CSTRING_H

#include "ace/post.h"
#endif /* ACE_CONFIG_H */
