/* -*- C++ -*- */
// config-aix-4.2.x.h,v 4.39 2001/09/05 15:52:48 shuston Exp

#ifndef ACE_AIX_VERS
# define ACE_AIX_VERS 402
#endif

#include "ace/config-aix-4.x.h"
