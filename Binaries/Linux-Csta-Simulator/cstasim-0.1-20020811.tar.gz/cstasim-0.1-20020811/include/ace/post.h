/* -*- C++ -*- */

//=============================================================================
/**
 *  @file    post.h
 *
 *  post.h,v 4.2 2000/11/01 22:17:39 coryan Exp
 *
 *  @author Christopher Kohlhoff <chris@kohlhoff.com>
 *
 *  This file restore the original alignment rules.
 *
 *
 */
//=============================================================================


// No header guard
#if defined (_MSC_VER)
# pragma pack (pop)
#elif defined (__BORLANDC__)
# pragma option pop
# pragma nopushoptwarn
# pragma nopackwarning
#endif
