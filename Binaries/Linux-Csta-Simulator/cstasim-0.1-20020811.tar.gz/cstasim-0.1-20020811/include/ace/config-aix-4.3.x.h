/* -*- C++ -*- */
// config-aix-4.3.x.h,v 1.3 2001/09/05 15:53:15 shuston Exp

#ifndef ACE_AIX_VERS
# define ACE_AIX_VERS 403
#endif

#include "ace/config-aix-4.x.h"
