/* -*- C++ -*- */
// config-mklinux.h,v 4.5 2000/03/23 21:27:02 nanbor Exp

// The following configuration file is designed to work for MkLinux
// platforms using GNU C++.

#ifndef ACE_CONFIG_H
#define ACE_CONFIG_H
#include "ace/pre.h"

#include "ace/config-linux-common.h"

#define ACE_HAS_SVR4_DYNAMIC_LINKING
#define ACE_HAS_AUTOMATIC_INIT_FINI

#undef ACE_HAS_SOCKLEN_T
#define ACE_HAS_SIZET_SOCKET_LEN

#include "ace/post.h"
#endif /* ACE_CONFIG_H */
