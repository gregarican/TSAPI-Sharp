// config-aix5.1.h,v 1.2 2002/01/25 23:32:39 shuston Exp
//
// Config file for AIX 5.1

#include "ace/config-aix-4.x.h"

// I think this is correct, but needs to be verified...   -Steve Huston
#define ACE_HAS_SIGTIMEDWAIT
