/*
 *
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */

#ifdef WIN32
#ifdef CSTADLL
#define CSTADLLIMPORTEXPORT __declspec(dllexport)
#else
#define CSTADLLIMPORTEXPORT __declspec(dllimport)
#endif /* CSTADLL */
#else
#define CSTADLLIMPORTEXPORT
#endif /* WIN32 */

extern "C"
{
#include "asn-incl.h"
}
#include "csta_defs.h"
#include "csta_config.h"
#include "csta_api.h"
#include "csta_event_api.h"



#ifdef __cplusplus
extern "C"
{
#endif


extern int encode_roiv_apdu(char *, int, InvokeIDType, void *, AsnInt);
int encode_event_report(char *, int, MonitorCrossRefID crossRefIdentifier, void *, EventSpecificInfo::EventSpecificInfoChoiceId);

int
csta_AgentBusyEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	device_t device,
	agentid_t agentid,
	device_t group,
	EventCause cause,
	CSTAPrivateData *privateData)
{
	AgentStateEvent *args;


	args = (AgentStateEvent *) Asn1Alloc(sizeof(AgentStateEvent));
	args->choiceId = AgentStateEvent::AGENTSTATEEVENT_AGENTBUSYEVENT;
	args->a.agentBusyEvent = (AgentBusyEvent *) Asn1Alloc(sizeof(AgentBusyEvent));
	args->a.agentBusyEvent->agentDevice = (SubjectDeviceID *) Asn1Alloc(sizeof(SubjectDeviceID));
	args->a.agentBusyEvent->agentDevice->choiceId = SubjectDeviceID::SUBJECTDEVICEID_DEVICEIDENTIFIER;
	args->a.agentBusyEvent->agentDevice->a.deviceIdentifier = (ExtendedDeviceID *) Asn1Alloc(sizeof(ExtendedDeviceID));
	args->a.agentBusyEvent->agentDevice->a.deviceIdentifier->choiceId = ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER;
	args->a.agentBusyEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier = (DeviceID *) Asn1Alloc(sizeof(DeviceID));
	args->a.agentBusyEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->choiceId = DeviceID::DEVICEID_DIALINGNUMBER;
	args->a.agentBusyEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->a.dialingNumber =
										(NumberDigits *) Asn1Alloc(sizeof(NumberDigits));
	setoctet(args->a.agentBusyEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->a.dialingNumber, device);

	if (agentid && strlen(agentid))
	{
		setoctet(&args->a.agentBusyEvent->agentID, agentid);
	}
	if (group && strlen(group))
	{
		args->a.agentBusyEvent->agentGroup = (AgentGroup *) Asn1Alloc(sizeof(AgentGroup));
		args->a.agentBusyEvent->agentGroup->choiceId = DeviceID::DEVICEID_DIALINGNUMBER;
		args->a.agentBusyEvent->agentGroup->a.dialingNumber = (NumberDigits *) Asn1Alloc(sizeof(NumberDigits));
		setoctet(args->a.agentBusyEvent->agentGroup->a.dialingNumber, group);
	}
	args->a.agentBusyEvent->cause = &cause;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_event_report(buff, len, crossRefIdentifier, (void *) args, EventSpecificInfo::EVENTSPECIFICINFO_AGENTSTATEEVENT);

}

int
csta_LoggedOnEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	device_t device,
	agentid_t agentid,
	agent_password_t password,
	device_t group,
	EventCause cause,
	CSTAPrivateData *privateData)
{
	AgentStateEvent *args;


	args = (AgentStateEvent *) Asn1Alloc(sizeof(AgentStateEvent));
	args->choiceId = AgentStateEvent::AGENTSTATEEVENT_LOGGEDONEVENT;
	args->a.loggedOnEvent = (LoggedOnEvent *) Asn1Alloc(sizeof(LoggedOnEvent));
	args->a.loggedOnEvent->agentDevice = (SubjectDeviceID *) Asn1Alloc(sizeof(SubjectDeviceID));
	args->a.loggedOnEvent->agentDevice->choiceId = SubjectDeviceID::SUBJECTDEVICEID_DEVICEIDENTIFIER;
	args->a.loggedOnEvent->agentDevice->a.deviceIdentifier = (ExtendedDeviceID *) Asn1Alloc(sizeof(ExtendedDeviceID));
	args->a.loggedOnEvent->agentDevice->a.deviceIdentifier->choiceId = ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER;
	args->a.loggedOnEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier = (DeviceID *) Asn1Alloc(sizeof(DeviceID));
	args->a.loggedOnEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->choiceId = DeviceID::DEVICEID_DIALINGNUMBER;
	args->a.loggedOnEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->a.dialingNumber =
											(NumberDigits *) Asn1Alloc(sizeof(NumberDigits));
	setoctet(args->a.loggedOnEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->a.dialingNumber, device);

	if (agentid && strlen(agentid))
	{
		setoctet(&args->a.loggedOnEvent->agentID, agentid);
	}
	if (password && strlen(password))
	{
		setoctet(&args->a.loggedOnEvent->password, password);
	}
	if (group && strlen(group))
	{
		args->a.loggedOnEvent->agentGroup = (AgentGroup *) Asn1Alloc(sizeof(AgentGroup));
		args->a.loggedOnEvent->agentGroup->choiceId = DeviceID::DEVICEID_DIALINGNUMBER;
		args->a.loggedOnEvent->agentGroup->a.dialingNumber = (NumberDigits *) Asn1Alloc(sizeof(NumberDigits));
		setoctet(args->a.loggedOnEvent->agentGroup->a.dialingNumber, group);
	}
	args->a.loggedOnEvent->cause = &cause;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_event_report(buff, len, crossRefIdentifier, (void *) args, EventSpecificInfo::EVENTSPECIFICINFO_AGENTSTATEEVENT);

}

int
csta_LoggedOffEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	device_t device,
	agentid_t agentid,
	agent_password_t password,
	device_t group,
	EventCause cause,
	CSTAPrivateData *privateData)
{
	AgentStateEvent *args;


	args = (AgentStateEvent *) Asn1Alloc(sizeof(AgentStateEvent));
	args->choiceId = AgentStateEvent::AGENTSTATEEVENT_LOGGEDOFFEVENT;
	args->a.loggedOffEvent = (LoggedOffEvent *) Asn1Alloc(sizeof(LoggedOffEvent));
	args->a.loggedOffEvent->agentDevice = (SubjectDeviceID *) Asn1Alloc(sizeof(SubjectDeviceID));
	args->a.loggedOffEvent->agentDevice->choiceId = SubjectDeviceID::SUBJECTDEVICEID_DEVICEIDENTIFIER;
	args->a.loggedOffEvent->agentDevice->a.deviceIdentifier = (ExtendedDeviceID *) Asn1Alloc(sizeof(ExtendedDeviceID));
	args->a.loggedOffEvent->agentDevice->a.deviceIdentifier->choiceId = ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER;
	args->a.loggedOffEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier = (DeviceID *) Asn1Alloc(sizeof(DeviceID));
	args->a.loggedOffEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->choiceId = DeviceID::DEVICEID_DIALINGNUMBER;
	args->a.loggedOffEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->a.dialingNumber =
												(NumberDigits *) Asn1Alloc(sizeof(NumberDigits));
	setoctet(args->a.loggedOffEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->a.dialingNumber, device);

	if (agentid && strlen(agentid))
	{
		setoctet(&args->a.loggedOffEvent->agentID, agentid);
	}
	if (password && strlen(password))
	{
		setoctet(&args->a.loggedOffEvent->password, password);
	}
	if (group && strlen(group))
	{
		args->a.loggedOffEvent->agentGroup = (AgentGroup *) Asn1Alloc(sizeof(AgentGroup));
		args->a.loggedOffEvent->agentGroup->choiceId = DeviceID::DEVICEID_DIALINGNUMBER;
		args->a.loggedOffEvent->agentGroup->a.dialingNumber = (NumberDigits *) Asn1Alloc(sizeof(NumberDigits));
		setoctet(args->a.loggedOffEvent->agentGroup->a.dialingNumber, group);
	}
	args->a.loggedOffEvent->cause = &cause;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_event_report(buff, len, crossRefIdentifier, (void *) args, EventSpecificInfo::EVENTSPECIFICINFO_AGENTSTATEEVENT);

}

int
csta_NotReadyEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	device_t device,
	agentid_t agentid,
	EventCause cause,
	CSTAPrivateData *privateData)
{
	AgentStateEvent *args;


	args = (AgentStateEvent *) Asn1Alloc(sizeof(AgentStateEvent));
	args->choiceId = AgentStateEvent::AGENTSTATEEVENT_NOTREADYEVENT;
	args->a.notReadyEvent = (NotReadyEvent *) Asn1Alloc(sizeof(NotReadyEvent));
	args->a.notReadyEvent->agentDevice = (SubjectDeviceID *) Asn1Alloc(sizeof(SubjectDeviceID));
	args->a.notReadyEvent->agentDevice->choiceId = SubjectDeviceID::SUBJECTDEVICEID_DEVICEIDENTIFIER;
	args->a.notReadyEvent->agentDevice->a.deviceIdentifier = (ExtendedDeviceID *) Asn1Alloc(sizeof(ExtendedDeviceID));
	args->a.notReadyEvent->agentDevice->a.deviceIdentifier->choiceId = ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER;
	args->a.notReadyEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier = (DeviceID *) Asn1Alloc(sizeof(DeviceID));
	args->a.notReadyEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->choiceId = DeviceID::DEVICEID_DIALINGNUMBER;
	args->a.notReadyEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->a.dialingNumber =
										(NumberDigits *) Asn1Alloc(sizeof(NumberDigits));
	setoctet(args->a.notReadyEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->a.dialingNumber, device);

	if (agentid && strlen(agentid))
	{
		setoctet(&args->a.notReadyEvent->agentID, agentid);
	}
	args->a.notReadyEvent->cause = &cause;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_event_report(buff, len, crossRefIdentifier, (void *) args, EventSpecificInfo::EVENTSPECIFICINFO_AGENTSTATEEVENT);

}

int
csta_ReadyEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	device_t device,
	agentid_t agentid,
	EventCause cause,
	CSTAPrivateData *privateData)
{
	AgentStateEvent *args;


	args = (AgentStateEvent *) Asn1Alloc(sizeof(AgentStateEvent));
	args->choiceId = AgentStateEvent::AGENTSTATEEVENT_READYEVENT;
	args->a.readyEvent = (ReadyEvent *) Asn1Alloc(sizeof(ReadyEvent));
	args->a.readyEvent->agentDevice = (SubjectDeviceID *) Asn1Alloc(sizeof(SubjectDeviceID));
	args->a.readyEvent->agentDevice->choiceId = SubjectDeviceID::SUBJECTDEVICEID_DEVICEIDENTIFIER;
	args->a.readyEvent->agentDevice->a.deviceIdentifier = (ExtendedDeviceID *) Asn1Alloc(sizeof(ExtendedDeviceID));
	args->a.readyEvent->agentDevice->a.deviceIdentifier->choiceId = ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER;
	args->a.readyEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier = (DeviceID *) Asn1Alloc(sizeof(DeviceID));
	args->a.readyEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->choiceId = DeviceID::DEVICEID_DIALINGNUMBER;
	args->a.readyEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->a.dialingNumber = (NumberDigits *) Asn1Alloc(sizeof(NumberDigits));
	setoctet(args->a.readyEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->a.dialingNumber, device);

	if (agentid && strlen(agentid))
	{
		setoctet(&args->a.readyEvent->agentID, agentid);
	}
	args->a.readyEvent->cause = &cause;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_event_report(buff, len, crossRefIdentifier, (void *) args, EventSpecificInfo::EVENTSPECIFICINFO_AGENTSTATEEVENT);

}

int
csta_WorkingAfterCallEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	device_t device,
	agentid_t agentid,
	EventCause cause,
	device_t group,
	CSTAPrivateData *privateData)
{
	AgentStateEvent *args;


	args = (AgentStateEvent *) Asn1Alloc(sizeof(AgentStateEvent));
	args->choiceId = AgentStateEvent::AGENTSTATEEVENT_WORKINGAFTERCALLEVENT;
	args->a.workingAfterCallEvent = (WorkingAfterCallEvent *) Asn1Alloc(sizeof(WorkingAfterCallEvent));
	args->a.workingAfterCallEvent->agentDevice = (SubjectDeviceID *) Asn1Alloc(sizeof(SubjectDeviceID));
	args->a.workingAfterCallEvent->agentDevice->choiceId = SubjectDeviceID::SUBJECTDEVICEID_DEVICEIDENTIFIER;
	args->a.workingAfterCallEvent->agentDevice->a.deviceIdentifier = (ExtendedDeviceID *) Asn1Alloc(sizeof(ExtendedDeviceID));
	args->a.workingAfterCallEvent->agentDevice->a.deviceIdentifier->choiceId = ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER;
	args->a.workingAfterCallEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier = (DeviceID *) Asn1Alloc(sizeof(DeviceID));
	args->a.workingAfterCallEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->choiceId = DeviceID::DEVICEID_DIALINGNUMBER;
	args->a.workingAfterCallEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->a.dialingNumber =
												(NumberDigits *) Asn1Alloc(sizeof(NumberDigits));
	setoctet(args->a.workingAfterCallEvent->agentDevice->a.deviceIdentifier->a.deviceIdentifier->a.dialingNumber, device);

	if (agentid && strlen(agentid))
	{
		setoctet(&args->a.workingAfterCallEvent->agentID, agentid);
	}
	if (group && strlen(group))
	{
		args->a.workingAfterCallEvent->agentGroup = (AgentGroup *) Asn1Alloc(sizeof(AgentGroup));
		args->a.workingAfterCallEvent->agentGroup->choiceId = DeviceID::DEVICEID_DIALINGNUMBER;
		args->a.workingAfterCallEvent->agentGroup->a.dialingNumber = (NumberDigits *) Asn1Alloc(sizeof(NumberDigits));
		setoctet(args->a.workingAfterCallEvent->agentGroup->a.dialingNumber, group);
	}
	args->a.workingAfterCallEvent->cause = &cause;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_event_report(buff, len, crossRefIdentifier, (void *) args, EventSpecificInfo::EVENTSPECIFICINFO_AGENTSTATEEVENT);
}

int
csta_encode_CallClearedEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	CallClearedEvent *callClearedEvent,
	CSTAPrivateData *privateData)
{
	CallEvent *args;


	args = (CallEvent *) Asn1Alloc(sizeof(CallEvent));
	args->choiceId = CallEvent::CALLEVENT_CALLCLEAREDEVENT;
	args->a.callClearedEvent = callClearedEvent;

	return encode_event_report(buff, len, crossRefIdentifier, (void *) args, EventSpecificInfo::EVENTSPECIFICINFO_CALLEVENT);
}

int
csta_encode_ConnectionClearedEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	ConnectionClearedEvent *connectionClearedEvent,
	CSTAPrivateData *privateData)
{
	CallEvent *args;


	args = (CallEvent *) Asn1Alloc(sizeof(CallEvent));
	args->choiceId = CallEvent::CALLEVENT_CONNECTIONCLEAREDEVENT;
	args->a.connectionClearedEvent = connectionClearedEvent;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_event_report(buff, len, crossRefIdentifier, (void *) args, EventSpecificInfo::EVENTSPECIFICINFO_CALLEVENT);

}

int
csta_encode_DeliveredEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	DeliveredEvent *deliveredEvent,
	CSTAPrivateData *privateData)
{
	CallEvent *args;


	args = (CallEvent *) Asn1Alloc(sizeof(CallEvent));
	args->choiceId = CallEvent::CALLEVENT_DELIVEREDEVENT;
	args->a.deliveredEvent = deliveredEvent;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_event_report(buff, len, crossRefIdentifier, (void *) args, EventSpecificInfo::EVENTSPECIFICINFO_CALLEVENT);

}

int
csta_encode_EstablishedEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	EstablishedEvent *establishedEvent,
	CSTAPrivateData *privateData)
{
	CallEvent *args;


	args = (CallEvent *) Asn1Alloc(sizeof(CallEvent));
	args->choiceId = CallEvent::CALLEVENT_ESTABLISHEDEVENT;
	args->a.establishedEvent = establishedEvent;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_event_report(buff, len, crossRefIdentifier, (void *) args, EventSpecificInfo::EVENTSPECIFICINFO_CALLEVENT);

}

int
csta_encode_HeldEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	HeldEvent *heldEvent,
	CSTAPrivateData *privateData)
{
	CallEvent *args;


	args = (CallEvent *) Asn1Alloc(sizeof(CallEvent));
	args->choiceId = CallEvent::CALLEVENT_HELDEVENT;
	args->a.heldEvent = heldEvent;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_event_report(buff, len, crossRefIdentifier, (void *) args, EventSpecificInfo::EVENTSPECIFICINFO_CALLEVENT);

}

int
csta_encode_OriginatedEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	OriginatedEvent *originatedEvent,
	CSTAPrivateData *privateData)
{
	CallEvent *args;


	args = (CallEvent *) Asn1Alloc(sizeof(CallEvent));
	args->choiceId = CallEvent::CALLEVENT_ORIGINATEDEVENT;
	args->a.originatedEvent = originatedEvent;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_event_report(buff, len, crossRefIdentifier, (void *) args, EventSpecificInfo::EVENTSPECIFICINFO_CALLEVENT);

}

int
csta_encode_ServiceInitiatedEvent (
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	ServiceInitiatedEvent *serviceInitiatedEvent,
	CSTAPrivateData *privateData)
{
	CallEvent *args;


	args = (CallEvent *) Asn1Alloc(sizeof(CallEvent));
	args->choiceId = CallEvent::CALLEVENT_SERVICEINITIATEDEVENT;
	args->a.serviceInitiatedEvent = serviceInitiatedEvent;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_event_report(buff, len, crossRefIdentifier, (void *) args, EventSpecificInfo::EVENTSPECIFICINFO_CALLEVENT);
}

int
encode_event_report(
	char *buff,
	int len,
	MonitorCrossRefID crossRefIdentifier,
	void *args,
	EventSpecificInfo::EventSpecificInfoChoiceId event)
{
	CSTAEventReportArgument *event_report_args;

	event_report_args = (CSTAEventReportArgument *) Asn1Alloc(sizeof(CSTAEventReportArgument));
	event_report_args->crossRefIdentifier = crossRefIdentifier;
	event_report_args->eventSpecificInfo = (EventSpecificInfo *) Asn1Alloc(sizeof(EventSpecificInfo));
	event_report_args->eventSpecificInfo->choiceId = event;

	/*
	 *  It is coerced to make it generic
	 */
	event_report_args->eventSpecificInfo->a.callEvent = (CallEvent *) args;


	return encode_roiv_apdu(buff, len, 0, event_report_args, OV_CSTAEVENTREPORT);
}

#ifdef __cplusplus
}
#endif
