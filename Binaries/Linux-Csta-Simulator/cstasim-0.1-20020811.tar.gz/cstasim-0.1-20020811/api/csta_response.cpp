/*
 *
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */

#ifdef WIN32
#ifdef CSTADLL
#define CSTADLLIMPORTEXPORT __declspec(dllexport)
#else
#define CSTADLLIMPORTEXPORT __declspec(dllimport)
#endif /* CSTADLL */
#else
#define CSTADLLIMPORTEXPORT
#endif /* WIN32 */

extern "C"
{
#include "asn-incl.h"
}
#include "csta_defs.h"
#include "csta_config.h"
#include "csta_api.h"
#include "csta_response_api.h"



#ifdef __cplusplus
extern "C"
{
#endif


extern AsnLen BEncROSEapdus (BUF_TYPE, ROSEapdus *);

static ExpBuf *encbuf = 0;

int encode_rors_apdu(char *, int, InvokeIDType, void *, AsnInt);

int
init_csta_response(void)
{
	int status = 0;

	encbuf = ExpBufAllocBufAndData();

	if (encbuf == 0)
	{
		status = -1;
	}

	return status;
}

#ifdef NOT_USED

/* ACSE association management */
void ACSEassociation()
{
	ACSEUserInformationForCSTA *infos;
	static ExpBuf *encbuf;
	AsnLen len;
	ACSE_apdu pdu;
	char dummy[4] = {0x00, 0x00, 0x00, 0x00};

	/* ACSE APDU */
	pdu.choiceId = ACSE_APDU_AARQ;
	pdu.a.aarq = Asn1Alloc(sizeof(AARQ_apdu));
	/* protocol_version */
	pdu.a.aarq->protocol_version.bitLen = 2;
	pdu.a.aarq->protocol_version.bits = dummy;
	SetAsnBit(&pdu.a.aarq->protocol_version, VERSION11);
	dummy[0] = 0x00; /* clean-up dummy */
	/* application_context_name */
	pdu.a.aarq->application_context_name = csta_version2;
	/* user_information (to carry CSTA protocole information) */
	pdu.a.aarq->user_information = AsnListNew(sizeof(ACSEUserInformationForCSTA));
	infos = AsnListAppend(pdu.a.aarq->user_information);
	/* CSTA version */
	SetAsnBit(&infos->cSTAVersion, VERSIONTWO);
	/* CSTA functionalities */
	infos->cSTAFunctionsRequiredByApplication = Asn1Alloc(sizeof(CSTAFunctionality));
	infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices.bitLen = 32;
	infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices.bits = dummy;
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, ALTERNATECALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, ANSWERCALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, ASSOCIATEDATA);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, CALLCOMPLETION);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, CLEARCALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, CLEARCONNECTION);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, CONFERENCECALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, CONSULTATIONCALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, DIVERTCALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, HOLDCALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, MAKECALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, MAKEPREDICTIVECALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, PARKCALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, QUERYDEVICE);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, RECONNECTCALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, RETRIEVECALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, SENDDTMFTONES);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, SETFEATURE);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, SINGLESTEPCONFERENCE);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, SINGLESTEPTRANSFER);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, TRANSFERCALL);
#ifdef DEBUG_CSTATEST
	PrintAsnBits(stdout, &infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, 0);
#endif
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->eventReportServices, DELIVERED);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->computingFunctionServices, ROUTEREQUEST);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->bidirectionalServices, SYSTEMSTATUS);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->statusReportingServices, MONITORSTART);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->inputOutputServices, SENDDATASERVICE);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->voiceUnitServices, SUSPEND);
	/* CSTA functionalities */
	infos->cSTAFunctionsThatCanBeSupplied = Asn1Alloc(sizeof(CSTAFunctionality));
	SetAsnBit(&infos->cSTAFunctionsThatCanBeSupplied->switchingFunctionServices, MAKECALL);
	SetAsnBit(&infos->cSTAFunctionsThatCanBeSupplied->eventReportServices, DELIVERED);
	SetAsnBit(&infos->cSTAFunctionsThatCanBeSupplied->computingFunctionServices, ROUTEREQUEST);
	SetAsnBit(&infos->cSTAFunctionsThatCanBeSupplied->bidirectionalServices, SYSTEMSTATUS);
	SetAsnBit(&infos->cSTAFunctionsThatCanBeSupplied->statusReportingServices, MONITORSTART);
	SetAsnBit(&infos->cSTAFunctionsThatCanBeSupplied->inputOutputServices, SENDDATASERVICE);
	SetAsnBit(&infos->cSTAFunctionsThatCanBeSupplied->voiceUnitServices, SUSPEND);

#ifdef DEBUG_CSTATEST
	PrintAsnOid(stdout, &csta_version1, 0);
#endif
	
	/* We don't use send_rors_apdu here because the ACSE APDU is a
	 * little bit special and uses a hack in csta2.asn1 */
	
	/* Initilialize the encbuf struct for scratch buffer */

	if (encbuf == NULL)
	{
		encbuf = ExpBufAllocBufAndData();
	}
	else
	{
		ExpBufResetInWriteRvsMode(encbuf);
	}


	/* Encode buffer */
	len = BEncACSE_apdu(encbuf, &pdu);
	if (ExpBufWriteError(&encbuf)) {
		fprintf(stderr, "\n");
		exit(-1);
	}

#ifdef DEBUG_CSTATEST
	/* SNACC pretty-print */
	printf("\n");
	PrintACSE_apdu(stdout, &pdu, 0);
	printf("\n");
#endif
	/*
	 * Free all of the decoded value since it has been encoded into the
	 * buffer. This is much more efficient than freeing each component of
	 * the value individually.
	 */
	ResetNibbleMem();


	/* Send the encoded PDU */
	if(tsp_write_socket(fdcsta, ExpBufDataPtr(encbuf), ExpBufDataSize(encbuf)) < 0) {
		perror("cstatest.c: ACSEassociation(): tcp_write_socket()");
		exit(-1);
	}

#ifdef DEBUG_CSTATEST
	printf("Data sent... requestID = %x\n", REQUEST_ID);
	logdump(LOG_DEBUG, ExpBufDataPtr(encbuf), ExpBufDataSize(encbuf));
#endif

}
#endif

int
csta_response_AlternateCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData)
{
	AlternateCallResult *args;

	args = (AlternateCallResult *) Asn1Alloc(sizeof(AlternateCallResult));

	if (privateData)
	{
		/* FIXME add data */
		args->a.extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		args->choiceId = AlternateCallResult::ALTERNATECALLRESULT_EXTENSIONS;
	}
	else
	{
		args->choiceId = AlternateCallResult::ALTERNATECALLRESULT_NODATA;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_ALTERNATECALL);
}

int
csta_response_AnswerCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	AnswerCallResult *args;

	args = (AnswerCallResult *) Asn1Alloc(sizeof(AnswerCallResult));

	if (privateData)
	{
		/* FIXME add data */
		args->a.extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		args->choiceId = AnswerCallResult::ANSWERCALLRESULT_EXTENSIONS;
	}
	else
	{
		args->choiceId = AnswerCallResult::ANSWERCALLRESULT_NODATA;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_ANSWERCALL);
}

int
csta_response_AssociateData (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	AssociateDataResult *args;

	args = (AssociateDataResult *) Asn1Alloc(sizeof(AssociateDataResult));

	if (privateData)
	{
		/* FIXME add data */
		args->a.extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		args->choiceId = AssociateDataResult::ASSOCIATEDATARESULT_EXTENSIONS;
	}
	else
	{
		args->choiceId = AssociateDataResult::ASSOCIATEDATARESULT_NODATA;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_ASSOCIATEDATA);
}

int
csta_response_CallCompletion (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	CallCompletionResult *args;

	args = (CallCompletionResult *) Asn1Alloc(sizeof(CallCompletionResult));

	if (privateData)
	{
		/* FIXME add data */
		args->a.extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		args->choiceId = CallCompletionResult::CALLCOMPLETIONRESULT_EXTENSIONS;
	}
	else
	{
		args->choiceId = CallCompletionResult::CALLCOMPLETIONRESULT_NODATA;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_CALLCOMPLETION);
}

int
csta_response_ClearCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	ClearCallResult *args;

	args = (ClearCallResult *) Asn1Alloc(sizeof(ClearCallResult));

	if (privateData)
	{
		/* FIXME add data */
		args->a.extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		args->choiceId = ClearCallResult::CLEARCALLRESULT_EXTENSIONS;
	}
	else
	{
		args->choiceId = ClearCallResult::CLEARCALLRESULT_NODATA;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_CLEARCALL);
}

int
csta_response_ClearConnection (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	ClearConnectionResult *args;

	args = (ClearConnectionResult *) Asn1Alloc(sizeof(ClearConnectionResult));

	if (privateData)
	{
		/* FIXME add data */
		args->a.extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		args->choiceId = ClearConnectionResult::CLEARCONNECTIONRESULT_EXTENSIONS;
	}
	else
	{
		args->choiceId = ClearConnectionResult::CLEARCONNECTIONRESULT_NODATA;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_CLEARCONNECTION);
}

int
csta_response_ConferenceCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
)
{
	ConferenceCallResult *args;

	/*
	 *  Currently the extra connection lists are not supported.
	 *  They are optional in the specification.
	 */

	args = (ConferenceCallResult *) Asn1Alloc(sizeof(ConferenceCallResult));
	csta_set_connectionid(&args->conferenceCall, device, &connid);

	if (privateData)
	{
		/* FIXME add data */
		args->extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_CONFERENCECALL);
}

int
csta_response_ConsultationCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
)
{
	ConsultationCallResult *args;
	ConnectionID *initiatedCall = 0;

	args = (ConsultationCallResult *) Asn1Alloc(sizeof(ConsultationCallResult));
	csta_set_connectionid(&initiatedCall, device, &connid);

	if (privateData)
	{
		args->choiceId = ConsultationCallResult::CONSULTATIONCALLRESULT_CONSULTATIONCALLRESULTSEQ;
		args->a.consultationCallResultSeq = (ConsultationCallResultSeq *) Asn1Alloc(sizeof(ConsultationCallResultSeq));
		args->a.consultationCallResultSeq->initiatedCall = initiatedCall;
		args->a.consultationCallResultSeq->extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		/* FIXME add data */
	}
	else
	{
		args->choiceId = ConsultationCallResult::CONSULTATIONCALLRESULT_INITIATEDCALL;
		args->a.initiatedCall = initiatedCall;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_CONSULTATIONCALL);
}

int
csta_response_DivertCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	DivertCallResult *args;

	args = (DivertCallResult *) Asn1Alloc(sizeof(DivertCallResult));

	if (privateData)
	{
		args->choiceId = DivertCallResult::DIVERTCALLRESULT_EXTENSIONS;
		args->a.extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		/* FIXME add data */
	}
	else
	{
		args->choiceId = DivertCallResult::DIVERTCALLRESULT_NODATA;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_DIVERTCALL);
}

int
csta_response_HoldCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	HoldCallResult *args;

	args = (HoldCallResult *) Asn1Alloc(sizeof(HoldCallResult));

	if (privateData)
	{
		args->choiceId = HoldCallResult::HOLDCALLRESULT_EXTENSIONS;
		args->a.extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
	}
	else
	{
		args->choiceId = HoldCallResult::HOLDCALLRESULT_NODATA;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_HOLDCALL);
}

int
csta_response_MakeCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
)
{
	MakeCallResult *args;
	ConnectionID *initiatedCall = 0;

	args = (MakeCallResult *) Asn1Alloc(sizeof(MakeCallResult));
	csta_set_connectionid(&initiatedCall, device, &connid);

	if (privateData)
	{
		args->choiceId = MakeCallResult::MAKECALLRESULT_MAKECALLRESULTSEQ;
		args->a.makeCallResultSeq = (MakeCallResultSeq *) Asn1Alloc(sizeof(MakeCallResultSeq));
		args->a.makeCallResultSeq->initiatedCall = initiatedCall;
		args->a.makeCallResultSeq->extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		/* FIXME add data */
	}
	else
	{
		args->choiceId = MakeCallResult::MAKECALLRESULT_INITIATEDCALL;
		args->a.initiatedCall = initiatedCall;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_MAKECALL);
}

int
csta_response_MakePredictiveCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
)
{
	MakePredictiveCallResult *args;
	ConnectionID *initiatedCall = 0;

	args = (MakePredictiveCallResult *) Asn1Alloc(sizeof(MakePredictiveCallResult));
	csta_set_connectionid(&initiatedCall, device, &connid);

	if (privateData)
	{
		args->choiceId = MakePredictiveCallResult::MAKEPREDICTIVECALLRESULT_MAKEPREDICTIVECALLRESULTSEQ;
		args->a.makePredictiveCallResultSeq = (MakePredictiveCallResultSeq *) Asn1Alloc(sizeof(MakePredictiveCallResultSeq));
		args->a.makePredictiveCallResultSeq->initiatedCall = initiatedCall;
		args->a.makePredictiveCallResultSeq->extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		/* FIXME add data */
	}
	else
	{
		args->choiceId = MakePredictiveCallResult::MAKEPREDICTIVECALLRESULT_INITIATEDCALL;
		args->a.initiatedCall = initiatedCall;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_MAKEPREDICTIVECALL);
}

int
csta_response_ParkCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	ParkCallResult *args;

	args = (ParkCallResult *) Asn1Alloc(sizeof(ParkCallResult));

	if (privateData)
	{
		args->choiceId = ParkCallResult::PARKCALLRESULT_EXTENSIONS;
		args->a.extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		/* FIXME add data */
	}
	else
	{
		args->choiceId = ParkCallResult::PARKCALLRESULT_NODATA;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_PARKCALL);
}

int
csta_response_QueryDevice (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	QueryDeviceFeature feature,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_response_ReconnectCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	ReconnectCallResult *args;

	args = (ReconnectCallResult *) Asn1Alloc(sizeof(ReconnectCallResult));

	if (privateData)
	{
		args->choiceId = ReconnectCallResult::RECONNECTCALLRESULT_EXTENSIONS;
		args->a.extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		/* FIXME add data */
	}
	else
	{
		args->choiceId = ReconnectCallResult::RECONNECTCALLRESULT_NODATA;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_RECONNECTCALL);
}

int
csta_response_RetrieveCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	RetrieveCallResult *args;

	args = (RetrieveCallResult *) Asn1Alloc(sizeof(RetrieveCallResult));

	if (privateData)
	{
		args->choiceId = RetrieveCallResult::RETRIEVECALLRESULT_EXTENSIONS;
		args->a.extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		/* FIXME add data */
	}
	else
	{
		args->choiceId = RetrieveCallResult::RETRIEVECALLRESULT_NODATA;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_RETRIEVECALL);
}

int
csta_response_SendDTMFTones (
        char *buff,
        int buff_len,
        InvokeIDType invokeID,
        CSTAPrivateData *privateData
)
{
	SendDTMFTonesResult *args;

	args = (SendDTMFTonesResult *) Asn1Alloc(sizeof(SendDTMFTonesResult));

	if (privateData)
	{
		args->choiceId = SendDTMFTonesResult::SENDDTMFTONESRESULT_EXTENSIONS;
		args->a.extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		/* FIXME add data */
	}
	else
	{
		args->choiceId = SendDTMFTonesResult::SENDDTMFTONESRESULT_NODATA;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_SENDDTMFTONES);
}

int
csta_response_SetFeature (
        char *buff,
        int buff_len,
        InvokeIDType invokeID,
        CSTAPrivateData *privateData
)
{
	SetFeatureResult *args;

	args = (SetFeatureResult *) Asn1Alloc(sizeof(SetFeatureResult));

	if (privateData)
	{
		args->choiceId = SetFeatureResult::SETFEATURERESULT_EXTENSIONS;
		args->a.extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		/* FIXME add data */
	}
	else
	{
		args->choiceId = SetFeatureResult::SETFEATURERESULT_NODATA;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_SETFEATURE);
}

int
csta_response_SingleStepConference (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
)
{
	SingleStepConfResult *args;
	ConnectionID *conferencedCall = 0;

	args = (SingleStepConfResult *) Asn1Alloc(sizeof(SingleStepConfResult));
	csta_set_connectionid(&conferencedCall, device, &connid);

	if (privateData)
	{
		args->choiceId = SingleStepConfResult::SINGLESTEPCONFRESULT_SINGLESTEPCONFRESULTSEQ;
		args->a.singleStepConfResultSeq = (SingleStepConfResultSeq *) Asn1Alloc(sizeof(SingleStepConfResultSeq));
		args->a.singleStepConfResultSeq->conferencedCall = conferencedCall;
		args->a.singleStepConfResultSeq->extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		/* FIXME add data */
	}
	else
	{
		args->choiceId = SingleStepConfResult::SINGLESTEPCONFRESULT_CONFERENCEDCALL;
		args->a.conferencedCall = conferencedCall;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_SINGLESTEPCONF);
}

int
csta_response_SingleStepTransfer (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_response_TransferCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
)
{
	return 0;
}

/*
 *  Status Reporting Services
 */

int
csta_response_MonitorStart (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	monitorid_t monitorCrossRefID,
	MonitorFilter *monitorFilter,
	CSTAPrivateData *privateData
)
{
	MonitorStartResult *args;

	args = (MonitorStartResult *) Asn1Alloc(sizeof(MonitorStartResult));
	setoctet(&args->crossRefIdentifier, monitorCrossRefID);
	args->monitorFilter = monitorFilter;

	if (privateData)
	{
		args->extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		/* FIXME add data */
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_MONITORSTART);
}

int
csta_response_ChangeMonitorFilter (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	MonitorFilter *filterList,
	CSTAPrivateData *privateData
)
{
	ChangeMonitorFilterResult *args;

	args = (ChangeMonitorFilterResult *) Asn1Alloc(sizeof(ChangeMonitorFilterResult));

	if (privateData)
	{
		args->choiceId = ChangeMonitorFilterResult::CHANGEMONITORFILTERRESULT_CHANGEMONITORFILTERRESULTSEQ;
		args->a.changeMonitorFilterResultSeq = (ChangeMonitorFilterResultSeq *) Asn1Alloc(sizeof(ChangeMonitorFilterResultSeq));
		args->a.changeMonitorFilterResultSeq->filterList = filterList;
		args->a.changeMonitorFilterResultSeq->extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		/* FIXME add data */
	}
	else
	{
		args->choiceId = ChangeMonitorFilterResult::CHANGEMONITORFILTERRESULT_FILTERLIST;
		args->a.filterList = filterList;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_CHANGEMONITORFILTER);
}

int
csta_response_MonitorStop (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	MonitorStopResult *args;

	args = (MonitorStopResult *) Asn1Alloc(sizeof(MonitorStopResult));

	if (privateData)
	{
		args->choiceId = MonitorStopResult::MONITORSTOPRESULT_EXTENSIONS;
		args->a.extensions = (CSTACommonArguments *) Asn1Alloc(sizeof(CSTACommonArguments));
		/* FIXME add data */
	}
	else
	{
		args->choiceId = MonitorStopResult::MONITORSTOPRESULT_NODATA;
	}

	return encode_rors_apdu(buff, buff_len, invokeID, (void *) args, OV_MONITORSTOP);
}

/* Snapshot Services*/

int
csta_response_SnapshotCallReq (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	ConnectionID *snapshotObj,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_response_SnapshotDeviceReq (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	DeviceID *snapshotObj,
	CSTAPrivateData *privateData
)
{
	return 0;
}

/* Routing Services*/

int
csta_response_RouteRegisterReq (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	DeviceID *routingDevice,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_response_RouteRegisterCancel (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	/*RouteRegisterReqID routeRegisterReqID, FIXME */
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_response_RouteSelect (
	char *buff,
	int buff_len,
	/*RouteRegisterReqID routeRegisterReqID, FIXME */
	RoutingCrossRefID routingCrossRefID,
	DeviceID *routeSelected,
	RetryValue remainRetry,
	SetupValues *setupInformation,
	AsnBool routeUsedReq,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_response_RouteEnd (
	char *buff,
	int buff_len,
	RoutingCrossRefID routingCrossRefID,
	UniversalFailure errorValue,
	CSTAPrivateData *privateData
)
{
	return 0;
}

/* Escape Services*/

int
csta_response_EscapeService (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_response_EscapeServiceConf (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	UniversalFailure error,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_response_SendPrivateEvent (
	char *buff,
	int buff_len,
	CSTAPrivateData *privateData
)
{
	return 0;
}

/* Maintenance Services*/

int
csta_response_SysStatReq (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_response_SysStatStart (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	/*SystemStatusFilter statusFilter, FIXME */
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_response_SysStatStop (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_response_ChangeSysStatFilter (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	/*SystemStatusFilter statusFilter, FIXME */
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_response_SysStatReqConf (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	SystemStatus systemStatus,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_response_SysStatEvent (
	char *buff,
	int buff_len,
	SystemStatus systemStatus,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_response_GetAPICaps (
	char *buff,
	int buff_len,
	InvokeIDType invokeID
)
{
	return 0;
}

int
csta_response_QueryCallMonitor (
	char *buff,
	int buff_len,
	InvokeIDType invokeID
)
{
	return 0;
}

int
encode_rors_apdu(char *buff, int buff_len, InvokeIDType invokeID, void *args, AsnInt serviceID)
{
	ROSEapdus pdu;
	AsnLen len;

	pdu.choiceId = ROSEapdus::ROSEAPDUS_RORS_APDU;
	pdu.a.rors_apdu = (RORSapdu *) Asn1Alloc(sizeof(RORSapdu));
	pdu.a.rors_apdu->invokeID = invokeID;
	pdu.a.rors_apdu->rORSapduSeq = (RORSapduSeq *) Asn1Alloc(sizeof(RORSapduSeq));
	pdu.a.rors_apdu->rORSapduSeq->operation_value = serviceID;
	pdu.a.rors_apdu->rORSapduSeq->result.value = args;

	ExpBufResetInWriteRvsMode(encbuf);

	len = BEncROSEapdus(&encbuf, &pdu);
 	if (ExpBufWriteError(&encbuf))
	{
		fprintf(stderr, "send_rors_apdu: BEncROSEapdus() failure\n");
		ResetNibbleMem();
		return -1;
	}

#ifdef DEBUG_CSTATEST
	printf("\n");
	PrintROSEapdus(stdout, &pdu, 0);
	printf("\n");
#endif

	/*
	 * Free all of the decoded value since it has been encoded into the
	 * buffer. This is much more efficient than freeing each component of
	 * the value individually.

	FIXME this cannot be done if a response and
	an event will be sent back to back using the
	decoded request.  The request will get wiped
	out after this call.

	ResetNibbleMem();
	 */

	len = ExpBufDataSize(encbuf);
	if (buff_len >= len)
	{
		memcpy(buff, ExpBufDataPtr(encbuf), len);
		#ifdef DEBUG_CSTATEST
		//logdump(LOG_DEBUG, buff, len);
		#endif
	}
	else
	{
		perror("encode failed passed in buffer too small");
		len = -1;
	}

	return len;
}

int
csta_failure_response(
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	UniversalFailure::UniversalFailureChoiceId  error_class,
	int error)
{
	ROSEapdus pdu;
	UniversalFailure failure;
	AsnLen len;

	pdu.choiceId = ROSEapdus::ROSEAPDUS_ROER_APDU;
	pdu.a.roer_apdu = (ROERapdu *) Asn1Alloc(sizeof(ROERapdu));
	pdu.a.roer_apdu->invokedID = invokeID;
	pdu.a.roer_apdu->error_value = EV_UNIVERSALFAILURE;
	pdu.a.roer_apdu->parameter.value = &failure;

	failure.choiceId = error_class;
	switch(error_class)
	{
	case UniversalFailure::UNIVERSALFAILURE_OPERATIONALERRORS:
		failure.a.operationalErrors = (Operations) error;
		break;
	case UniversalFailure::UNIVERSALFAILURE_STATEERRORS:
		failure.a.stateErrors = (StateIncompatibility) error;
		break;
	case UniversalFailure::UNIVERSALFAILURE_SYSTEMRESOURCEERRORS:
		failure.a.systemResourceErrors = (SystemResourceAvailability) error;
		break;
	case UniversalFailure::UNIVERSALFAILURE_SUBSCRIBEDRESOURCEAVAILABILITYERRORS:
		failure.a.subscribedResourceAvailabilityErrors = (SubscribedResourceAvailability) error;
		break;
	case UniversalFailure::UNIVERSALFAILURE_PERFORMANCEERRORS:
		failure.a.performanceErrors = (PerformanceManagement) error;
		break;
	case UniversalFailure::UNIVERSALFAILURE_SECURITYERRORS:
		failure.a.securityErrors = (SecurityError) error;
		break;
	/*
	 * FIXME can these be added?

	case UniversalFailure::UNIVERSALFAILURE_NONSTANDARDERRORS:
		failure.a.nonStandardErrors = error;
		break;
	 */
	}

	ExpBufResetInWriteRvsMode(encbuf);

	len = BEncROSEapdus(&encbuf, &pdu);
 	if (ExpBufWriteError(&encbuf))
	{
		fprintf(stderr, "send_rors_apdu: BEncROSEapdus() failure\n");
		ResetNibbleMem();
		return -1;
	}

#ifdef DEBUG_CSTATEST
	printf("\n");
	PrintROSEapdus(stdout, &pdu, 0);
	printf("\n");
#endif

	/*
	 * Free all of the decoded value since it has been encoded into the
	 * buffer. This is much more efficient than freeing each component of
	 * the value individually.

	FIXME this cannot be done if a response and
	an event will be sent back to back using the
	decoded request.  The request will get wiped
	out after this call.

	ResetNibbleMem();
	 */

	len = ExpBufDataSize(encbuf);
	if (buff_len >= len)
	{
		memcpy(buff, ExpBufDataPtr(encbuf), len);
		#ifdef DEBUG_CSTATEST
		//logdump(LOG_DEBUG, buff, len);
		#endif
	}
	else
	{
		perror("encode failed passed in buffer too small");
		len = -1;
	}

	return len;
}

#ifdef __cplusplus
}
#endif
