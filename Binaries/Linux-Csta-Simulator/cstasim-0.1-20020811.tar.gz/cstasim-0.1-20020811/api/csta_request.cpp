/*
 *
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */

#ifdef WIN32
#ifdef CSTADLL
#define CSTADLLIMPORTEXPORT __declspec(dllexport)
#else
#define CSTADLLIMPORTEXPORT __declspec(dllimport)
#endif /* CSTADLL */
#else
#define CSTADLLIMPORTEXPORT
#endif /* WIN32 */

extern "C"
{
#include "asn-incl.h"
#include "csta_defs.h"
}
#include "csta_config.h"
#include "csta_api.h"
#include "csta_request_api.h"



#ifdef __cplusplus
extern "C"
{
#endif

extern AsnLen BEncROSEapdus (BUF_TYPE, ROSEapdus *);

static ExpBuf *encbuf = 0;
int encode_roiv_apdu(char *, int, InvokeIDType, void *, AsnInt);

int
init_csta_request(void)
{
	int status = 0;

	encbuf = ExpBufAllocBufAndData();

	if (encbuf == 0)
	{
		status = -1;
	}

	return status;
}

#ifdef NOT_USED

/* ACSE association management */
void ACSEassociation()
{
	ACSEUserInformationForCSTA *infos;
	static ExpBuf *encbuf;
	AsnLen len;
	ACSE_apdu pdu;
	char dummy[4] = {0x00, 0x00, 0x00, 0x00};

	/* ACSE APDU */
	pdu.choiceId = ACSE_APDU_AARQ;
	pdu.a.aarq = Asn1Alloc(sizeof(AARQ_apdu));
	/* protocol_version */
	pdu.a.aarq->protocol_version.bitLen = 2;
	pdu.a.aarq->protocol_version.bits = dummy;
	SetAsnBit(&pdu.a.aarq->protocol_version, VERSION11);
	dummy[0] = 0x00; /* clean-up dummy */
	/* application_context_name */
	pdu.a.aarq->application_context_name = csta_version2;
	/* user_information (to carry CSTA protocole information) */
	pdu.a.aarq->user_information = AsnListNew(sizeof(ACSEUserInformationForCSTA));
	infos = AsnListAppend(pdu.a.aarq->user_information);
	/* CSTA version */
	SetAsnBit(&infos->cSTAVersion, VERSIONTWO);
	/* CSTA functionalities */
	infos->cSTAFunctionsRequiredByApplication = Asn1Alloc(sizeof(CSTAFunctionality));
	infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices.bitLen = 32;
	infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices.bits = dummy;
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, ALTERNATECALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, ANSWERCALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, ASSOCIATEDATA);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, CALLCOMPLETION);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, CLEARCALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, CLEARCONNECTION);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, CONFERENCECALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, CONSULTATIONCALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, DIVERTCALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, HOLDCALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, MAKECALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, MAKEPREDICTIVECALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, PARKCALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, QUERYDEVICE);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, RECONNECTCALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, RETRIEVECALL);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, SENDDTMFTONES);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, SETFEATURE);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, SINGLESTEPCONFERENCE);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, SINGLESTEPTRANSFER);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, TRANSFERCALL);
#ifdef DEBUG_CSTATEST
	PrintAsnBits(stdout, &infos->cSTAFunctionsRequiredByApplication->switchingFunctionServices, 0);
#endif
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->eventReportServices, DELIVERED);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->computingFunctionServices, ROUTEREQUEST);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->bidirectionalServices, SYSTEMSTATUS);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->statusReportingServices, MONITORSTART);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->inputOutputServices, SENDDATASERVICE);
	SetAsnBit(&infos->cSTAFunctionsRequiredByApplication->voiceUnitServices, SUSPEND);
	/* CSTA functionalities */
	infos->cSTAFunctionsThatCanBeSupplied = Asn1Alloc(sizeof(CSTAFunctionality));
	SetAsnBit(&infos->cSTAFunctionsThatCanBeSupplied->switchingFunctionServices, MAKECALL);
	SetAsnBit(&infos->cSTAFunctionsThatCanBeSupplied->eventReportServices, DELIVERED);
	SetAsnBit(&infos->cSTAFunctionsThatCanBeSupplied->computingFunctionServices, ROUTEREQUEST);
	SetAsnBit(&infos->cSTAFunctionsThatCanBeSupplied->bidirectionalServices, SYSTEMSTATUS);
	SetAsnBit(&infos->cSTAFunctionsThatCanBeSupplied->statusReportingServices, MONITORSTART);
	SetAsnBit(&infos->cSTAFunctionsThatCanBeSupplied->inputOutputServices, SENDDATASERVICE);
	SetAsnBit(&infos->cSTAFunctionsThatCanBeSupplied->voiceUnitServices, SUSPEND);

#ifdef DEBUG_CSTATEST
	PrintAsnOid(stdout, &csta_version1, 0);
#endif
	
	/* Encode buffer */
	len = BEncACSE_apdu(encbuf, &pdu);
	if (ExpBufWriteError(&encbuf)) {
		fprintf(stderr, "\n");
		exit(-1);
	}

#ifdef DEBUG_CSTATEST
	/* SNACC pretty-print */
	printf("\n");
	PrintACSE_apdu(stdout, &pdu, 0);
	printf("\n");
#endif
	/*
	 * Free all of the decoded value since it has been encoded into the
	 * buffer. This is much more efficient than freeing each component of
	 * the value individually.
	 */
	ResetNibbleMem();


	/* Send the encoded PDU */
	if(tsp_write_socket(fdcsta, ExpBufDataPtr(encbuf), ExpBufDataSize(encbuf)) < 0) {
		perror("cstatest.c: ACSEassociation(): tcp_write_socket()");
		exit(-1);
	}

#ifdef DEBUG_CSTATEST
	printf("Data sent... requestID = %x\n", REQUEST_ID);
	logdump(LOG_DEBUG, ExpBufDataPtr(encbuf), ExpBufDataSize(encbuf));
#endif

}
#endif


/*
 *  The CSTAPrivateData parameter present in all requests is simply a place
 *  holder for now.  The intent is to have a this parameter be a linked list
 *  of key, value pairs to pass special or extra parameters to functions.
 */

int
csta_request_AlternateCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t activecall,
	connid_t heldcall,
	CSTAPrivateData *privateData
)
{
	AlternateCallArgument *args;
	ConnectionDetails *callsInvolved;
	ConnectionID *activeCall = NULL;
	ConnectionID *heldCall = NULL;
	ConnectionIDChoice *cid_device = 0;
	ConnectionDetailsSeq* bothCalls;

	args = (AlternateCallArgument *) Asn1Alloc(sizeof(AlternateCallArgument));
	callsInvolved = (ConnectionDetails *) Asn1Alloc(sizeof(ConnectionDetails));

	if (activecall)
	{
		activeCall = (ConnectionID *) Asn1Alloc(sizeof(ConnectionID));
		if (heldcall)
		{
			heldCall = (ConnectionID *) Asn1Alloc(sizeof(ConnectionID));
			callsInvolved->choiceId = ConnectionDetails::CONNECTIONDETAILS_BOTHCALLS;
			bothCalls = (ConnectionDetailsSeq *) Asn1Alloc(sizeof(ConnectionDetailsSeq));
			bothCalls->activeCall = activeCall;
			bothCalls->heldCall = heldCall;
			callsInvolved->a.bothCalls = bothCalls;
		}
		else
		{
			callsInvolved->choiceId = ConnectionDetails::CONNECTIONDETAILS_ACTIVECALL;
			callsInvolved->a.activeCall = activeCall;
		}
	}
	else if (heldcall)
	{
		heldCall = (ConnectionID *) Asn1Alloc(sizeof(ConnectionID));
		callsInvolved->choiceId = ConnectionDetails::CONNECTIONDETAILS_HELDCALL;
		callsInvolved->a.heldCall = heldCall;
	}

	csta_set_ConnectionIDChoice(&cid_device, device);

	if (activeCall)
	{
		setoctet(&activeCall->call, activecall);
		activeCall->device = cid_device;
	}
	if (heldCall)
	{
		setoctet(&heldCall->call, heldcall);
		heldCall->device = cid_device;
	}


	if (privateData)
	{
		args->choiceId = AlternateCallArgument::ALTERNATECALLARGUMENT_ALTERNATECALLARGUMENTSEQ;
		args->a.alternateCallArgumentSeq->callsInvolved = callsInvolved;
	
		/* FIXME add extensions */
	}
	else
	{
		args->choiceId = AlternateCallArgument::ALTERNATECALLARGUMENT_CALLSINVOLVED;
		args->a.callsInvolved = callsInvolved;
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_ALTERNATECALL);
}

int
csta_request_AnswerCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
)
{
	AnswerCallArgument *args;
	ConnectionID *callToBeAnswered = 0;

	args = (AnswerCallArgument *) Asn1Alloc(sizeof(AnswerCallArgument));

	csta_set_connectionid(&callToBeAnswered, device, &connid);

	if (privateData)
	{
		args->choiceId = AnswerCallArgument::ANSWERCALLARGUMENT_ANSWERCALLARGUMENTSEQ;
		args->a.answerCallArgumentSeq->callToBeAnswered = callToBeAnswered;
	
		/* FIXME add extensions */
	}
	else
	{
		args->choiceId = AnswerCallArgument::ANSWERCALLARGUMENT_CALLTOBEANSWERED;
		args->a.callToBeAnswered = callToBeAnswered;
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_ANSWERCALL);
}

int
csta_request_AssociateData (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	char *accountCode,
	char *authCode,
	char *correlatorData,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_request_CallCompletion (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	int feature,
	ConnectionID *call,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_request_ClearCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	connid_t connid,
	CSTAPrivateData *privateData
)
{
	ClearCallArgument *args;
	ConnectionID *callToBeCleared = 0;

	args = (ClearCallArgument *) Asn1Alloc(sizeof(ClearCallArgument));
	csta_set_connectionid(&callToBeCleared, 0, &connid);

	if (privateData)
	{
		args->choiceId = ClearCallArgument::CLEARCALLARGUMENT_CLEARCALLARGUMENTSEQ;
		args->a.clearCallArgumentSeq->callToBeCleared = callToBeCleared;
	
		/* FIXME add extensions */
	}
	else
	{
		args->choiceId = ClearCallArgument::CLEARCALLARGUMENT_CALLTOBECLEARED;
		args->a.callToBeCleared = callToBeCleared;
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_CLEARCALL);
}

int
csta_request_ClearConnection (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	CSTAPrivateData *privateData
)
{
	ClearConnectionArgument *args;
	ConnectionID *connectionToBeCleared = 0;

	args = (ClearConnectionArgument *) Asn1Alloc(sizeof(ClearConnectionArgument));
	csta_set_connectionid(&connectionToBeCleared, device, &connid);

	if (privateData)
	{
		args->choiceId = ClearConnectionArgument::CLEARCONNECTIONARGUMENT_CLEARCONNECTIONARGUMENTSEQ;
		args->a.clearConnectionArgumentSeq->connectionToBeCleared = connectionToBeCleared;
	
		/* FIXME add extensions */
	}
	else
	{
		args->choiceId = ClearConnectionArgument::CLEARCONNECTIONARGUMENT_CONNECTIONTOBECLEARED;
		args->a.connectionToBeCleared = connectionToBeCleared;
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_CLEARCONNECTION);
}

int
csta_request_ConferenceCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t activecall,
	connid_t heldcall,
	CSTAPrivateData *privateData
)
{
	ConferenceCallArgument *args;
	ConnectionDetails *callsInvolved;
	ConnectionID *activeCall = NULL;
	ConnectionID *heldCall = NULL;
	ConnectionIDChoice *cid_device = 0;
	ConnectionDetailsSeq* bothCalls;

	args = (ConferenceCallArgument *) Asn1Alloc(sizeof(ConferenceCallArgument));
	callsInvolved = (ConnectionDetails *) Asn1Alloc(sizeof(ConnectionDetails));

	if (activecall)
	{
		activeCall = (ConnectionID *) Asn1Alloc(sizeof(ConnectionID));
		if (heldcall)
		{
			heldCall = (ConnectionID *) Asn1Alloc(sizeof(ConnectionID));
			callsInvolved->choiceId = ConnectionDetails::CONNECTIONDETAILS_BOTHCALLS;
			bothCalls = (ConnectionDetailsSeq *) Asn1Alloc(sizeof(ConnectionDetailsSeq));
			bothCalls->activeCall = activeCall;
			bothCalls->heldCall = heldCall;
			callsInvolved->a.bothCalls = bothCalls;
		}
		else
		{
			callsInvolved->choiceId = ConnectionDetails::CONNECTIONDETAILS_ACTIVECALL;
			callsInvolved->a.activeCall = activeCall;
		}
	}
	else if (heldcall)
	{
		heldCall = (ConnectionID *) Asn1Alloc(sizeof(ConnectionID));
		callsInvolved->choiceId = ConnectionDetails::CONNECTIONDETAILS_HELDCALL;
		callsInvolved->a.heldCall = heldCall;
	}

	csta_set_ConnectionIDChoice(&cid_device, device);

	if (activeCall)
	{
		setoctet(&activeCall->call, activecall);
		activeCall->device = cid_device;
	}
	if (heldCall)
	{
		setoctet(&heldCall->call, heldcall);
		heldCall->device = cid_device;
	}

	if (privateData)
	{
		args->choiceId = ConferenceCallArgument::CONFERENCECALLARGUMENT_CONFERENCECALLARGUMENTSEQ;
		args->a.conferenceCallArgumentSeq->callsInvolved = callsInvolved;
	
		/* FIXME add extensions */
	}
	else
	{
		args->choiceId = ConferenceCallArgument::CONFERENCECALLARGUMENT_CALLSINVOLVED;
		args->a.callsInvolved = callsInvolved;
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_CONFERENCECALL);
}

int
csta_request_ConsultationCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t calling_device,
	connid_t existingcall,
	device_t called_device,
	CSTAPrivateData *privateData
)
{
	ConsultationCallArgument *args;

	args = (ConsultationCallArgument *) Asn1Alloc(sizeof(ConsultationCallArgument));

	csta_set_connectionid(&args->existingCall, calling_device, &existingcall);

        args->consultedDevice = (CalledDeviceID *) Asn1Alloc(sizeof(CalledDeviceID));
        args->consultedDevice->choiceId = CalledDeviceID::CALLEDDEVICEID_DEVICEIDENTIFIER;
        args->consultedDevice->a.deviceIdentifier = (ExtendedDeviceID *) Asn1Alloc(sizeof(ExtendedDeviceID));
        args->consultedDevice->a.deviceIdentifier->choiceId = ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER;
        args->consultedDevice->a.deviceIdentifier->a.deviceIdentifier = (DeviceID *) Asn1Alloc(sizeof(DeviceID));
	csta_set_deviceid(&args->consultedDevice->a.deviceIdentifier->a.deviceIdentifier, called_device);

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_CONSULTATIONCALL);
}

int
csta_request_DivertCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	int diversion_type,
	device_t source,
	connid_t connid,
	device_t destination,
	CSTAPrivateData *privateData
)
{
	DivertCallArgument *args;

	args = (DivertCallArgument *) Asn1Alloc(sizeof(DivertCallArgument));
	args->divertInfo = (DivertInfo *) Asn1Alloc(sizeof(DivertInfo));

	switch ((DivertInfo::DivertInfoChoiceId) diversion_type)
	{
	case DivertInfo::DIVERTINFO_DEFLECT:

		args->divertInfo->choiceId = (DivertInfo::DivertInfoChoiceId) diversion_type;
		args->divertInfo->a.deflect = (DivertInfoSeq *) Asn1Alloc(sizeof(DivertInfoSeq));
		args->divertInfo->a.deflect->callToBeDiverted = (ConnectionID *) Asn1Alloc(sizeof(ConnectionID));
		csta_set_connectionid(&args->divertInfo->a.deflect->callToBeDiverted, source, &connid);
		
		args->divertInfo->a.deflect->newDestination = (CalledDeviceID *) Asn1Alloc(sizeof(CalledDeviceID));
		args->divertInfo->a.deflect->newDestination->choiceId = CalledDeviceID::CALLEDDEVICEID_DEVICEIDENTIFIER;
		args->divertInfo->a.deflect->newDestination->a.deviceIdentifier =
									(ExtendedDeviceID *) Asn1Alloc(sizeof(ExtendedDeviceID));
		args->divertInfo->a.deflect->newDestination->a.deviceIdentifier->choiceId =
										ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER;
		csta_set_deviceid(&args->divertInfo->a.deflect->newDestination->a.deviceIdentifier->a.deviceIdentifier,destination);
		break;

	case DivertInfo::DIVERTINFO_PICKUP:

		args->divertInfo->choiceId = (DivertInfo::DivertInfoChoiceId) diversion_type;
		args->divertInfo->a.pickup = (DivertInfoSeq1 *) Asn1Alloc(sizeof(DivertInfoSeq1));
		csta_set_connectionid(&args->divertInfo->a.pickup->callToBePickedUp, source, &connid);
		csta_set_deviceid(&args->divertInfo->a.pickup->requestingDevice, destination);
		break;

	case DivertInfo::DIVERTINFO_GROUPREQUESTINGDEVICE:

		args->divertInfo->choiceId = (DivertInfo::DivertInfoChoiceId) diversion_type;
		csta_set_deviceid(&args->divertInfo->a.groupRequestingDevice, destination);
		break;
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_DIVERTCALL);
}

int
csta_request_HoldCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
	AsnBool reservation,
	CSTAPrivateData *privateData
)
{
	HoldCallArgument *args;

	args = (HoldCallArgument *) Asn1Alloc(sizeof(HoldCallArgument));
	csta_set_connectionid(&args->callToBeHeld, device, &connid);
	args->connectionReservation = &reservation;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_HOLDCALL);
}

int
csta_request_MakeCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t source,
	device_t destination,
	CSTAPrivateData *privateData
)
{
	MakeCallArgument *args;

	args = (MakeCallArgument *) Asn1Alloc(sizeof(MakeCallArgument));
	csta_set_deviceid(&args->callingDevice, source);

	args->calledDirectoryNumber = (CalledDeviceID *) Asn1Alloc(sizeof(CalledDeviceID));
	args->calledDirectoryNumber->choiceId = CalledDeviceID::CALLEDDEVICEID_DEVICEIDENTIFIER;
	args->calledDirectoryNumber->a.deviceIdentifier = (ExtendedDeviceID *) Asn1Alloc(sizeof(ExtendedDeviceID));
	args->calledDirectoryNumber->a.deviceIdentifier->choiceId = ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER;
	csta_set_deviceid(&args->calledDirectoryNumber->a.deviceIdentifier->a.deviceIdentifier, destination);

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_MAKECALL);
}

int
csta_request_MakePredictiveCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t source,
	device_t destination,
	AllocationState allocationState,
	CSTAPrivateData *privateData
)
{
	MakePredictiveCallArgument *args;

	args = (MakePredictiveCallArgument *) Asn1Alloc(sizeof(MakePredictiveCallArgument));
	args->allocation = &allocationState;
	csta_set_deviceid(&args->callingDevice, source);
	
	args->calledDirectoryNumber = (CalledDeviceID *) Asn1Alloc(sizeof(CalledDeviceID));
	args->calledDirectoryNumber->choiceId = CalledDeviceID::CALLEDDEVICEID_DEVICEIDENTIFIER;
	args->calledDirectoryNumber->a.deviceIdentifier = (ExtendedDeviceID *) Asn1Alloc(sizeof(ExtendedDeviceID));
	args->calledDirectoryNumber->a.deviceIdentifier->choiceId = ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER;
	csta_set_deviceid(&args->calledDirectoryNumber->a.deviceIdentifier->a.deviceIdentifier, destination);

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_MAKEPREDICTIVECALL);
}

int
csta_request_ParkCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t callToPark,
	device_t parkTo,
	CSTAPrivateData *privateData
)
{
	ParkCallArgument *args;

	args = (ParkCallArgument *) Asn1Alloc(sizeof(ParkCallArgument));
	csta_set_connectionid(&args->callToPark, device, &callToPark);

        args->parkTo = (SubjectDeviceID *) Asn1Alloc(sizeof(SubjectDeviceID));
        args->parkTo->choiceId = SubjectDeviceID::SUBJECTDEVICEID_DEVICEIDENTIFIER;
        args->parkTo->a.deviceIdentifier = (ExtendedDeviceID *) Asn1Alloc(sizeof(ExtendedDeviceID));
        args->parkTo->a.deviceIdentifier->choiceId = ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER;
	csta_set_deviceid(&args->parkTo->a.deviceIdentifier->a.deviceIdentifier, parkTo);

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_PARKCALL);
}

int
csta_request_QueryDevice (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	QueryDeviceFeature feature,
	CSTAPrivateData *privateData
)
{
	QueryDeviceArgument *args;

	args = (QueryDeviceArgument *) Asn1Alloc(sizeof(QueryDeviceArgument));
	csta_set_deviceid(&args->device, device);
	args->feature = feature;	

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_QUERYDEVICE);
}

/* Monitor Services*/

int
csta_request_ReconnectCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t conn_to_clear,
	connid_t conn_to_retrieve,
	CSTAPrivateData *privateData
)
{
	ReconnectCallArgument *args;
	ConnectionDetails *reconnectInfo;
	ConnectionID *activeCall = 0;
	ConnectionID *heldCall = 0;
	ConnectionIDChoice *cid_device = 0;
	ConnectionDetailsSeq* bothCalls;
	ReconnectCallArgumentSeq* reconnectCallArgumentSeq;

	args = (ReconnectCallArgument *) Asn1Alloc(sizeof(ReconnectCallArgument));
	reconnectInfo = (ConnectionDetails *) Asn1Alloc(sizeof(ConnectionDetails));

	if (conn_to_clear)
	{
		activeCall = (ConnectionID *) Asn1Alloc(sizeof(ConnectionID));
		if (conn_to_retrieve)
		{
			heldCall = (ConnectionID *) Asn1Alloc(sizeof(ConnectionID));
			reconnectInfo->choiceId = ConnectionDetails::CONNECTIONDETAILS_BOTHCALLS;
			bothCalls = (ConnectionDetailsSeq *) Asn1Alloc(sizeof(ConnectionDetailsSeq));
			bothCalls->activeCall = activeCall;
			bothCalls->heldCall = heldCall;
			reconnectInfo->a.bothCalls = bothCalls;
		}
		else
		{
			reconnectInfo->choiceId = ConnectionDetails::CONNECTIONDETAILS_ACTIVECALL;
			reconnectInfo->a.activeCall = activeCall;
		}
	}
	else if (conn_to_retrieve)
	{
		heldCall = (ConnectionID *) Asn1Alloc(sizeof(ConnectionID));
		reconnectInfo->choiceId = ConnectionDetails::CONNECTIONDETAILS_HELDCALL;
		reconnectInfo->a.heldCall = heldCall;
	}

	csta_set_ConnectionIDChoice(&cid_device, device);

	if (activeCall)
	{
		setoctet(&activeCall->call, conn_to_clear);
		activeCall->device = cid_device;
	}
	if (heldCall)
	{
		setoctet(&heldCall->call, conn_to_retrieve);
		heldCall->device = cid_device;
	}


	if (privateData)
	{
		args->choiceId = ReconnectCallArgument::RECONNECTCALLARGUMENT_RECONNECTCALLARGUMENTSEQ;
		args->a.reconnectCallArgumentSeq->reconnectInfo = reconnectInfo;
	
		/* FIXME add extensions */
	}
	else
	{
		args->choiceId = ReconnectCallArgument::RECONNECTCALLARGUMENT_RECONNECTINFO;
		args->a.reconnectInfo = reconnectInfo;
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_RECONNECTCALL);
}

int
csta_request_RetrieveCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t heldCall,
	CSTAPrivateData *privateData
)
{
	RetrieveCallArgument *args;
	ConnectionID *callToBeRetrieved = 0;

	args = (RetrieveCallArgument *) Asn1Alloc(sizeof(RetrieveCallArgument));
	csta_set_connectionid(&callToBeRetrieved, device, &heldCall);

	if (privateData)
	{
		args->choiceId = RetrieveCallArgument::RETRIEVECALLARGUMENT_RETRIEVECALLARGUMENTSEQ;
		args->a.retrieveCallArgumentSeq = (RetrieveCallArgumentSeq *) Asn1Alloc(sizeof(RetrieveCallArgumentSeq));
		args->a.retrieveCallArgumentSeq->callToBeRetrieved = callToBeRetrieved;

		/* FIXME add extensions */
	}
	else
	{
		args->choiceId = RetrieveCallArgument::RETRIEVECALLARGUMENT_CALLTOBERETRIEVED;
		args->a.callToBeRetrieved = callToBeRetrieved;
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_RETRIEVECALL);
}

int
csta_request_SendDTMFTones (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t connid,
        char *charactersToSend,
        int toneDuration,
        int pauseDuration,
	CSTAPrivateData *privateData
)
{
	SendDTMFTonesArgument *args;

	args = (SendDTMFTonesArgument *) Asn1Alloc(sizeof(SendDTMFTonesArgument));
	csta_set_connectionid(&args->connectionToSendTones, device, &connid);
	setoctet(&args->charactersToSend, charactersToSend);
	args->toneDuration = &toneDuration;
	args->pauseDuration = &pauseDuration;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_SENDDTMFTONES);
}

int
csta_request_SetMessageWaiting (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	int state,
	CSTAPrivateData *privateData
)
{
	SetFeatureArgument *args;

	args = (SetFeatureArgument *) Asn1Alloc(sizeof(SetFeatureArgument));
	args->feature = (SetDeviceFeature *) Asn1Alloc(sizeof(SetDeviceFeature));

	csta_set_deviceid(&args->device, device);

	args->feature->choiceId = SetDeviceFeature::SETDEVICEFEATURE_MSGWAITINGON;
	args->feature->a.msgWaitingOn = state;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_SETFEATURE);
}

int
csta_request_SetDoNotDisturb (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	int state,
	CSTAPrivateData *privateData
)
{
	SetFeatureArgument *args;

	args = (SetFeatureArgument *) Asn1Alloc(sizeof(SetFeatureArgument));
	args->feature = (SetDeviceFeature *) Asn1Alloc(sizeof(SetDeviceFeature));

	csta_set_deviceid(&args->device, device);

	args->feature->choiceId = SetDeviceFeature::SETDEVICEFEATURE_DONOTDISTURBON;
	args->feature->a.doNotDisturbOn = state;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_SETFEATURE);
}

int
csta_request_SetForwarding (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	ForwardingType forwardingType,
	int state,
	device_t forwardDN,
	CSTAPrivateData *privateData
)
{
	SetFeatureArgument *args;

	args = (SetFeatureArgument *) Asn1Alloc(sizeof(SetFeatureArgument));
	args->feature = (SetDeviceFeature *) Asn1Alloc(sizeof(SetDeviceFeature));

	csta_set_deviceid(&args->device, device);

	args->feature->choiceId = SetDeviceFeature::SETDEVICEFEATURE_FORWARD;
	args->feature->a.forward = (ForwardParameter *) Asn1Alloc(sizeof(ForwardParameter));
	args->feature->a.forward->forwardingType = forwardingType;

	if (state)
	{
		setoctet(&args->feature->a.forward->forwardDN, forwardDN);
	}

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_SETFEATURE);
}

int
csta_request_SetAgentState (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	AgentParameter::AgentParameterChoiceId agentMode,
	agentid_t agentid,
	device_t  group,
	agent_password_t password,
	CSTAPrivateData *privateData
)
{
	SetFeatureArgument *args;

	args = (SetFeatureArgument *) Asn1Alloc(sizeof(SetFeatureArgument));
	args->feature = (SetDeviceFeature *) Asn1Alloc(sizeof(SetDeviceFeature));

	csta_set_deviceid(&args->device, device);

	args->feature->choiceId = SetDeviceFeature::SETDEVICEFEATURE_REQUESTEDAGENTSTATE;

	args->feature->a.requestedAgentState = (AgentParameter *) Asn1Alloc(sizeof(AgentParameter));

	switch (agentMode)
	{
	case AgentParameter::AGENTPARAMETER_AGENTLOGGEDIN:
		args->feature->a.requestedAgentState->a.agentLoggedIn = (LoggedOnInfo *) Asn1Alloc(sizeof(LoggedOnInfo));
		if (agentid)
		{
			setoctet(&args->feature->a.requestedAgentState->a.agentLoggedIn->agentID, agentid);
		}
		if (password)
		{
			setoctet(&args->feature->a.requestedAgentState->a.agentLoggedIn->password, password);
		}
		if (group)
		{
			csta_set_deviceid(&args->feature->a.requestedAgentState->a.agentLoggedIn->group, group);
		}
		break;

	case AgentParameter::AGENTPARAMETER_AGENTLOGGEDOUT:
		args->feature->a.requestedAgentState->a.agentLoggedOut = (LoggedOffInfo *) Asn1Alloc(sizeof(LoggedOffInfo));
		if (agentid)
		{
			setoctet(&args->feature->a.requestedAgentState->a.agentLoggedOut->agentID, agentid);
		}
		if (password)
		{
			setoctet(&args->feature->a.requestedAgentState->a.agentLoggedOut->password, password);
		}
		if (group)
		{
			csta_set_deviceid(&args->feature->a.requestedAgentState->a.agentLoggedOut->group, group);
		}
		break;

		break;

	case AgentParameter::AGENTPARAMETER_AGENTNOTREADY:
	case AgentParameter::AGENTPARAMETER_AGENTREADY:
	case AgentParameter::AGENTPARAMETER_AGENTBUSY:
	case AgentParameter::AGENTPARAMETER_AGENTWORKINGAFTERCALL:
		break;

	}

	args->feature->a.requestedAgentState->choiceId = (AgentParameter::AgentParameterChoiceId) agentMode;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_SETFEATURE);
}

int
csta_request_EnableRouting (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	int state,
	CSTAPrivateData *privateData
)
{
	SetFeatureArgument *args;

	args = (SetFeatureArgument *) Asn1Alloc(sizeof(SetFeatureArgument));
	args->feature = (SetDeviceFeature *) Asn1Alloc(sizeof(SetDeviceFeature));

	csta_set_deviceid(&args->device, device);

	args->feature->choiceId = SetDeviceFeature::SETDEVICEFEATURE_ENABLEROUTING;
	args->feature->a.enableRouting = state;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_SETFEATURE);
}

int
csta_request_AutoAnswer (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	int state,
	CSTAPrivateData *privateData
)
{
	SetFeatureArgument *args;

	args = (SetFeatureArgument *) Asn1Alloc(sizeof(SetFeatureArgument));
	args->feature = (SetDeviceFeature *) Asn1Alloc(sizeof(SetDeviceFeature));

	csta_set_deviceid(&args->device, device);

	args->feature->choiceId = SetDeviceFeature::SETDEVICEFEATURE_AUTOANSWERON;
	args->feature->a.autoAnswerOn = state;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_SETFEATURE);
}

int
csta_request_MicrophoneMute (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	int state,
	CSTAPrivateData *privateData
)
{
	SetFeatureArgument *args;

	args = (SetFeatureArgument *) Asn1Alloc(sizeof(SetFeatureArgument));
	args->feature = (SetDeviceFeature *) Asn1Alloc(sizeof(SetDeviceFeature));

	csta_set_deviceid(&args->device, device);

	args->feature->choiceId = SetDeviceFeature::SETDEVICEFEATURE_MICROPHONEMUTEON;
	args->feature->a.microphoneMuteOn = state;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_SETFEATURE);
}

int
csta_request_SpeakerMute (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	int state,
	CSTAPrivateData *privateData
)
{
	SetFeatureArgument *args;

	args = (SetFeatureArgument *) Asn1Alloc(sizeof(SetFeatureArgument));
	args->feature = (SetDeviceFeature *) Asn1Alloc(sizeof(SetDeviceFeature));

	csta_set_deviceid(&args->device, device);

	args->feature->choiceId = SetDeviceFeature::SETDEVICEFEATURE_SPEAKERMUTEON;
	args->feature->a.speakerMuteOn = state;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_SETFEATURE);
}

int
csta_request_SpeakerVolume (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	int level,
	CSTAPrivateData *privateData
)
{
	SetFeatureArgument *args;

	args = (SetFeatureArgument *) Asn1Alloc(sizeof(SetFeatureArgument));
	args->feature = (SetDeviceFeature *) Asn1Alloc(sizeof(SetDeviceFeature));

	csta_set_deviceid(&args->device, device);

	args->feature->choiceId = SetDeviceFeature::SETDEVICEFEATURE_SPEAKERVOLUME;
	args->feature->a.speakerVolume = level;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_SETFEATURE);
}

int
csta_request_SingleStepConference (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t calling_device,
	connid_t existingcall,
	device_t deviceToJoin,
	ParticipationType participation,
	CSTAPrivateData *privateData
)
{
	SingleStepConfArgument *args;

	args = (SingleStepConfArgument *) Asn1Alloc(sizeof(SingleStepConfArgument));
	csta_set_connectionid(&args->activeCall, calling_device, &existingcall);
	csta_set_deviceid(&args->deviceToJoin, deviceToJoin);

	args->participationType = &participation;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_SINGLESTEPCONF);
}

int
csta_request_SingleStepTransfer (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t calling_device,
	connid_t existingcall,
	device_t destination,
	CSTAPrivateData *privateData
)
{
	SingleStepTransArgument *args;

	args = (SingleStepTransArgument *) Asn1Alloc(sizeof(SingleStepTransArgument));
	csta_set_connectionid(&args->activeCall, calling_device, &existingcall);
	csta_set_deviceid(&args->deviceToTransferTo, destination);

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_SINGLESTEPTRANS);
}
int
csta_request_TransferCall (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	connid_t activecall,
	connid_t heldcall,
	CSTAPrivateData *privateData
)
{
	TransferCallArgument *args;
	ConnectionDetails *transferInfo;
	ConnectionID *activeCall = 0;
	ConnectionID *heldCall = 0;
	ConnectionIDChoice *cid_device = 0;
	ConnectionDetailsSeq *bothCalls;

	args = (TransferCallArgument *) Asn1Alloc(sizeof(TransferCallArgument));
	transferInfo = (ConnectionDetails *) Asn1Alloc(sizeof(ConnectionDetails));

	if (activecall)
	{
		activeCall = (ConnectionID *) Asn1Alloc(sizeof(ConnectionID));
		if (heldcall)
		{
			heldCall = (ConnectionID *) Asn1Alloc(sizeof(ConnectionID));
			transferInfo->choiceId = ConnectionDetails::CONNECTIONDETAILS_BOTHCALLS;
			bothCalls = (ConnectionDetailsSeq *) Asn1Alloc(sizeof(ConnectionDetailsSeq));
			bothCalls->activeCall = activeCall;
			bothCalls->heldCall = heldCall;
			transferInfo->a.bothCalls = bothCalls;
		}
		else
		{
			transferInfo->choiceId = ConnectionDetails::CONNECTIONDETAILS_ACTIVECALL;
			transferInfo->a.activeCall = activeCall;
		}
	}
	else if (heldcall)
	{
		heldCall = (ConnectionID *) Asn1Alloc(sizeof(ConnectionID));
		transferInfo->choiceId = ConnectionDetails::CONNECTIONDETAILS_HELDCALL;
		transferInfo->a.heldCall = heldCall;
	}

	csta_set_ConnectionIDChoice(&cid_device, device);

	if (activeCall)
	{
		setoctet(&activeCall->call, activecall);
		activeCall->device = cid_device;
	}
	if (heldCall)
	{
		setoctet(&heldCall->call, heldcall);
		heldCall->device = cid_device;
	}

	if (privateData)
	{
		args->choiceId = TransferCallArgument::TRANSFERCALLARGUMENT_TRANSFERCALLARGUMENTSEQ;
		args->a.transferCallArgumentSeq->transferInfo = transferInfo;
	
		/* FIXME add extensions */
	}
	else
	{
		args->choiceId = TransferCallArgument::TRANSFERCALLARGUMENT_TRANSFERINFO;
		args->a.transferInfo = transferInfo;
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_TRANSFERCALL);
}

int
csta_request_ChangeMonitorFilter (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	monitorid_t monitorid,
	MonitorFilter *filterlist,
	CSTAPrivateData *privateData
)
{
	ChangeMonitorFilterArgument *args;

	args = (ChangeMonitorFilterArgument *) Asn1Alloc(sizeof(ChangeMonitorFilterArgument));

	setoctet(&args->monitorCrossRefID, monitorid);

	if (filterlist)
	{
		args->filterlist = filterlist;
	}
	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_CHANGEMONITORFILTER);
}

int
csta_request_MonitorStart (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	device_t device,
	MonitorFilter *monitorFilter,
	CSTAPrivateData *privateData
)
{
	MonitorStartArgument *args;
	MonitorType mon_type = MTF_DEVICE;

	args = (MonitorStartArgument *) Asn1Alloc(sizeof(MonitorStartArgument));
	args->monitorObject = (MonitorObject *) Asn1Alloc(sizeof(MonitorObject));
	args->monitorObject->choiceId = MonitorObject::CSTAOBJECT_DEVICE;
	csta_set_deviceid(&args->monitorObject->a.device, device);
	args->monitorFilter = monitorFilter;
	args->monitorType = &mon_type;

	if (privateData)
	{
		/* FIXME add extensions */
	}

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_MONITORSTART);
}

int
csta_request_MonitorStop (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	monitorid_t monitorCrossRefID,
	CSTAPrivateData *privateData
)
{
	MonitorStopArgument *args;

	args = (MonitorStopArgument *) Asn1Alloc(sizeof(MonitorStopArgument));
	args->choiceId = MonitorStopArgument::MONITORSTOPARGUMENT_CROSSREFIDENTIFIER;
	args->a.crossRefIdentifier = (MonitorCrossRefID *) Asn1Alloc(sizeof(MonitorCrossRefID));
	setoctet(args->a.crossRefIdentifier, monitorCrossRefID);

	return encode_roiv_apdu(buff, buff_len, invokeID, (void *) args, OV_MONITORSTOP);
}

/* Snapshot Services*/

int
csta_request_SnapshotCallReq (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	ConnectionID *snapshotObj,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_request_SnapshotDeviceReq (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	DeviceID *snapshotObj,
	CSTAPrivateData *privateData
)
{
	return 0;
}

/* Routing Services*/

int
csta_request_RouteRegisterReq (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	DeviceID *routingDevice,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_request_RouteRegisterCancel (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	/*RouteRegisterReqID routeRegisterReqID, FIXME */
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_request_RouteSelect (
	char *buff,
	int buff_len,
	/*RouteRegisterReqID routeRegisterReqID, FIXME */
	RoutingCrossRefID routingCrossRefID,
	DeviceID *routeSelected,
	RetryValue remainRetry,
	SetupValues *setupInformation,
	AsnBool routeUsedReq,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_request_RouteEnd (
	char *buff,
	int buff_len,
	RoutingCrossRefID routingCrossRefID,
	UniversalFailure errorValue,
	CSTAPrivateData *privateData
)
{
	return 0;
}

/* Escape Services*/

int
csta_request_EscapeService (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_request_EscapeServiceConf (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	UniversalFailure error,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_request_SendPrivateEvent (
	char *buff,
	int buff_len,
	CSTAPrivateData *privateData
)
{
	return 0;
}

/* Maintenance Services*/

int
csta_request_SysStatReq (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_request_SysStatStart (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	/*SystemStatusFilter statusFilter, FIXME */
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_request_SysStatStop (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_request_ChangeSysStatFilter (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	/*SystemStatusFilter statusFilter, FIXME */
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_request_SysStatReqConf (
	char *buff,
	int buff_len,
	InvokeIDType invokeID,
	SystemStatus systemStatus,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_request_SysStatEvent (
	char *buff,
	int buff_len,
	SystemStatus systemStatus,
	CSTAPrivateData *privateData
)
{
	return 0;
}

int
csta_request_GetAPICaps (
	char *buff,
	int buff_len,
	InvokeIDType invokeID
)
{
	return 0;
}

int
csta_request_QueryCallMonitor (
	char *buff,
	int buff_len,
	InvokeIDType invokeID
)
{
	return 0;
}

int
encode_roiv_apdu(char *buff, int buff_len, InvokeIDType invokeID, void *args, AsnInt serviceID)
{
	ROSEapdus pdu;
	AsnLen len;

	pdu.choiceId = ROSEapdus::ROSEAPDUS_ROIV_APDU;
	pdu.a.roiv_apdu = (ROIVapdu *) Asn1Alloc(sizeof(ROIVapdu));
	pdu.a.roiv_apdu->invokeID = invokeID;
	pdu.a.roiv_apdu->operation_value = serviceID;
	pdu.a.roiv_apdu->argument.value = args;

	ExpBufResetInWriteRvsMode(encbuf);

	len = BEncROSEapdus(&encbuf, &pdu);
 	if (ExpBufWriteError(&encbuf))
	{
		fprintf(stderr, "cstatest.c: send_roiv_apdu(): BEncROIVapdu(): encbuf was too small\n");
		ResetNibbleMem();
		return -1;
	}

#ifdef DEBUG_CSTATEST
	printf("\n");
	PrintROSEapdus(stdout, &pdu, 0);
	printf("\n");
#endif

	/*
	 * Free all of the decoded value since it has been encoded into the
	 * buffer. This is much more efficient than freeing each component of
	 * the value individually.
	 */
	ResetNibbleMem();

	len = ExpBufDataSize(encbuf);
	if (buff_len >= len)
	{
		memcpy(buff, ExpBufDataPtr(encbuf), len);
		#ifdef DEBUG_CSTATEST
		//logdump(LOG_DEBUG, buff, len);
		#endif
	}
	else
	{
		perror("encode failed passed in buffer too small");
		len = -1;
	}
		
	return len;
}

#ifdef __cplusplus
}
#endif
