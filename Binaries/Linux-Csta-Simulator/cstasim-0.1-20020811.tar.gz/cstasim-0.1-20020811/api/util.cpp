/*
 *
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */


#ifdef WIN32
#ifdef CSTADLL
#define CSTADLLIMPORTEXPORT __declspec(dllexport)
#else
#define CSTADLLIMPORTEXPORT __declspec(dllimport)
#endif /* CSTADLL */
#else
#define CSTADLLIMPORTEXPORT
#endif /* WIN32 */


extern "C"
{
#include "asn-incl.h"
}
#include "csta_defs.h"
#include "csta_config.h"
#include "csta_api.h"



#ifdef __cplusplus
extern "C"
{
#endif


#ifdef __cplusplus
}
#endif

void
setoctet(void *octet, char *s)
{
        int l = strlen(s);

        ((AsnOcts *) octet)->octetLen = l;
        ((AsnOcts *) octet)->octs = (char *) Asn1Alloc(l);
        memcpy(((AsnOcts *) octet)->octs, s, l);
}

void
setoctet(void *octet, ACE_UINT32 n)
{
        ((AsnOcts *) octet)->octetLen = sizeof(ACE_UINT32);
        ((AsnOcts *) octet)->octs = (char *) Asn1Alloc(sizeof(ACE_UINT32));
        memcpy(((AsnOcts *) octet)->octs, &n, sizeof(ACE_UINT32));
}

void
setoctet(void *octet, ACE_UINT64 n)
{
#if defined (ACE_LACKS_LONGLONG_T)
	int len = 2 * sizeof(ACE_UINT32);
	ACE_UINT32 hi = n.hi;
	ACE_UINT32 lo = n.lo;
#else
	int len = sizeof(ACE_UINT64);
#endif

        ((AsnOcts *) octet)->octetLen = len;
        ((AsnOcts *) octet)->octs = (char *) Asn1Alloc(len);

#if defined (ACE_LACKS_LONGLONG_T)
        memcpy(((AsnOcts *) octet)->octs, &hi, sizeof(ACE_UINT32));
        memcpy(((AsnOcts *) octet)->octs + sizeof(ACE_UINT32), &lo, sizeof(ACE_UINT32));
#else
        memcpy(((AsnOcts *) octet)->octs, &n, len);
#endif
}

