/*
 *
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */

#ifdef WIN32
#ifdef CSTADLL
#define CSTADLLIMPORTEXPORT __declspec(dllexport)
#else
#define CSTADLLIMPORTEXPORT __declspec(dllimport)
#endif /* CSTADLL */
#else
#define CSTADLLIMPORTEXPORT
#endif /* WIN32 */

#include <string.h>
extern "C"
{
#include "asn-incl.h"
#include "CSTA-asnany-bridge.h"
}
#include "csta_config.h"
#include "csta_defs.h"
#include "csta_api.h"



#ifdef __cplusplus
extern "C"
{
#endif

extern int init_csta_request(void);
extern int init_csta_response(void);
extern void BDecROSEapdus (BUF_TYPE, ROSEapdus *, AsnLen *, ENV_TYPE);

void
csta_init(void)
{
        ExpBufInit (4096);
        InitNibbleMem(4096, 4096);

	init_csta_request();
	init_csta_response();

        init_asnany_tables();
}

ROSEapdus *
csta_decode_message(char *buf, int size)
{
	ExpBuf ebuf;
	ExpBuf *p = &ebuf;
	ROSEapdus *pdu;
	AsnLen decodedLen = 0;
	jmp_buf env;
	int error;

	ExpBufInstallDataInBuf(p, buf, size);

	if (!(error = setjmp(env)))
	{
		pdu = (ROSEapdus *) Asn1Alloc(sizeof(ROSEapdus));
		BDecROSEapdus(&p, pdu, &decodedLen, env);
	}
	else
	{
		printf("Error in decoding pdu : %d\n", error);
		return 0;
	}

#ifdef DEBUG_CSTATEST_EXTRA
	PrintROSEapdus(stdout, &pdu, 0);
#endif

	return pdu;
}

void
csta_release_memory(void)
{
	ResetNibbleMem();
}

#ifdef __cplusplus
}
#endif

int
csta_set_connectionid(
	ConnectionID **connection_id,
	device_t device,
	connid_t *connid,
	ConnectionIDChoice::ConnectionIDChoiceChoiceId type
)
{
	int status = 0;

	if (connection_id)
	{
		if (*connection_id == 0)
		{
			*connection_id = (ConnectionID *) Asn1Alloc(sizeof(ConnectionID));
		}

		if (device)
		{
			(*connection_id)->device = (ConnectionIDChoice *) Asn1Alloc(sizeof(ConnectionIDChoice));
			(*connection_id)->device->choiceId = type;
			if (type == ConnectionIDChoice::CONNECTIONIDCHOICE_STATICID)
			{
				csta_set_deviceid(&(*connection_id)->device->a.staticID, device);
			}
			else
			{
				(*connection_id)->device->a.dynamicID = (AsnOcts *) Asn1Alloc(sizeof(AsnOcts));
				setoctet((*connection_id)->device->a.dynamicID, device);
			}
		}
		else
		{
			(*connection_id)->device = 0;
		}
		if (connid)
		{
			setoctet(&(*connection_id)->call, *connid);
		}
		else
		{
			memset(&(*connection_id)->call, 0, sizeof((*connection_id)->call));
		}
	}
	else
	{
		status = -1;
	}

	return status;
}

int
csta_set_deviceid(
	DeviceID **deviceid,
	device_t device
)
{
	int status = 0;

	if (deviceid)
	{
		if (*deviceid == 0)
		{
			*deviceid = (DeviceID *) Asn1Alloc(sizeof(DeviceID));
		}

		(*deviceid)->choiceId = DeviceID::DEVICEID_DIALINGNUMBER;

		if (device)
		{
			(*deviceid)->a.dialingNumber = (NumberDigits *) Asn1Alloc(sizeof(NumberDigits));
			setoctet((*deviceid)->a.dialingNumber, device);
		}
		else
		{
			(*deviceid)->a.dialingNumber = 0;
		}
	}
	else
	{
		status = -1;
	}

	return status;
}

int
csta_set_ConnectionIDChoice(
	ConnectionIDChoice **connection_id_choice,
	device_t device
)
{
	int status = 0;

	if (connection_id_choice)
	{
		if (*connection_id_choice == 0)
		{
			*connection_id_choice = (ConnectionIDChoice *) Asn1Alloc(sizeof(ConnectionIDChoice));
		}

		(*connection_id_choice)->choiceId = ConnectionIDChoice::CONNECTIONIDCHOICE_STATICID;

		if (device)
		{
			status = csta_set_deviceid(&(*connection_id_choice)->a.staticID, device);
		}
		else
		{
			(*connection_id_choice)->a.staticID = 0;
		}
	}

	return status;
}

int
csta_set_CallingDeviceID(
	CallingDeviceID **calling_device_id,
	device_t device,
	CallingDeviceID::CallingDeviceIDChoiceId type

)
{
	int status = 0;

	if (calling_device_id)
	{
		if (*calling_device_id == 0)
		{
			*calling_device_id = (CallingDeviceID *) Asn1Alloc(sizeof(CallingDeviceID));
		}
		(*calling_device_id)->choiceId = type;
		if (type == CallingDeviceID::CALLINGDEVICEID_DEVICEIDENTIFIER)
		{
			(*calling_device_id)->a.deviceIdentifier = (ExtendedDeviceID *) Asn1Alloc(sizeof(ExtendedDeviceID));
			(*calling_device_id)->a.deviceIdentifier->choiceId = ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER;
			if (device)
			{
				status = csta_set_deviceid(&(*calling_device_id)->a.deviceIdentifier->a.deviceIdentifier, device);
			}
			else
			{
				(*calling_device_id)->a.deviceIdentifier->a.deviceIdentifier = 0;
			}
		}
	}

	return status;
}

int
csta_set_CalledDeviceID(
	CalledDeviceID **called_device_id,
	device_t device,
	CalledDeviceID::CalledDeviceIDChoiceId type

)
{
	int status = 0;

	if (called_device_id)
	{
		if (*called_device_id == 0)
		{
			*called_device_id = (CalledDeviceID *) Asn1Alloc(sizeof(CalledDeviceID));
		}
		(*called_device_id)->choiceId = type;
		if (type == CalledDeviceID::CALLEDDEVICEID_DEVICEIDENTIFIER)
		{
			(*called_device_id)->a.deviceIdentifier = (ExtendedDeviceID *) Asn1Alloc(sizeof(ExtendedDeviceID));
			(*called_device_id)->a.deviceIdentifier->choiceId = ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER;
			if (device)
			{
				status = csta_set_deviceid(&(*called_device_id)->a.deviceIdentifier->a.deviceIdentifier, device);
			}
			else
			{
				(*called_device_id)->a.deviceIdentifier->a.deviceIdentifier = 0;
			}
		}
	}

	return status;
}

int
csta_set_SubjectDeviceID(
	SubjectDeviceID **subject_device_id,
	device_t device,
	SubjectDeviceID::SubjectDeviceIDChoiceId type

)
{
	int status = 0;

	if (subject_device_id)
	{
		if (*subject_device_id == 0)
		{
			*subject_device_id = (SubjectDeviceID *) Asn1Alloc(sizeof(SubjectDeviceID));
		}
		(*subject_device_id)->choiceId = type;
		if (type == SubjectDeviceID::SUBJECTDEVICEID_DEVICEIDENTIFIER)
		{
			(*subject_device_id)->a.deviceIdentifier = (ExtendedDeviceID *) Asn1Alloc(sizeof(ExtendedDeviceID));
			(*subject_device_id)->a.deviceIdentifier->choiceId = ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER;
			if (device)
			{
				status = csta_set_deviceid(&(*subject_device_id)->a.deviceIdentifier->a.deviceIdentifier, device);
			}
			else
			{
				(*subject_device_id)->a.deviceIdentifier->a.deviceIdentifier = 0;
			}
		}
	}

	return status;
}

int
csta_set_RedirectionDeviceID(
	RedirectionDeviceID **redirection_device_id,
	device_t device,
	RedirectionDeviceID::RedirectionDeviceIDChoiceId type

)
{
	int status = 0;

	if (redirection_device_id)
	{
		if (*redirection_device_id == 0)
		{
			*redirection_device_id = (RedirectionDeviceID *) Asn1Alloc(sizeof(RedirectionDeviceID));
		}
		(*redirection_device_id)->choiceId = type;
		if (type == RedirectionDeviceID::REDIRECTIONDEVICEID_NUMBERDIALED)
		{
			(*redirection_device_id)->a.numberdialed = (ExtendedDeviceID *) Asn1Alloc(sizeof(ExtendedDeviceID));
			(*redirection_device_id)->a.numberdialed->choiceId = ExtendedDeviceID::EXTENDEDDEVICEID_DEVICEIDENTIFIER;
			if (device)
			{
				status = csta_set_deviceid(&(*redirection_device_id)->a.numberdialed->a.deviceIdentifier, device);
			}
			else
			{
				(*redirection_device_id)->a.numberdialed->a.deviceIdentifier = 0;
			}
		}
	}

	return status;
}

int
csta_get_device(char *device, int device_len, AsnOcts *data)
{
	int status = 0;

	if (device)
	{
		if (device_len > data->octetLen)
		{
			memcpy(device, data->octs, data->octetLen);
			*(device + data->octetLen) = 0;
		}
		else
		{
			*device = 0;
			status = -1;
		}
	}
	else
	{
		status = -1;
	}

	return status;
}

int
csta_get_connid(connid_t *connid, AsnOcts *data)
{
	int status = 0;

	if (connid)
	{
		if (sizeof(connid_t) >= data->octetLen)
		{
			memcpy(connid, data->octs, data->octetLen);
		}
		else
		{
			*connid = 0;
			status = -1;
		}
	}
	else
	{
		status = -1;
	}

	return status;
}
