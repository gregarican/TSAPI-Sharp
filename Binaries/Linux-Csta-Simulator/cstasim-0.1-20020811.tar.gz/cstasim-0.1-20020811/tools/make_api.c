/*
 * Copyright (C) 2002 Je Code <jecode@hotpop.com>
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA or look at http://www.gnu.org/copyleft/gpl.html
 */



#include <stdio.h>
#include <errno.h>
#include <sys/stat.h>

extern int errno;
void parse_source(char *, FILE *);


int
main(int argc, char *argv[])
{
	FILE *target;
	struct stat sbuf;
	int i;
	int res;

	if (argc < 3)
	{
		/*  useage */
		return -1;
	}

	res = stat(argv[1], &sbuf);

	if (res == 0 || (res < 0 && errno != ENOENT))
	{
		printf("\n\n\tTarget file problem, make sure file does not already exist.\n\n");
		return -2;
	}

	printf("\n\n\tStarting API extraction process....");

	target = fopen(argv[1], "w+");

	for (i = 2; i < argc ; i++)
	{
		parse_source(argv[i], target);
	}

	printf("API extraction Complete.\n\n");
	return 0;
}

void
parse_source(char *s, FILE *target)
{
	FILE *src = fopen(s, "r");
	char buff[256];
	char *p, *q;
	char *semicolon;
	char *openbrace;
	char *closebrace;
	char *comment;
	char *end;
	char *next_word;
	char prev_start = 0;
	int state = 0;
	int prev_state = 0;
	int writeline;
	int add_newline;
	char debug_buff[8192];
	int i, iter;
	int type = 0;


	if (src)
	{
		#ifdef DEBUG
		printf("\n\t Processing %s....\n", s);
		#endif
		sprintf(debug_buff, "\n/*\n *  %s\n */\n\n", s);
		fwrite(debug_buff, sizeof(char), strlen(debug_buff), target);
		for (p = fgets(buff, sizeof(buff), src); p && (p != EOF) ; )
		{
			semicolon = NULL;
			openbrace = NULL;
			closebrace = NULL;
			comment = NULL;
			next_word = NULL;
			end = NULL;
			writeline = 0;
			add_newline = 0;

			while (isspace(*p) && *p != '\n')
			{
				p++;
			}

			if (state)
			{
				comment = strchr(p, '/');
				closebrace = strchr(p, '}');
				if (!closebrace)
				{
					openbrace = strchr(p, '{');
					if (openbrace)
					{
						if (!comment || openbrace < comment)
						{
							prev_state = state;
							state++;
							#ifdef DEBUG
							sprintf(debug_buff, "state = %d", state);
							fwrite(debug_buff, sizeof(char), strlen(debug_buff), target);
							#endif
						}
					}
				}
				else
				{
					if (!comment || closebrace < comment)
					{
						prev_state = state;
						state--;
						#ifdef DEBUG
						sprintf(debug_buff, "state = %d", state);
						fwrite(debug_buff, sizeof(char), strlen(debug_buff), target);
						#endif
					}
				}

				semicolon = strchr(p, ';');

				if (closebrace || openbrace || semicolon || !comment)
				{
					writeline++;
				}
			}
			else
			{
				if ((strncmp(p, "typedef", strlen("typedef")) == 0) || *p == '{' ||
					(strncmp(p, "CSTADLLIMPORTEXPORT void Print", strlen("CSTADLLIMPORTEXPORT void Print")) == 0))
				{
					writeline++;
					if (strncmp(p, "void Print", strlen("void Print") == 0))
					{
						/*fwrite("CSTADLLIMPORTEXPORT ", 20, 1, target);*/
					}
					semicolon = strchr(p, ';');
					if (!semicolon)
					{

						if (*p != '{')
						{
							add_newline++;
						}

						next_word = strchr(p, ' ');
						if (next_word)
						{
							next_word++;
							if (strncmp(next_word, "struct", strlen("struct")) == 0)
							{
								type = 1;
								#ifdef TDEBUG
								sprintf(debug_buff, "type = %d", type);
								fwrite(debug_buff, sizeof(char), strlen(debug_buff), target);
								#endif
							}
						}
						openbrace = strchr(p, '{');
						if (openbrace)
						{
							state = 1;
							#ifdef DEBUG
							sprintf(debug_buff, "state = %d\n", state);
							fwrite(debug_buff, sizeof(char), strlen(debug_buff), target);
							#endif
						}
					}
				}
				else if (strncmp(p, "#define", strlen("#define")) == 0)
				{
					q = strchr(p, ' ');
					if (++q)
					{
					
						if (!((strncmp(q, "BDec", strlen("BDec")) == 0) ||
							(strncmp(q, "BEnc", strlen("BEnc")) == 0) ||
							(strncmp(q, "Free", strlen("Free")) == 0) ||
							/*(strncmp(q, "Print", strlen("Print")) == 0) ||*/
							(*q == '_')))
						{
							writeline++;
						}
					}
				}
			}

			if (writeline && (*p != '\n'))
			{
				comment = strchr(p, '/');
				if (comment)
				{
					while (*(--comment) == ' ')
					{
						;
					}
			
					end = ++comment;
				}
#ifdef NOT_USED
				else if (semicolon)
				{
					end = ++semicolon;
				}
				else if (openbrace)
				{
					end = ++openbrace;
				}
				else if (closebrace)
				{
					end = ++closebrace;
				}

				/*if (!state && semicolon && closebrace && !type)*/
				if (!state && type)
				{
					type = 0;
					#ifdef TDEBUG
					sprintf(debug_buff, "type = %d", type);
					fwrite(debug_buff, sizeof(char), strlen(debug_buff), target);
					#endif
					next_word += 6;
					/**(++closebrace) = ';';
					*(++closebrace) = 0;*/
					*(next_word) = '\n';
					*(++next_word) = 0;
					end = NULL;
				}
#endif
				

				if (end)
				{
					*end = '\n';
					*(++end) = 0;
				}
				
				switch (state)
				{
				case 0:
					/*
					if (state == 0 && prev_state)
					{
						type = 0;
						prev_state = 0;
					}
					*/
					break;
				default:
					iter = state;
					if (openbrace)
					{
						iter--;
					}
					for (i = 0 ; i < iter ; i++)
					{
						fwrite("\t", sizeof(char), 1, target);
					}
					break;
				}

				if ((add_newline || (!state && prev_start == '}')) && prev_start != '\n')
				{
					fwrite("\n", sizeof(char), 1, target);
					prev_start = '\n';
				}
				else
				{
					if (state)
					{
						prev_start = 0;
					}
					else
					{
						prev_start = *p;
					}
				}

				fwrite(p, sizeof(char), strlen(p), target);
			}
			else if (!state && prev_start == '}')
			{
				fwrite("\n", sizeof(char), 1, target);
				prev_start = 0;
			}

			p = fgets(buff, sizeof(buff), src);
		}

		fclose(src);
	}
	else
	{
		printf("\n\n\tWarning could not open %s\n\n", s);
	}
}
